#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <time.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <dirent.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <sys/vfs.h>
#include <sys/time.h> /* select() */ 
#define _GNU_SOURCE
#include <stdlib.h>
#include <stdio.h>
#include <sqlite3.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <fcntl.h>
#include <assert.h>
#include <net/if.h> 
#ifndef BUILD_RECOVER
#include <libxml/xmlmemory.h>
#include <libxml/parser.h>
#include <libxml/xmlerror.h>
#include <libxml/uri.h>
#include <libxml/entities.h>
#include <libxml/HTMLparser.h>
#include <libxml/xpath.h>
#endif
#include <strings.h>
#include <ctype.h>
#ifndef BUILD_RECOVER
#include <pthread.h>
#endif
#include "buffer.h"
#include "server.h"
#include "log.h"
#include "connections.h"

#ifdef BUILD_ON_ARM
#include "nvram.h"
#ifndef BUILD_RECOVER
#include <dbus/dbus.h>
#include "timezone_offset.h"
#endif

#endif
#include <stdbool.h>
#include "fdevent.h"

#include "request.h"
#include "response.h"
#include "network.h"
#include "http_chunk.h"
#include "stat_cache.h"
#include "joblist.h"

#include "plugin.h"

#include "inet_ntop_cache.h"

#ifdef BUILD_ON_ARM
#define PREFIX                           ""
#else
#define PREFIX                           "/home/target_QT"
#endif
#define PVALUENUM               320
#define COMMANDNUM              4

#define WEB_FACEBOOK            "http://api.facebook.com/restserver.php?api_key=09aacbfa33cf484fd2f2a9b898c0f6b4&method=auth.createToken&v=1.0&sig=2a03b3dbedb29344540850ce4dbdaf1d"
#define WEB_FACEBOOK_AUTH      "http://www.facebook.com/login.php?api_key=09aacbfa33cf484fd2f2a9b898c0f6b4&v=1.0&auth_token="
#define WEB_FACEBOOK_PRO       "http://www.facebook.com/connect/prompt_permissions.php?api_key=09aacbfa33cf484fd2f2a9b898c0f6b4&v=1.0&ext_perm=offline_access,read_stream,publish_stream"

#define APP_CONF_PATH                    PREFIX"/app/config"
#define APP_DATA_PATH                    PREFIX"/app/data"
#define APP_DATAFAV_PATH              PREFIX"/app/data/favorites"
#define TMP_FAVPATH                        PREFIX"/tmp/favorites"
#define DATA_DIR                        PREFIX"/data"
#define DATATMP_DIR                        PREFIX"/data/tmp"

#define CONF_CALLFUNC               APP_CONF_PATH"/Call/call.xml"
#define CONF_AUTOCONFIG               APP_CONF_PATH"/AutoConfig/autoconfig.xml"
#define CONF_RSSNEW               APP_CONF_PATH"/RSSNews/rssnews.xml"
#define CONF_BLF                 APP_CONF_PATH"/BLF/blf.xml"
#define CONF_COLORE                 APP_CONF_PATH"/ColorE/ColorELogin.xml"
#define CONF_WEATHER              APP_CONF_PATH"/Weather/weather.xml"
#define CONF_HWPHBK               APP_CONF_PATH"/HWPhonebook/huawei_server_api.xml"
#define CONF_LASTFM               APP_CONF_PATH"/LastFM/lastfm.xml"
#define CONF_GOOGLEVOICE            APP_CONF_PATH"/GoogleVoice/googlevoice.xml"
#define CONF_BOOKMARKS              APP_CONF_PATH"/Browser/download.xml"
#define CONF_SCREEN               APP_CONF_PATH"/SystemConfig/systemconfig.xml"
#define CONF_MENU                   APP_CONF_PATH"/MenuManager/menu.xml"
#define CONF_PHBKDOWNLOAD       "/data/data/com.android.contacts/shared_prefs/import_export_config.xml"
#define OLDLANGUAGE_PATH          APP_CONF_PATH"/language"
#define CONF_MPK				"/data/data/com.base.module.mpk/shared_prefs/com.base.module.mpk.setting_shareprenferences.xml"
#define CONF_MPKEXT 		"/data/data/com.base.module.mpkext/shared_prefs/com.base.module.mpkext.setting_shareprenferences.xml"
#define SYS_CONFIG_FILE                 APP_CONF_PATH"/SystemSetting/systemsettingmenuconfig.xml"
#define SYS_CONFIG_ACCT                         "0"
#define SYS_CONFIG_UPGRADE                  "1"

#define DATA_PHONEBOOK              APP_CONF_PATH"/Phonebook/Phonebook.xml"
#define DATA_BOOKMARKS              APP_CONF_PATH"/Browser/bookmarks.xml"
#define TMP_PHONEBOOKPATH         PREFIX"/sdcard/phonebook"
#define TMP_AUDIOFILEPATH		  PREFIX"/data/moh/account"
#define TMP_MESSAGEPATH           PREFIX"/sdcard/message"
#define TMP_CALLHISTORYPATH       PREFIX"/sdcard/callhistory"
#define TMP_GS_PHONEBOOK          TMP_PHONEBOOKPATH"/phonebook.xml"
#define TMP_BOOKMARKS                TMP_FAVPATH"/bookmarks.xml"

#define CONF_IM                      PREFIX"/data/.purple/accounts.xml"
#define CONF_IM_DIR                   PREFIX"/data/.purple"
#define VPN_PATH                           PREFIX"/data/openvpn"
#define DATA_PPP                           PREFIX"/data/ppp"
#define PCAP_PATH                           PREFIX"/sdcard/ppp"
#define DIR_802MODE                           PREFIX"/path"
#define PATH_802MODE                           PREFIX"/etc/certs"
#define TEMP_PVALUES                    PREFIX"/data/tmp/pvaluesCache"
#define TEMP_PATH              	       "/tmp"
#define TEMP_PVALUES_SH                    PREFIX"/tmp/set_pvalues.sh"
#define LANGUAGE_PATH             PREFIX"/app/config_flash/language"
#define RINGTONE_PATH             PREFIX"/app/ringtone"
#define TONELIST_PATH               "/system/media/audio/ringtones/"
#define FW_PATH              "/tmp/upgradefile"
#define FIFO_PATH              "/tmp/gparse.fifo"

#define DOWN_PHONEBOOK              "phonebook"

#define JSON_TEMPLATE "var result = {\"Response\":\"%s\"%s};"

#define GUI_XML_PARSE_ATTR    (XML_PARSE_NOBLANKS |XML_PARSE_NOERROR | XML_PARSE_NOWARNING)

#define DBUS_PATH                 "/com/grandstream/dbus/gui"
#define DBUS_INTERFACE            "com.grandstream.dbus.signal"
#define SIGNAL_LIGHTTPD           "lighttpd"
#define SIGNAL_CALLUPDATED          "callfuncupdated"
#define SIGNAL_TVOUT              "tvout"
#define SIGNAL_FACTFUN            "factfun"
#define SIGNAL_CFUPDATED          "cfupdated"
#define SIGNAL_APPLYED          "applyed"

#define SIGNAL_VBRATEUPDATED          "video_bitrate_change"
#define SIGNAL_WIFI_CHANGED         "wifi_changed"
#define SIGNAL_WIFI_SCAN                    "wifi_scan"
#define SIGNAL_COLORE_CHANGE_PWD        "change_password"
#define SIGNAL_WEATHER_UPDATED          "weatherupdated"
#define SIGNAL_RSS_UPDATED              "rssupdated"
#define SIGNAL_BLFUPDATED           "blfupdated"
#define SIGNAL_MPKURIUPDATED        "blfuriupdated"
#define SIGNAL_MPKDATAUPDATED           "mpkdatachanged"
#define SIGNAL_MPKEXTDATAUPDATED	"extdatachanged"
#define SIGNAL_BLFREORDER           "sortchanged"
#define SIGNAL_BLFEXTREORDER 		"extsortchanged"
#define SIGNAL_BLFCOUNTUPDATED           "blfcountChanged"
#define SIGNAL_BLFNAMEUPDATED           "displayformatchanged"
#define SIGNAL_BLFFOLLOWUPDATED           "blfUrifollowChanged"
#define SIGNAL_URIBLFUPDATED           "uriblfupdated"
#define SIGNAL_PROXYUPDATED           "proxyChanged"
#define SIGNAL_CALLFORWARD              "callforward"

//#define SIGNAL_LIGHTTPD_RSS_CHANGED             0
//#define SIGNAL_LIGHTTPD_WEATHER_CHANGED         1
//#define SIGNAL_LIGHTTPD_LAN_CHANGED             2
#define SIGNAL_LIGHTTPD_SCREEN_CHANGED          3
#define SIGNAL_LIGHTTPD_CAPTURE_ON              4
#define SIGNAL_LIGHTTPD_CAPTURE_OFF             5
#define SIGNAL_LIGHTTPD_TIMEZONE_CHANGED        6
//#define SIGNAL_LIGHTTPD_FACTREST                8
#define SIGNAL_ACCT1_TRANSFER_OFF               9
/*#define SIGNAL_ACCT1_TRANSFER_ON               10
#define SIGNAL_ACCT2_TRANSFER_OFF              11
#define SIGNAL_ACCT2_TRANSFER_ON               12
#define SIGNAL_ACCT3_TRANSFER_OFF              13
#define SIGNAL_ACCT3_TRANSFER_ON               14
*/
#define SIGNAL_ACCT1_AUTO_ANSWER_OFF           15
/*
#define SIGNAL_ACCT1_AUTO_ANSWER_ON            16
#define SIGNAL_ACCT2_AUTO_ANSWER_OFF           17
#define SIGNAL_ACCT2_AUTO_ANSWER_ON            18
#define SIGNAL_ACCT3_AUTO_ANSWER_OFF           19
#define SIGNAL_ACCT3_AUTO_ANSWER_ON            20
#define SIGNAL_LIGHTTPD_VOIP_FACRESET               21
#define SIGNAL_LIGHTTPD_USERDATA_FACRESET               22
*/
#define SIGNAL_LIGHTTPD_PHBKDOWN               25      /*with a 'down' suffix means download from internet*/
#define SIGNAL_LIGHTTPD_TONENAME               26
#define SIGNAL_LIGHTTPD_PHBKUPLOAD             27     /*with a 'up' or 'upload' suffix means download from localfile*/
#define SIGNAL_LIGHTTPD_RADIOFAVDOWN           28
/*#define SIGNAL_LIGHTTPD_RADIOFAVUPLOAD         29
#define SIGNAL_LIGHTTPD_YOUTUBEFAVDOWN         30
#define SIGNAL_LIGHTTPD_YOUTUBEFAVUPLOAD       31
#define SIGNAL_LIGHTTPD_BOOKMARKUP             32
#define SIGNAL_LIGHTTPD_WDPHOTOFAVUP           33
#define SIGNAL_LIGHTTPD_BOOKMARKSDOWN          34
#define SIGNAL_LIGHTTPD_WDPHOTOFAVDOWN         35
#define SIGNAL_LIGHTTPD_WEATHERFAVUP           39
#define SIGNAL_LIGHTTPD_WEATHERFAVDOWN          40
*/
#define SIGNAL_LIGHTTPD_PHBKDOWNLOADSAVE          41
//#define SIGNAL_LIGHTTPD_DOWNLOADSAVE            42

#define P_VALUE_EXT_1_KEY_1_MODE 	    10000
#define P_VALUE_EXT_1_KEY_1_ACCT            10001   /* Ext-board 1 key 1 Account */
#define P_VALUE_EXT_1_KEY_1_NAME            10002   /* Ext-board 1 key 1 ID */
#define P_VALUE_EXT_1_KEY_1_ID              10003   /* Ext-board 1 key 1 Name */
#define P_VALUE_EXT_1_KEY_1_POS             10004   /* Ext-board 1 key 1 Position */
    
#define MTD_NANDFLASH		4
#define MEMGETINFO              _IOR('M', 1, struct mtd_info_user)
#define MEMERASE                _IOW('M', 2, struct erase_info_user)
#define MEMGETBADBLOCK		_IOW('M', 11, loff_t)
#define CONST_GCHAR_LEN(x) x, x ? strlen(x) : 0
#define SKYPE_VERSION     "1"

typedef struct mtd_info_user mtd_info_t;
typedef struct erase_info_user erase_info_t;

struct mtd_info_user {
	uint8_t type;
	uint32_t flags;
	uint32_t size;	 // Total size of the MTD
	uint32_t erasesize;
	uint32_t oobblock;  // Size of OOB blocks (e.g. 512)
	uint32_t oobsize;   // Amount of OOB data per block (e.g. 16)
	uint32_t ecctype;
	uint32_t eccsize;
};
struct erase_info_user {
	uint32_t start;
	uint32_t length;
};


#define DEBUGSWITCH 0
#ifndef SHA1_H
#define SHA1_H

#define INTERNAL_SHA1

#define SHA1_MAC_LEN 20

typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned int u32;

static char *dbus_path = "/com/grandstream/dbus/webservice";
static char *dbus_dest = "com.grandstream.dbus.gmi.server";
static char *dbus_interface = "com.grandstream.dbus.method";

void hmac_sha1_vector(const u8 *key, size_t key_len, size_t num_elem,
		      const u8 *addr[], const size_t *len, u8 *mac);
void hmac_sha1(const u8 *key, size_t key_len, const u8 *data, size_t data_len,
	       u8 *mac);
void pbkdf2_sha1(const char *passphrase, const char *ssid, size_t ssid_len,
		 int iterations, u8 *buf, size_t buflen);

struct SHA1Context;

void SHA1Init(struct SHA1Context *context);
void SHA1Update(struct SHA1Context *context, const void *data, u32 len);
void SHA1Final(unsigned char digest[20], struct SHA1Context *context);

#endif /* SHA1_H */

#ifdef USE_OPENSSL
# include <openssl/ssl.h>
# include <openssl/err.h>
#endif


#ifdef HAVE_SYS_FILIO_H
# include <sys/filio.h>
#endif

#include "sys-socket.h"

#ifndef BUILD_RECOVER
xmlChar * unhtmlize (xmlChar * string);
#endif

typedef struct {
	        PLUGIN_DATA;
} plugin_data;

char usercookie[80] = "";
char gmicookie[80] = "";
char usertype[80] = "";
char gmiusertype[80] = "";
char newloginuser[80] = "";
char curuser[80] = "";
time_t sessiontimeout = 0;
time_t gmisessiontimeout = 0;
#ifndef BUILD_RECOVER
ACCStatus accountstatus;
int capmode = 0;
int portphbkresponse = 1;
int phbkresponse = 1;
int radiofavresponse = 1;
int videofavresponse = 1;
int bookmarksrsps = 1;
int wdphotorsps = 1;
int weatherfavrsps = 1;
int chgcolorepwdrsps = 1;
int lan_reload_flag = 0;
int fxostatus = 1;
int fxocon = 0;
int wifiscanok = 0;
char wifiscanresult[256] = "";
int phonerebooting = 0;
char importlanrsps[32] = "1";

int provision_local_fd;
int provision_ret;
int m_uploading = 0;
struct sockaddr_un provision_destaddr;
//pthread_cond_t changeinput_cond = PTHREAD_COND_INITIALIZER;

//void (*get_timezone_offset)(const char *ids[], const int n, long *result);
//void print_offset(buffer *b, long millis_offsets[], int n);

//#define SOFILE "libtimezone_offset.so"
char *ids[] = { "Pacific/Midway", "Pacific/Honolulu", "America/Anchorage",
                "America/Los_Angeles", "America/Tijuana","America/Phoenix", "America/Chihuahua", "America/Denver",
                "America/Costa_Rica", "America/Chicago", "America/Mexico_City", "America/Regina", "America/Bogota",
                "America/New_York", "America/Caracas", "America/Barbados", "America/Halifax", "America/Manaus",
                "America/Santiago", "America/St_Johns", "America/Sao_Paulo", "America/Argentina/Buenos_Aires",
                "America/Godthab", "America/Montevideo", "Atlantic/South_Georgia", "Atlantic/Azores", "Atlantic/Cape_Verde",
                "Africa/Casablanca", "Europe/London", "Europe/Amsterdam",
                "Europe/Belgrade", "Europe/Brussels", "Europe/Sarajevo", "Africa/Windhoek", "Africa/Brazzaville",
                "Asia/Amman", "Europe/Athens", "Asia/Beirut", "Africa/Cairo", "Europe/Helsinki",
                "Asia/Jerusalem", "Europe/Minsk", "Africa/Harare", "Asia/Baghdad",
                "Europe/Moscow", "Asia/Kuwait", "Africa/Nairobi", "Asia/Tehran", "Asia/Baku",
                "Asia/Tbilisi", "Asia/Yerevan", "Asia/Dubai", "Asia/Kabul", "Asia/Karachi",
                "Asia/Oral", "Asia/Yekaterinburg", "Asia/Calcutta", "Asia/Colombo", "Asia/Katmandu",
                "Asia/Almaty", "Asia/Rangoon", "Asia/Krasnoyarsk", "Asia/Bangkok",
                "Asia/Shanghai", "Asia/Hong_Kong", "Asia/Irkutsk",
                "Asia/Kuala_Lumpur", "Australia/Perth", "Asia/Taipei", "Asia/Seoul", "Asia/Tokyo",
                "Asia/Yakutsk", "Australia/Adelaide", "Australia/Darwin", "Australia/Brisbane", "Australia/Hobart",
                "Australia/Sydney", "Asia/Vladivostok", "Pacific/Guam", "Asia/Magadan", "Pacific/Majuro", 
                "Pacific/Auckland", "Pacific/Fiji", "Pacific/Tongatapu"
    };
    
#endif


#ifdef BUILD_ON_ARM
#ifndef BUILD_RECOVER
extern pthread_mutex_t dbusmutex;
extern DBusConnection* bus;
#endif
#endif

#ifndef BUILD_RECOVER
//extern GList  *pvalue_protect;
PvalueList *pvalue_protect = NULL;
PvalueList *command_protect = NULL;
static int dbus_send_lighttpd ( const int arg1 );
//static int dbus_send_tvout ( const int arg1 );
#endif


PvalueList *pvalue_cache = NULL;


extern char* MD5_string(char *string);

static int handle_checkneedapplyp(buffer *b)
{
    buffer_append_string(b, "Response=Success\r\n");

    if( pvalue_cache != NULL )
        buffer_append_string(b, "needapply=1\r\n");
    else
        buffer_append_string(b, "needapply=0\r\n");
    
    return 1;
}

static PvalueList *create_list_node(char *pvalue, char *data)
{
    PvalueList *newNode;
    newNode = (PvalueList *)malloc(sizeof(PvalueList));
    if (newNode == NULL)
    {
       printf("Memory allocation failure!\n");
       return NULL;
    }
    else
    {
       newNode->pvalue = strdup( pvalue );
       newNode->data = strdup( data );
       newNode->next = NULL;
    }
    
    return newNode;
}

static PvalueList* pvaluelist_append( PvalueList *head, char *pvalue, char *data )
{
    PvalueList *newNode = NULL;
    PvalueList *curPtr = head;
    PvalueList *prePtr = head;
    bool replaced  = FALSE;

    if (curPtr == NULL)
    {
        head = create_list_node(pvalue, data );
    }
    else
    {
        while ( curPtr != NULL )
        {
            if ( ( strcmp( curPtr->pvalue, pvalue ) == 0 ) )
            {
                free( curPtr->data );
                curPtr->data = strdup( data );
                replaced = TRUE;
                break;
            }
            prePtr = curPtr;
            curPtr = curPtr->next;
        }

        if ( !replaced && prePtr )
        {
            newNode = create_list_node(pvalue, data );
            newNode->next = NULL;
            prePtr->next = newNode;
        }
    }
    
    return head;
}


static char * pvaluelist_get( PvalueList *list, char *pvalue )
{
    char *value = NULL;

    PvalueList *p = list;
    while ( p != NULL )
    {
        if ( strcmp( p->pvalue, pvalue ) == 0 )
        {
            value = p->data;
            break;
        }

         p = p->next;
    }

    return value;
}

/*static int pvaluelist_find( PvalueList *list, char *pvalue )
{
    int find = 0;
    int pos = 0;

    PvalueList *p = list;
    while ( p != NULL )
    {
        pos++;
        if ( strcmp( p->pvalue, pvalue ) == 0 )
        {
            find = 1;
            break;
        }

         p = p->next;
    }

    return ( find == 1 ) ? pos : find;
}
*/

static const char *nvram_my_get( const char *var)
{
    char * value = "";
    if ( var != NULL )
    {
#ifdef BUILD_ON_ARM
        value = nvram_get( var );
#endif
        if ( value == NULL )
        {
            value = "";
        }
    }

    return value;
}

static int callback(void *NotUsed, int argc, char **argv, char **azColName){
    int i;
    printf("callback argc is %d\n", argc);
    for(i=0; i<argc; i++)
    {
        printf("%s = %s\n", azColName[i], argv[i] ? argv[i] : "NULL");
    }
    printf("\n");
    return 0;
}

int sqlite_handle(buffer *b, const char *sqlstr)
{
    sqlite3 *db;
    int rc;
    char * errmsg = NULL;
    char **dbResult;
    int nRow, nColumn;
    int i , j;
    int index, len;
    char *temp = NULL;

    printf("sql str is %s\n", sqlstr);
    rc = sqlite3_open("/data/data/com.android.providers.settings/databases/settings.db", &db);
    if( rc ){
        printf(stderr, "Can't open database: %s\n", sqlite3_errmsg(db));
        sqlite3_close(db);
        return 0;
    }
    printf("db open suc\n");
    /*rc = sqlite3_exec(db, sqlstr, callback, 0, &errmsg);
    if( rc!=SQLITE_OK )
    {
        printf(stderr, "SQL error: %s\n", errmsg);
        sqlite3_free(errmsg);
    }*/
    rc = sqlite3_get_table ( db, sqlstr , &dbResult, &nRow, &nColumn, &errmsg );
    if( rc == SQLITE_OK )
    {
        index = nColumn;
        printf( "query %d records.\n", nRow );
        for( i = 0; i < nRow ; i++ )
        {
            printf("Record %d:\n" , i+1 );
            for( j = 0 ; j < nColumn; j++ )
            {
                if( !strcasecmp(dbResult[j], "name") )
                {
                    len = 4 + strlen(dbResult[j]) + strlen(dbResult[index]);
                    temp = malloc( len );
                    snprintf(temp, len, "%s=", dbResult[index]);
                    buffer_append_string(b, temp);
                    free(temp);
                }else if( !strcasecmp(dbResult[j], "value") )
                {
                    buffer_append_string(b, dbResult[index]);
                    buffer_append_string(b, "\r\n");
                }
                printf( "index:%d, name:%s, value:%s\n", index, dbResult[j], dbResult[index] );
                ++index;
            }
            printf("---index--%d--\n" , index);
        }
    }else
    {
        printf(stderr, "SQL error: %s\n", errmsg);
        sqlite3_free(errmsg);
    }
    sqlite3_free_table ( dbResult );
    sqlite3_close(db);
    return 1;
}

static const char *msg_get_header(const struct message *m, char *var)
{
	char cmp[80];
	unsigned int x;
    
	snprintf(cmp, sizeof(cmp), "%s=", var);
	for (x = 0; x < m->hdrcount; x++) {
		if (!strncasecmp(cmp, m->headers[x], strlen(cmp))) {
			return m->headers[x] + strlen(cmp);
		}
	}

	return NULL;
}

static char * build_JSON_res( server *srv, connection *con,  const struct message *m, char *appendRes )
{
    char *temp = NULL;
    if ( ( srv != NULL ) && ( con != NULL ) && ( m != NULL ) && ( appendRes != NULL ) )
    {
         response_header_overwrite(srv, con, CONST_STR_LEN("Content-Type"), 
                    CONST_STR_LEN("application/x-javascript; charset=utf-8"));
            
        const char * jsonCallback = msg_get_header( m, "jsoncallback" );
        if ( jsonCallback != NULL )
        {
            temp = malloc( strlen(appendRes) +10 + strlen( jsonCallback ) );
            snprintf( temp, strlen(appendRes) +10 + strlen( jsonCallback ),
                "%s(%s)", jsonCallback, appendRes );
        }
        else
        {
             temp = strdup( appendRes );
        }
    }
    
    return temp;
}

static char * build_JSON_formate( server *srv, connection *con,  const struct message *m, char *appendRes )
{
    char *temp = NULL;
    if ( ( srv != NULL ) && ( con != NULL ) && ( m != NULL ) && ( appendRes != NULL ) )
    {
         response_header_overwrite(srv, con, CONST_STR_LEN("Content-Type"), 
                    CONST_STR_LEN("application/x-javascript; charset=utf-8"));
            
        const char * jsonCallback = msg_get_header( m, "jsoncallback" );
        if ( jsonCallback != NULL )
        {
	    printf("jsonclall----------\r\n");
            temp = malloc( strlen(appendRes) + 10 + strlen( jsonCallback ) );
            snprintf( temp, strlen(appendRes) + 10 + strlen( jsonCallback ),
                "%s(%s)", jsonCallback, appendRes );
        }
        else
        {
             temp = strdup( appendRes );
        }
    }
    
    return temp;
}

static void uri_decode(char *s)
{
    char *o;
    unsigned int tmp;

    for (o = s; *s; s++, o++) {
    	if (*s == '%' && strlen(s) > 2 && sscanf(s + 1, "%2x", &tmp) == 1) {
    		/* have '%', two chars and correct parsing */
    		*o = tmp;
    		s += 2;	/* Will be incremented once more when we break out */
    	} else /* all other cases, just copy */
    		*o = *s;
    }
    *o = '\0';
}

static int handle_sqlitesetting(buffer *b, const struct message *m)
{
    printf("handle_sqlitesettting\n");
    const char *temp = NULL;
    temp = msg_get_header(m, "sqlstr");
    uri_decode((char *)temp);
    buffer_append_string(b,"Response=Success\r\n");
    return sqlite_handle(b, temp);
}

static int authenticate (const struct message *m)
{
    const char *user = msg_get_header (m, "Username");
    const char *pass = msg_get_header (m, "Secret");

    if (user == NULL || pass == NULL)
    {
        return -1;
    }
    uri_decode((char *) pass);
    if ((!strcasecmp ("admin", user)) || (!strcasecmp("gmiadmin", user)))
    {
#ifdef BUILD_ON_ARM
        char *adminpwd = nvram_get ("2");
#else
        char *adminpwd = "admin";
#endif
        if (adminpwd == NULL) 
        {
            adminpwd = "admin";
#ifdef BUILD_ON_ARM
            nvram_set ("2", "admin");
            nvram_commit ();    
#endif
        }

        if (!strcmp (adminpwd, pass))
        {
	    if(!strcmp("admin", user))
            	strcpy (usertype, "admin");
	    else
		strcpy (gmiusertype, "gmiadmin");

	    strcpy(newloginuser, user);
	    strcpy(curuser, user);
            return 0;
        }
        
    } else if (!strcasecmp ("user", user)) 
    {
#ifdef BUILD_ON_ARM
        char *userpwd = nvram_get ("196");
#else
        char *userpwd = "user";
#endif
        if (userpwd == NULL) 
        {
            //printf ("1.----------userpwd init is null----------\n");
            userpwd = "123";
#ifdef BUILD_ON_ARM
            nvram_set ("196", "123");
            nvram_commit ();
#endif
        }
        
        if (!strcmp (userpwd, pass)) 
        {
            strcpy (usertype, "user");
	    strcpy (newloginuser, user);
	    strcpy (curuser, user);
            return 0;
        }
    }

    return -1;
}

static void authenticate_success_response(server *srv, connection *con, 
    buffer *b, const struct message *m)
{
    long unsigned int cookie;
    char *tmp = NULL;

    time_t now;
    cookie = rand();
    tmp = malloc(128);
    time(&now);

    if( (!strcasecmp("admin", newloginuser)) || (!strcasecmp("user", newloginuser))) {
    	sprintf(usercookie, "%08lx", cookie);
    	snprintf(tmp, 128, "phonecookie=\"%s\";", usercookie);
    	sessiontimeout = now + WEB_TIMEOUT;
    } else if (!strcasecmp("gmiadmin", newloginuser)) {
	sprintf(gmicookie, "%08lx", cookie);
	snprintf(tmp, 128, "gmicookie=\"%s\";", gmicookie);
	gmisessiontimeout = now + WEB_TIMEOUT;
    }


    response_header_overwrite(srv, con, CONST_STR_LEN("Set-Cookie"),
        CONST_GCHAR_LEN(tmp));

    free(tmp);

    tmp = malloc(strlen(usertype)+16);
    snprintf(tmp, strlen(usertype)+16, "type=%s;", newloginuser);
    response_header_insert(srv, con, CONST_STR_LEN("Set-Cookie"),
        CONST_GCHAR_LEN(tmp));

    free(tmp);
     
    response_header_insert(srv, con, CONST_STR_LEN("Set-Cookie"),
        CONST_STR_LEN("Version=\"1\";"));
    tmp = malloc(16);
    snprintf(tmp, 16, "Max-Age=%d", WEB_TIMEOUT);
    response_header_insert(srv, con, CONST_STR_LEN("Set-Cookie"),
        CONST_GCHAR_LEN(tmp));

    free(tmp);

    const char * resType = msg_get_header(m, "format");
    if ( (resType != NULL) && !strcasecmp( resType, "json" ) )
    {
        response_header_overwrite(srv, con, CONST_STR_LEN("Content-Type"), 
            CONST_STR_LEN("application/x-javascript; charset=utf-8"));
        
        const char * jsonCallback = msg_get_header( m, "jsoncallback" );

        if ( jsonCallback != NULL )
        {
            tmp = malloc( 128 + strlen( jsonCallback ) );
            snprintf( tmp, 128 + strlen( jsonCallback ),
                "%s(%s)", jsonCallback, "{\"res\": \"success\", \"msg\" : \"authentication accepted\"}" );
        }
        else
        {
            tmp = malloc( 128 );
            snprintf( tmp, 128, "%s", "{\"res\": \"success\", \"msg\" : \"authentication accepted\"}" );
        }
        
        buffer_append_string( b, tmp );
        free(tmp);
    }
    else
    {
        buffer_append_string(b,
            "Response=Success\r\n"
            "Message=Authentication accepted\r\n");
    }
}

#ifndef BUILD_RECOVER
static int handle_logoff(buffer *b)
{
	long unsigned int cookie;

	cookie = rand();

	if( (!strcmp("admin", curuser)) || (!strcmp("user", curuser)) ) {
	    sprintf(usercookie, "%08lx", cookie);
	    strcpy(usertype, "none");
	    sessiontimeout = 0;
	} else if (!strcmp("gmiadmin", curuser)) {
	    sprintf(gmicookie, "%08lx", cookie);
	    strcpy(gmiusertype, "none");
	    gmisessiontimeout = 0;
	}
	//printf("logoff to del the cookie, usercookie now is %s, "
	//	"usertype now is %s, sessiontimeout now is %d\n",
	//	usercookie, usertype, sessiontimeout);
	buffer_append_string(b, "Response=Success\r\n"
		"Message=Logoff Success\r\n");

	return 0;
}

static int handle_getcolore(buffer *b)
{
    char res[64] = "";
    xmlChar *key = NULL;
    xmlDoc *doc = NULL;
    xmlNode *root_element = NULL;
    xmlNode *cur_node = NULL;

    doc = xmlReadFile( CONF_COLORE, NULL, 0 );
    if (doc == NULL)
    {
        printf("error: could not parse file %s\n", CONF_COLORE);
        buffer_append_string(b, "Response=Error\r\n"
                "Message=Configuration File Not Found\r\n");
        return -1;
    }

    buffer_append_string (b, "Response=Success\r\n");

    /*Get the root element node */
    root_element = xmlDocGetRootElement(doc);
    for (cur_node = root_element->xmlChildrenNode; cur_node; cur_node = cur_node->next)
    {
        if (cur_node->type == XML_ELEMENT_NODE)
        {
            if ((!xmlStrcmp(cur_node->name, BAD_CAST "enable")))
            {
                key = xmlNodeListGetString(doc, cur_node->xmlChildrenNode, 1);
                if (key != NULL)
                {
                    snprintf(res, sizeof(res), "enable=%s\r\n", (char *) key );
                    buffer_append_string(b, res);
                    xmlFree(key);
                }else
                {
                    buffer_append_string(b, "enable=\r\n");
                }
            }else if ((!xmlStrcmp(cur_node->name, BAD_CAST "username")))
            {
                key = xmlNodeListGetString(doc, cur_node->xmlChildrenNode, 1);
                if (key != NULL)
                {
                    snprintf(res, sizeof(res), "username=%s\r\n", (char *) key );
                    buffer_append_string(b, res);
                    xmlFree(key);
                }else
                {
                    buffer_append_string(b, "username=\r\n");
                }
            }else if ((!xmlStrcmp(cur_node->name, BAD_CAST "password")))
            {
                key = xmlNodeListGetString(doc, cur_node->xmlChildrenNode, 1);
                if (key != NULL)
                {
                    snprintf(res, sizeof(res), "password=%s\r\n", (char *) key );
                    buffer_append_string(b, res);
                    xmlFree(key);
                }else
                {
                    buffer_append_string(b, "password=\r\n");
                }
            }else if ((!xmlStrcmp(cur_node->name, BAD_CAST "save-password")))
            {
                key = xmlNodeListGetString(doc, cur_node->xmlChildrenNode, 1);
                if (key != NULL)
                {
                    snprintf(res, sizeof(res), "save-password=%s\r\n", (char *) key );
                    buffer_append_string(b, res);
                    xmlFree(key);
                }else
                {
                    buffer_append_string(b, "save-password=\r\n");
                }
            }else if ((!xmlStrcmp(cur_node->name, BAD_CAST "auto-login")))
            {
                key = xmlNodeListGetString(doc, cur_node->xmlChildrenNode, 1);
                if (key != NULL)
                {
                    snprintf(res, sizeof(res), "auto-login=%s\r\n", (char *) key );
                    buffer_append_string(b, res);
                    xmlFree(key);
                }else
                {
                    buffer_append_string(b, "auto-login=\r\n");
                }
            }else if ((!xmlStrcmp(cur_node->name, BAD_CAST "login-success")))
            {
                key = xmlNodeListGetString(doc, cur_node->xmlChildrenNode, 1);
                if (key != NULL)
                {
                    snprintf(res, sizeof(res), "loginsuc=%s\r\n", (char *) key );
                    buffer_append_string(b, res);
                    xmlFree(key);
                }else
                {
                    buffer_append_string(b, "loginsuc=\r\n");
                }
            }
        }
    }

    /*free the document */
    xmlFreeDoc(doc);
    return 1;
}

static int handle_putcolore (buffer *b, const struct message *m)
{
    xmlDocPtr doc = NULL;
    xmlNode *root_element = NULL;
    xmlNode *cur_node = NULL;
    const char *temp = NULL;
    char val[256] = "";

    doc = xmlReadFile(CONF_COLORE, NULL, 0);

    if (doc == NULL)
    {
        printf("error: could not parse file %s\n", CONF_COLORE);
        buffer_append_string(b, "Response=Error\r\n"
                "Message=Configuration File Not Found\r\n");
        return -1;
    }

    /*Get the root element node */
    root_element = xmlDocGetRootElement(doc);

    for (cur_node = root_element->xmlChildrenNode; cur_node; cur_node = cur_node->next)
    {
        if (cur_node->type == XML_ELEMENT_NODE)
        {
            if ((!xmlStrcmp(cur_node->name, BAD_CAST "enable")))
            {
                temp = msg_get_header(m, "enable");
                if ( temp != NULL )
                {
                    memset(val, 0, sizeof(val));
                    strncpy(val, temp, sizeof(val) - 1);
                    uri_decode(val);
                    //tempint = atoi(val);
                    //snprintf(tempbuf, sizeof(tempbuf), "%d", tempint);
                    xmlNodeSetContent(cur_node, (xmlChar *) val);
                }
            }else if ((!xmlStrcmp(cur_node->name, BAD_CAST "username")))
            {
                temp = msg_get_header(m, "username");
                if ( temp != NULL )
                {
                    memset(val, 0, sizeof(val));
                    strncpy(val, temp, sizeof(val) - 1);
                    uri_decode(val);
                    xmlNodeSetContent(cur_node, (xmlChar *) val);
                }
            }else if ((!xmlStrcmp(cur_node->name, BAD_CAST "password")))
            {
                temp = msg_get_header(m, "pwd");
                if ( temp != NULL )
                {
                    memset(val, 0, sizeof(val));
                    strncpy(val, temp, sizeof(val) - 1);
                    uri_decode(val);
                    xmlNodeSetContent(cur_node, (xmlChar *) val);
                }
            }else if ((!xmlStrcmp(cur_node->name, BAD_CAST "save-password")))
            {
                temp = msg_get_header(m, "savepwd");
                if ( temp != NULL )
                {
                    memset(val, 0, sizeof(val));
                    strncpy(val, temp, sizeof(val) - 1);
                    uri_decode(val);
                    xmlNodeSetContent(cur_node, (xmlChar *) val);
                }
            }else if ((!xmlStrcmp(cur_node->name, BAD_CAST "auto-login")))
            {
                temp = msg_get_header(m, "autologin");
                if ( temp != NULL )
                {
                    memset(val, 0, sizeof(val));
                    strncpy(val, temp, sizeof(val) - 1);
                    uri_decode(val);
                    xmlNodeSetContent(cur_node, (xmlChar *) val);
                }
            }
        }
    }

    xmlSaveFormatFileEnc(CONF_COLORE, doc, "UTF-8", 1);
    xmlFreeDoc(doc);
    xmlCleanupParser();
    xmlMemoryDump();
    sync();

    buffer_append_string (b, "Response=Success\r\n");

    return 1;
}

static int handle_changepwd (buffer *b, const struct message *m)
{
    const char *uname = NULL;
    const char *oldpwd = NULL;
    const char *pwd = NULL;
    /*char val[256] = "";
    memset(val, 0, sizeof(val));
    strncpy(val, temp, sizeof(val) - 1);
    uri_decode(val);*/

    uname = msg_get_header(m, "uname");
    uri_decode((char *)uname);
    oldpwd = msg_get_header(m, "oldpwd");
    uri_decode((char *)oldpwd);
    pwd = msg_get_header(m, "pwd");
    uri_decode((char *)pwd);
#ifdef BUILD_ON_ARM
    DBusMessage* message;

    if ( bus == NULL )
    {
        printf( "Error: Dbus bus is NULL\n" );
        return 1;
    }

    message = dbus_message_new_signal( DBUS_PATH, DBUS_INTERFACE, SIGNAL_COLORE_CHANGE_PWD);
    if ( message == NULL )
    {
        printf( "message is NULL\n");
        return 1;
    }

    dbus_message_append_args( message, DBUS_TYPE_STRING, &uname, DBUS_TYPE_STRING, &oldpwd, DBUS_TYPE_STRING, &pwd, DBUS_TYPE_INVALID );

    dbus_connection_send( bus, message, NULL );
    dbus_message_unref( message );

#endif

    buffer_append_string (b, "Response=Success\r\n");
    return 0;
}

static int handle_chgcolorepwdrsps(buffer *b)
{
    char res[32] = "";

    buffer_append_string (b, "Response=Success\r\n");

    snprintf(res, sizeof(res), "chgcolorepwdrsps=%d\r\n", chgcolorepwdrsps);
    buffer_append_string(b, res);

    if(chgcolorepwdrsps != 1)
        chgcolorepwdrsps = 1;
    return 0;
}

static int handle_coloreExist(buffer *b)
{
    const char *val = NULL;
    char res[64] = "";

#ifdef BUILD_ON_ARM
    val = nvram_my_get("oem_id");
#else
    val = "unknown";
#endif
    snprintf(res, sizeof(res), "Response=Success\r\ncoloreexist=%s\r\n", val);
    buffer_append_string(b, res);

    return 0;
}
#endif

static int handle_get(buffer *b, const struct message *m)
{
    int x;
    char hdr[64] = "";
    char *res = NULL;

    const char *val = NULL, *var = NULL;
    const char *resType = NULL;
    char *temp = NULL;
    char *newtemp = NULL;
    const char * jsonCallback = NULL;

    resType = msg_get_header(m, "format");

    if((resType != NULL) && !strcasecmp(resType, "json"))
    {
        jsonCallback = msg_get_header( m, "jsoncallback" );    
    }
    else
    {
        buffer_append_string (b, "Response=Success\r\n");
    }

    for (x = 0; x < 10000; x++)
    {
    	snprintf(hdr, sizeof(hdr), "var-%04d", x);
    	var = msg_get_header(m, hdr);
#ifndef BUILD_RECOVER
        if ( (var == NULL) )
        {
            break;
        }else if( protected_pvalue_find(pvalue_protect, (char *) var) )
        {
            continue;
        }
#else
        if ( (var == NULL) )
        {
            break;
        }
#endif

        char *fromCache = pvaluelist_get( pvalue_cache, var );
        if ( fromCache != NULL )
        {
            val = fromCache;
        }
        else
        {
#ifdef BUILD_ON_ARM
            val = nvram_my_get(var);
#else
            val = "Unknow";
#endif
        }

        res = malloc(strlen(var)+strlen(val)+16);

        if(jsonCallback == NULL)
        {
            sprintf(res,"%s=%s\r\n", var, val);
            buffer_append_string(b, res);
        }
        else
        {
            if(temp == NULL)
            {
                sprintf(res,"\"%s\" : \"%s\"", var, val);
                temp = malloc((64 + strlen(res) + strlen(jsonCallback)) * sizeof(char));
                sprintf(temp, "%s({\"res\" : \"success\", %s", jsonCallback, res);
            }
            else
            {
                sprintf(res,", \"%s\" : \"%s\"", var, val);
                newtemp = realloc(temp, (strlen(temp) + strlen(res)) * sizeof(char));

                if(newtemp == NULL)
                {
                    free(temp);
                    temp = NULL;
                    break;
                }
                else
                {
                    temp = newtemp;
                    strcat(temp, res);
                }
            }
        }

        free(res);
    }

    if(jsonCallback != NULL)
    {
        if(temp == NULL)
        {
            temp = malloc((strlen(jsonCallback) + 128) * sizeof(char));
            sprintf(temp, "%s(%s)", jsonCallback, "{\"res\": \"error\", \"msg\" : \"new memory failed or no value\"}");
            buffer_append_string( b, temp );
            free(temp);
        }
        else
        {
            strcat(temp, "})");
            buffer_append_string( b, temp );
            free(temp);
        }
    }

    return 0;
}

#ifndef BUILD_RECOVER


static int dbus_send_cfupdated ( void )
{
#ifdef BUILD_ON_ARM
    DBusMessage* message;

    if ( bus == NULL )
    {
        printf( "Error: Dbus bus is NULL\n" );
        return 1;
    }

    message = dbus_message_new_signal( DBUS_PATH, DBUS_INTERFACE, SIGNAL_CFUPDATED);
    if ( message == NULL )
    {
        printf( "message is NULL\n" );
        return 1;
    }

    dbus_message_append_args( message,  DBUS_TYPE_INVALID );

    dbus_connection_send( bus, message, NULL );
    dbus_message_unref( message );
#endif
    return 0;
}

static int dbus_send_applyed ( void )
{
#ifdef BUILD_ON_ARM
    DBusMessage* message;

    if ( bus == NULL )
    {
        printf( "Error: Dbus bus is NULL\n" );
        return 1;
    }

    message = dbus_message_new_signal( DBUS_PATH, DBUS_INTERFACE, SIGNAL_APPLYED);
    if ( message == NULL )
    {
        printf( "message is NULL\n" );
        return 1;
    }

    dbus_message_append_args( message,  DBUS_TYPE_INVALID );

    dbus_connection_send( bus, message, NULL );
    dbus_message_unref( message );
#endif
    return 0;
}

static void get_blf_nametype(int extIndex, int *nametype, int *fromserv)
{
    xmlDocPtr doc = NULL;
    xmlNode *root_element = NULL;
    xmlNode *cur_node = NULL;
    xmlChar *key = NULL;
	xmlChar *val = NULL;
    const char *tempbuf = NULL;
     
    if(extIndex == 0)
    	doc = xmlReadFile(CONF_MPK, NULL, 0);
    else
	doc = xmlReadFile(CONF_MPKEXT, NULL, 0);
 
    if (doc == NULL) 
    {
        printf("error: could not parse file %s\n", CONF_MPK);
        return 0;
    }
    
	tempbuf = malloc(24);
	snprintf(tempbuf, 24, "display_format%d", extIndex);
	printf("get extindex is %s\n", tempbuf);
    //int nametype = 0;
	//int fromserv = 0;
    
    /*Get the root element node */
	root_element = xmlDocGetRootElement(doc);
    for (cur_node = root_element->xmlChildrenNode; cur_node; cur_node = cur_node->next) 
    {
    	if (cur_node->type == XML_ELEMENT_NODE) 
        {
        	if ((!xmlStrcmp(cur_node->name, BAD_CAST "int")))
            {
            	key = xmlGetProp(cur_node, BAD_CAST "name");
                if( key != NULL )
                {
                	if( strcmp( (char *)key, tempbuf) == 0 ) 
		            {
		            	//nametype = atoi( (char*)xmlNodeListGetString(doc, cur_node->xmlChildrenNode, 1) );
						val = xmlGetProp(cur_node, BAD_CAST "value");
						if (val != NULL) {
							*nametype = atoi(val);

							xmlFree(val);
						}
		            }
                	xmlFree(key);
                }
            }
			if ((!xmlStrcmp(cur_node->name, BAD_CAST "boolean")))
			{
				key = xmlGetProp(cur_node, BAD_CAST "name");
				if (key != NULL)
				{
					if (strcmp((char*)key, "displaynameshowfromserver") == 0)
					{
						val = xmlGetProp(cur_node, BAD_CAST "value");
						if (val != NULL) {
							if (strcmp(val, "true") == 0)
								*fromserv = 1;
							else
								*fromserv = 0;

							xmlFree(val);
						}
					}
					xmlFree(key);
				}
			}
        }
    }
    xmlFreeDoc(doc);
    //return nametype;
}

static int handle_getmpkexist(buffer *b, const struct message *m)
{
    sqlite3 *db;
    int rc;
    char * errmsg = NULL;
    char **dbResult;
    int nRow, nColumn;
    char *temp = NULL, *number = NULL, *oldIndex = NULL;

    rc = sqlite3_open("/data/data/com.base.module.mpkshutcut/databases/mpk.db", &db);
    if( rc ){
        printf(stderr, "Can't open database: %s\n", sqlite3_errmsg(db));
        sqlite3_close(db);
        buffer_append_string(b, "0");
        return 0;
    }
    number = msg_get_header(m, "number");
    uri_decode(number);
    int acct = 0, mode = 0;
    acct = atoi( msg_get_header(m, "account") );
    mode = atoi( msg_get_header(m, "mode") );
    temp = malloc( 128 );

    oldIndex = msg_get_header(m, "index");
    if( oldIndex != NULL )
    {
        if( mode == 2 || mode == 4 || mode == 5 )
            snprintf(temp, 128, "select * from mpkinfo where accountid=\"%s\" and mode=%d and id!=%d;", number, mode, atoi(oldIndex) );
        else
            snprintf(temp, 128, "select * from mpkinfo where accountid=\"%s\" and account=%d and mode=%d and id!=%d;", number, acct, mode, atoi(oldIndex));
    }else
    {
        if( mode == 2 || mode == 4 || mode == 5 )
            snprintf(temp, 128, "select * from mpkinfo where accountid=\"%s\" and mode=%d;", number, mode);
        else
            snprintf(temp, 128, "select * from mpkinfo where accountid=\"%s\" and account=%d and mode=%d;", number, acct, mode);
    }
    printf("temps is %s\n", temp);
    rc = sqlite3_get_table ( db, temp , &dbResult, &nRow, &nColumn, &errmsg );
    free(temp);
    if( rc == SQLITE_OK )
    {
        printf( "query %d records, nColumn is %d.\n", nRow, nColumn );
        temp = malloc( 8 );
        snprintf(temp, 8, "%d", nRow);
        buffer_append_string(b, temp);
        free(temp);
    }else
    {
        buffer_append_string(b, "0");
        printf(stderr, "SQL error: %s\n", errmsg);
        sqlite3_free(errmsg);
    }
    sqlite3_free_table ( dbResult );
    sqlite3_close(db);

    return 1;
}

/* search CONF_MPK file. get the index of applied account via mpkindex(which board)*/
static int handle_getapldacct(buffer *b, const struct message *m)
{
    /* acct_name: "name" attr of "int" node
     * value: "value" attr of "int" node
     * index_str: change from value
     * name_str: change from acct_name
     * ptr: return of strstr function
     * mpkindex: the request argument
     */  	
    xmlDoc *doc = NULL;
    xmlNode *root_element = NULL;
    xmlNode *cur_node = NULL;
    xmlChar *acct_name = NULL;
    xmlChar *value = NULL;
    char *index_str = NULL;
    char *name_str = NULL;
    char *res = NULL;
    char *sub_str = NULL;
    char *temp_substr = NULL;
    int index_value = 0;
    int mpkindex = 0;
    int len = 0;
    int flag = 0;

    /*get the request argument*/
    index_str = msg_get_header(m, "mpkindex");
    if(index_str != NULL)
    {
    	mpkindex = atoi(index_str);
        doc = xmlReadFile( CONF_MPK, NULL, 0);
        if(doc == NULL)
        {
            printf("error: could not parse file %s\n", CONF_MPK);
            buffer_append_string(b, "Response=Error\r\n"
                "Message=Configuration File Not Found\r\n");
            return -1;
        }

        buffer_append_string(b, "Response=Success\r\nacctindex=");

        res = malloc(2);

        root_element = xmlDocGetRootElement(doc);
        cur_node = root_element->xmlChildrenNode;

	while(cur_node != NULL)
        {
            if(!(xmlStrcmp(cur_node->name, BAD_CAST "int")))
            {
		/*get the "value" attr. and compared with the request argument*/
                value = xmlGetProp(cur_node, BAD_CAST "value");
                index_value = atoi((char*)value);
                if(mpkindex == index_value)
                {
		    /*get the "name" attr */
                    acct_name = xmlGetProp(cur_node, BAD_CAST "name");
                    name_str = (char*)acct_name;

		    len = strlen(name_str)-1;
		    
		    /* get the substr of name_str. remove the last number*/
		    sub_str = malloc(len+1);
		    temp_substr = sub_str;

		    while(len--)
			*(sub_str++) = *(name_str++);
		    *sub_str = '\0';

		    /*compare the substr with "blfgroup". if equal,node is the wanted*/
                    if(!(strcmp("blfgroup",temp_substr)))
                    {
			/*get the account index.the last char of name_str*/
                        res[0] = *name_str;
                        res[1] = '\0';
                        if(flag!=0)
                            buffer_append_string(b,",");
                        buffer_append_string(b,res);
                        flag = 1;
                    }
		    free(temp_substr);
		    xmlFree(acct_name);
                }
                xmlFree(value);
            }
            cur_node = cur_node->next;
        }

        free(res);
        xmlFree(doc);
    }
    return 0;
}

static int handle_getmpkinfo(buffer *b, const struct message *m)
{
	char *temp = NULL;
	const char *val = NULL;
    
	temp = msg_get_header(m, "mpkindex");
	int mpkindex = atoi(temp);
	//temp = msg_get_header(m, "page");
	//int pageindex = atoi(temp);
	
	//printf("mpkindex:%d	page:%d\n", mpkindex, pageindex);

	//int addnum = pageindex * 100 + mpkindex * 200;
	int addnum = mpkindex * 200;
	printf("addnum is %d\n", addnum);
	int tmpint;
	char tempbuf[8] = "";
	char *curNumber = NULL, *curName = NULL, *curPos = NULL;
	int curAcct, curMode;
	int count = 0, len;
	int nametype = 0;
	int fromserv = 0;

	buffer_append_string(b, "{\"Response\":\"Success\",");

	//nametype = get_blf_nametype(mpkindex + 1);
	get_blf_nametype(mpkindex + 1, &nametype, &fromserv);
	temp = malloc(64);
	snprintf(temp, 64, "\"nametype\":\"%d\",\"Data\":[", nametype);
	buffer_append_string(b, temp);

	for( int i = 0; i < 40; i ++ )
	{
        tmpint = P_VALUE_EXT_1_KEY_1_ACCT + addnum + 5 * i;
        snprintf(tempbuf, 8, "%d", tmpint);
        curAcct = atoi( nvram_my_get(tempbuf) );

        tmpint = P_VALUE_EXT_1_KEY_1_ID + addnum + 5 * i;
        snprintf(tempbuf, 8, "%d", tmpint);
        curNumber = nvram_my_get(tempbuf);

        tmpint = P_VALUE_EXT_1_KEY_1_MODE + addnum + 5 * i;
        snprintf(tempbuf, 8, "%d", tmpint);
        curMode = atoi( nvram_my_get(tempbuf) );

        tmpint = P_VALUE_EXT_1_KEY_1_NAME + addnum + 5 * i;
        snprintf(tempbuf, 8, "%d", tmpint);
        curName = nvram_my_get(tempbuf);

        tmpint = P_VALUE_EXT_1_KEY_1_POS + addnum + 5 * i;
        snprintf(tempbuf, 8, "%d", tmpint);
        //curPos = atoi( nvram_my_get(tempbuf) );
	curPos = nvram_my_get(tempbuf);

        len =  strlen(curNumber) + strlen(curName) + strlen(curPos) + 128;
        temp = malloc( len );
        if(!count)
        {
            snprintf(temp, len, "{\"name\":\"%s\",\"number\":\"%s\",\"acct\":\"%d\",\"mode\":\"%d\",\"pos\":\"%s\"}", curName, curNumber, curAcct, curMode, curPos);
        }
        else
        {
            snprintf(temp, len, ",{\"name\":\"%s\",\"number\":\"%s\",\"acct\":\"%d\",\"mode\":\"%d\",\"pos\":\"%s\"}", curName, curNumber, curAcct, curMode, curPos);
        }
        buffer_append_string(b, temp);
        free(temp);
  		count ++;
	}
	buffer_append_string(b, "]}");
	
}

static int handle_getblf(buffer *b, const struct message *m)
{
    //const char *sqlstr = NULL;

    sqlite3 *db;
    int rc;
    char * errmsg = NULL;
    char **dbResult;
    int nRow, nColumn;
    int i , j, count = 0, isTone = 0;
    int index, len;
    char *temp = NULL, *name = NULL;

    rc = sqlite3_open("/data/data/com.base.module.mpk/databases/mpk.db", &db);
	
    if( rc ){
        printf(stderr, "Can't open database: %s\n", sqlite3_errmsg(db));
        sqlite3_close(db);
        return 0;
    }
    printf("db open suc\n");
    /*rc = sqlite3_exec(db, sqlstr, callback, 0, &errmsg);
    if( rc!=SQLITE_OK )
    {
        printf(stderr, "SQL error: %s\n", errmsg);
        sqlite3_free(errmsg);
    }*/
    temp = msg_get_header(m, "mpkindex");
    int mpkindex = atoi(temp);
    int nametype = 0;
	int fromserv = 0;
    //nametype = get_blf_nametype(mpkindex);
	get_blf_nametype(mpkindex, &nametype, &fromserv);

    int blfcount = 0;

	/*
    temp = malloc( 64 );
    snprintf(temp, 64, "select * from mpkinfo where mode=1;");
    rc = sqlite3_get_table ( db, temp , &dbResult, &nRow, &nColumn, &errmsg );
    free(temp);
    if( rc == SQLITE_OK )
    {
        blfcount = nRow;
    }else
    {
        printf(stderr, "SQL error: %s\n", errmsg);
        sqlite3_free(errmsg);
    }*/

    temp = malloc( 64 );
    //snprintf(temp, 64, "select * from mpkinfo where showpalce=%d order by sortindex;", mpkindex);
    snprintf(temp, 64, "select * from mpkinfo order by sortindex;");
    printf("temps is %s\n", temp);
    rc = sqlite3_get_table ( db, temp , &dbResult, &nRow, &nColumn, &errmsg );
    free(temp);
    char *curId = NULL, *curNumber = NULL, *curName = NULL;
    int curAcct, curMode;
    if( rc == SQLITE_OK )
    {
		blfcount = nRow;
        index = nColumn;
        printf( "query %d records, nColumn is %d.\n", nRow, nColumn );
        temp = malloc( 128 );
        snprintf(temp, 128, "{\"Response\":\"Success\",\"nametype\":\"%d\",\"fromserv\":\"%d\",\"blfcount\":\"%d\",\"Data\":[", nametype, fromserv, blfcount);
        buffer_append_string(b, temp);
        free(temp);
        for( i = 0; i < nRow ; i++ )
        {
            printf("Record %d:\n" , i+1 );
            for( j = 0 ; j < nColumn; j++ )
            {
                if( !strcasecmp(dbResult[j], "id") )
                {
                    curId = strdup(dbResult[index]);
                }
                else if( !strcasecmp(dbResult[j], "number") )
                {
                    curNumber = strdup(dbResult[index]);
                }else if( !strcasecmp(dbResult[j], "displayname") )
                {
                	curName = strdup(dbResult[index]);
                }else if( !strcasecmp(dbResult[j], "gsaccount") )
                {
                    curAcct = atoi(dbResult[index]);
                }else if( !strcasecmp(dbResult[j], "mode") )
                {
                    curMode = atoi(dbResult[index]);
                }
                ++index;
            }
            if( curNumber != NULL )
            {
            	len =  strlen(curNumber) + strlen(curName) + 64;
                temp = malloc( len );
                if(!count)
                {
                    snprintf(temp, len, "{\"id\":\"%s\",\"name\":\"%s\",\"number\":\"%s\",\"acct\":\"%d\",\"mode\":\"%d\"}", curId, curName, curNumber, curAcct, curMode);
                }
                else
                {
                    snprintf(temp, len, ",{\"id\":\"%s\",\"name\":\"%s\",\"number\":\"%s\",\"acct\":\"%d\",\"mode\":\"%d\"}", curId, curName, curNumber, curAcct, curMode);
                }
                count++;
                buffer_append_string(b, temp);
                free(curId);
                free(curName);
                free(curNumber);
                free(temp);
            }
        }
        buffer_append_string(b, "]}");
    }else
    {
        printf(stderr, "SQL error: %s\n", errmsg);
        sqlite3_free(errmsg);
    }
    sqlite3_free_table ( dbResult );
    sqlite3_close(db);
    
    return 1;
    
}

static int dbus_send_string ( const char *dbusname )
{
#ifdef BUILD_ON_ARM
    DBusMessage* message;

    if ( bus == NULL )
    {
        printf( "Error: Dbus bus is NULL\n" );
        return 1;
    }

    message = dbus_message_new_signal( DBUS_PATH, DBUS_INTERFACE, dbusname);
    if ( message == NULL )
    {
        printf( "message is NULL\n");
        return 1;
    }

    dbus_message_append_args( message, DBUS_TYPE_INVALID );

    dbus_connection_send( bus, message, NULL );
    dbus_message_unref( message );
#endif

    return 0;
}

static int dbus_send_mpk_order ( const int arg1, const int arg2, const int arg3 )
{
#ifdef BUILD_ON_ARM
    DBusMessage* message;

    if ( bus == NULL )
    {
        printf( "Error: Dbus bus is NULL\n" );
        return 1;
    }

    message = dbus_message_new_signal( DBUS_PATH, DBUS_INTERFACE, SIGNAL_BLFREORDER);
    if ( message == NULL )
    {
        printf( "message is NULL\n");
        return 1;
    }

    dbus_message_append_args( message, DBUS_TYPE_INT32, &arg1, DBUS_TYPE_INT32, &arg2, DBUS_TYPE_INT32, &arg3, DBUS_TYPE_INVALID );

    dbus_connection_send( bus, message, NULL );
    dbus_message_unref( message );
#endif

    return 0;
}

static int dbus_send_mpkext_order (const int arg1, const int arg2, const int arg3)
{
	DBusMessage* message;
	
	if( bus == NULL )
	{
		printf( "Error: Dbus bus is NULL\n" );
		return 1;
	}

	message = dbus_message_new_signal( DBUS_PATH, DBUS_INTERFACE, SIGNAL_BLFEXTREORDER);
	if( message == NULL)
	{
		printf( "message is NULL\n" );
		return 1;
	}

	dbus_message_append_args( message, DBUS_TYPE_INT32, &arg1, DBUS_TYPE_INT32, &arg2, DBUS_TYPE_INT32, &arg3, DBUS_TYPE_INVALID );

	dbus_connection_send (bus, message, NULL );
	dbus_message_unref( message );

	return 0;
}

static int dbus_send_blf_int ( const char *dbusname, const int arg1 )
{
#ifdef BUILD_ON_ARM
    DBusMessage* message;

    if ( bus == NULL )
    {
        printf( "Error: Dbus bus is NULL\n" );
        return 1;
    }

    message = dbus_message_new_signal( DBUS_PATH, DBUS_INTERFACE, dbusname);
    if ( message == NULL )
    {
        printf( "message is NULL\n");
        return 1;
    }

    dbus_message_append_args( message, DBUS_TYPE_INT32, &arg1, DBUS_TYPE_INVALID );

    dbus_connection_send( bus, message, NULL );
    dbus_message_unref( message );
#endif

    return 0;
}

static int dbus_send_blf_uri_updated ( const int arg1, const int arg2, const char* arg3 )
{
#ifdef BUILD_ON_ARM
    DBusMessage* message;

    if ( bus == NULL )
    {
        printf( "Error: Dbus bus is NULL\n" );
        return 1;
    }

    message = dbus_message_new_signal( DBUS_PATH, DBUS_INTERFACE, SIGNAL_MPKURIUPDATED);
    if ( message == NULL )
    {
        printf( "message is NULL\n");
        return 1;
    }

    dbus_message_append_args( message, DBUS_TYPE_INT32, &arg1, DBUS_TYPE_INT32, &arg2, DBUS_TYPE_STRING, &arg3, DBUS_TYPE_INVALID );

    dbus_connection_send( bus, message, NULL );
    dbus_message_unref( message );
#endif

    return 0;
}

static int dbus_send_blf_string ( const char *dbusname, const char* arg1 )
{
#ifdef BUILD_ON_ARM
    DBusMessage* message;

    if ( bus == NULL )
    {
        printf( "Error: Dbus bus is NULL\n" );
        return 1;
    }

    message = dbus_message_new_signal( DBUS_PATH, DBUS_INTERFACE, dbusname);
    if ( message == NULL )
    {
        printf( "message is NULL\n");
        return 1;
    }

    dbus_message_append_args( message, DBUS_TYPE_STRING, &arg1, DBUS_TYPE_INVALID );

    dbus_connection_send( bus, message, NULL );
    dbus_message_unref( message );
#endif

    return 0;
}

static int dbus_send_blf_nametype_updated (const int extindex, const int nametype, const int isfromserv)
{
	DBusMessage* message;
	
	dbus_bool_t bool_fromserv;

	if( bus == NULL )
	{
		printf( "Error: Dbus bus is NULL\n" );
		return 1;
	}

	message = dbus_message_new_signal( DBUS_PATH, DBUS_INTERFACE, SIGNAL_BLFNAMEUPDATED );
	if( message ==NULL )
	{
		printf( "message is NULL\n" );
		return 1;
	}

	if (isfromserv == 0)
		bool_fromserv = false;
	else
		bool_fromserv = true;

	dbus_message_append_args( message, DBUS_TYPE_INT32, &extindex, DBUS_TYPE_INT32, &nametype, DBUS_TYPE_BOOLEAN, &bool_fromserv, DBUS_TYPE_INVALID);
	dbus_connection_send( bus, message, NULL);
	dbus_message_unref(message);

	return 0;
}

static int dbus_send_mpkext_data_updated ( const int nvramindex )
{ 
	DBusMessage* message;
	
	if( NULL == bus )
	{
		printf( "Error:Dbus bus is NULL\n" );
		return 1;
	}

	message = dbus_message_new_signal( DBUS_PATH, DBUS_INTERFACE, SIGNAL_MPKEXTDATAUPDATED );
	if( NULL == message )
	{
		printf( "message is NULL\n" );
		return 1;
	}

	dbus_message_append_args( message, DBUS_TYPE_INT32, &nvramindex, DBUS_TYPE_INVALID);
	dbus_connection_send( bus, message, NULL);
	dbus_message_unref( message );

	return 0;
}

static int dbus_send_mpk_data_updated ( const int type, const int opindex, const int acct, const char* name, const char* number, const int mode, const int extIndex )
{
	printf("type:%d, opindex:%d, acct:%d, name:%s, number:%s, mode:%d, extindex: %d\n", type, opindex, acct, name, number, mode, extIndex);
#ifdef BUILD_ON_ARM
    DBusMessage* message;

    if ( bus == NULL )
    {
        printf( "Error: Dbus bus is NULL\n" );
        return 1;
    }

    message = dbus_message_new_signal( DBUS_PATH, DBUS_INTERFACE, SIGNAL_MPKDATAUPDATED);
    if ( message == NULL )
    {
        printf( "message is NULL\n");
        return 1;
    }

    dbus_message_append_args( message, DBUS_TYPE_INT32, &type,
    								DBUS_TYPE_INT32, &opindex, 
    								DBUS_TYPE_INT32, &acct, 
    								DBUS_TYPE_STRING, &name, 
    								DBUS_TYPE_STRING, &number, 
    								DBUS_TYPE_INT32, &mode, 
    								DBUS_TYPE_INT32, &extIndex, 
    								DBUS_TYPE_INVALID );

    dbus_connection_send( bus, message, NULL );
    dbus_message_unref( message );
#endif

    return 0;
}

static int handle_putmpkorder(buffer *b, const struct message *m)
{
	const char *extIndex = NULL;
    extIndex = msg_get_header(m, "extIndex");
    
    const char *fromIndex = NULL;
    fromIndex = msg_get_header(m, "from");
    
    const char *toIndex = NULL;
    toIndex = msg_get_header(m, "to");
    
    buffer_append_string (b, "Response=Success\r\n");
    dbus_send_mpk_order( atoi(extIndex), atoi(fromIndex), atoi(toIndex) );
}

static int handle_putmpkext(buffer *b, const struct message *m)
{
	int extindex = 0;
	int nametype = 0;
	int isfromserv = 0;
	char *temp = NULL;

	temp = msg_get_header(m, "extIndex");
	if ( temp!= NULL)
		extindex = atoi(temp);
	else 
	{
		buffer_append_string (b, "Response=Error\r\n");
        return 0;
	}
	
	temp = msg_get_header(m, "nametype");
	nametype = atoi(temp);

	temp = msg_get_header(m, "fromserv");
	isfromserv = atoi(temp);

	dbus_send_blf_nametype_updated(extindex, nametype, isfromserv);
	buffer_append_string (b, "Response=Success\r\n");
}

static int handle_putmpk(buffer *b, const struct message *m)
{
    char *temp = NULL, *tempbuf = NULL, *urivalue = NULL;
    int extindex = 0;
    int nametype = 0;
    
    temp = msg_get_header(m, "extIndex");
    if( temp != NULL )
        extindex = atoi(temp);
    else
    {
    	buffer_append_string (b, "Response=Error\r\n");
    	return 0;
    }
    
    //temp = msg_get_header(m, "nametype");

    //nametype = atoi(temp);
    //dbus_send_blf_nametype_updated(extindex, nametype);
	
    //buffer_append_string (b, "Response=Success\r\n");

    urivalue = msg_get_header(m, "urivalue");
    temp = msg_get_header(m, "uripos");
    nvram_set(temp, urivalue);
  
    nvram_commit();

    dbus_send_blf_int( SIGNAL_BLFUPDATED, -1);
    dbus_send_applyed();

    if( urivalue != NULL )
    {
        uri_decode(urivalue);
        dbus_send_blf_uri_updated( atoi(msg_get_header(m, "uriacct")), extindex, urivalue);
    }
	buffer_append_string (b, "Response=Success\r\n");

    return 1;
}

static int handle_putblfext(buffer *b, const struct message *m)
{
    const char *optype = NULL, *number = NULL, *name = NULL, *acct = NULL, *mode = NULL, *pos = NULL, *eventlist = NULL, *temp = NULL;
    int type, opindex, extIndex, posIndex, nvramIndex, exchangeIndex, isExchange, isDataChanged;

    optype = msg_get_header(m, "type");
    opindex = atoi(msg_get_header(m, "index"));
    extIndex = atoi(msg_get_header(m, "extIndex"));
    pos = msg_get_header(m, "posIndex");
    posIndex = atoi(pos);
    int addnum = 5 * ( posIndex - 1 ) + 200 * extIndex;
    nvramIndex = 40 * extIndex + ( posIndex -1 );
    int tempindex;
    char tempbuf[8] = "";
    if ( optype != NULL )
    {
        if( !strcasecmp(optype, "add") || !strcasecmp(optype, "edit") )
        {
            //type = 0;
            acct = msg_get_header(m, "acct");
            name = msg_get_header(m, "name");
            uri_decode(name);
            number = msg_get_header(m, "id");
            uri_decode(number);
            mode = msg_get_header(m, "mode");
            tempindex = P_VALUE_EXT_1_KEY_1_MODE + addnum;
            snprintf(tempbuf, 8, "%d", tempindex);
            printf("tempbuf is :%d/ %s\n", tempindex, tempbuf);
			nvram_set(tempbuf, mode);

            tempindex = P_VALUE_EXT_1_KEY_1_ACCT + addnum;
            snprintf(tempbuf, 8, "%d", tempindex);
            nvram_set(tempbuf, acct);

            tempindex = P_VALUE_EXT_1_KEY_1_ID + addnum;
            snprintf(tempbuf, 8, "%d", tempindex);
            nvram_set(tempbuf, number);

            tempindex = P_VALUE_EXT_1_KEY_1_NAME + addnum;
            snprintf(tempbuf, 8, "%d", tempindex);
            nvram_set(tempbuf, name);

            tempindex = P_VALUE_EXT_1_KEY_1_POS + addnum;
            snprintf(tempbuf, 8, "%d", tempindex);
	    	if(!strcmp(mode, "3")) 
	    	{
				eventlist = msg_get_header(m, "eventlist");
            	nvram_set(tempbuf, eventlist);
	    	}
		    else
				nvram_set(tempbuf, pos);

            //dbus_send_mpk_data_updated(type, opindex, acct, name, number, mode, extIndex);
        }
        else if( !strcasecmp(optype, "delete") )
        {
            //type = 1;
            tempindex = P_VALUE_EXT_1_KEY_1_MODE + addnum;
            snprintf(tempbuf, 8, "%d", tempindex);
            nvram_set(tempbuf, "");

            tempindex = P_VALUE_EXT_1_KEY_1_ACCT + addnum;
            snprintf(tempbuf, 8, "%d", tempindex);
            nvram_set(tempbuf, "");

            tempindex = P_VALUE_EXT_1_KEY_1_ID + addnum;
            snprintf(tempbuf, 8, "%d", tempindex);
            nvram_set(tempbuf, "");

            tempindex = P_VALUE_EXT_1_KEY_1_NAME + addnum;
            snprintf(tempbuf, 8, "%d", tempindex);
            nvram_set(tempbuf, "");

            tempindex = P_VALUE_EXT_1_KEY_1_POS + addnum;
            snprintf(tempbuf, 8, "%d", tempindex);
            nvram_set(tempbuf, "");
            //dbus_send_mpk_data_updated(type, opindex, "", "", "", 0, extIndex);
		}

#ifdef BUILD_ON_ARM
		nvram_commit();
#endif

		temp = msg_get_header(m, "isexchange");
		isExchange = atoi(temp);
		if( !strcasecmp(optype, "edit") && isExchange == 1 ) {
			temp = msg_get_header(m, "exchangepos");
			exchangeIndex = 40 * extIndex + ( atoi(temp)-1 );
			//dbus_send_mpkext_order( nvramIndex, exchangeIndex );
		
			temp = msg_get_header(m, "isdatachanged");
			isDataChanged = atoi(temp);
			if(isDataChanged == 1)
				//dbus_send_mpkext_data_updated(exchangeIndex);
				dbus_send_mpkext_order( nvramIndex, exchangeIndex, 1);
			else
				dbus_send_mpkext_order( nvramIndex, exchangeIndex, 0);
		}else if ( isExchange == -1 )
			dbus_send_mpkext_data_updated ( nvramIndex );

    	buffer_append_string (b, "Response=Success\r\n");
    }else
    {
    	buffer_append_string (b, "Response=Error\r\n");
    }
}

static int handle_putblf(buffer *b, const struct message *m)
{
    const char *optype = NULL, *number = NULL, *name = NULL;
    int type, opindex, extIndex, acct, mode;
    
    optype = msg_get_header(m, "type");
    opindex = atoi(msg_get_header(m, "index"));
    extIndex = atoi(msg_get_header(m, "extIndex"));
    if ( optype != NULL )
    {
    	if( !strcasecmp(optype, "add") )
    	{
    		type = 0;
    		acct = atoi(msg_get_header(m, "acct"));
    		name = msg_get_header(m, "name");
            uri_decode(name);
            number = msg_get_header(m, "id");
            uri_decode(number);
    		mode = atoi( msg_get_header(m, "mode") );
    		dbus_send_mpk_data_updated(type, opindex, acct, name, number, mode, extIndex);
    	}
    	else if( !strcasecmp(optype, "edit") )
    	{
    		type = 2;
    		acct = atoi(msg_get_header(m, "acct"));
    		name = msg_get_header(m, "name");
            uri_decode(name);
            number = msg_get_header(m, "id");
            uri_decode(number);
            mode = atoi( msg_get_header(m, "mode") );
    		dbus_send_mpk_data_updated(type, opindex, acct, name, number, mode, extIndex);
    	}
    	else if( !strcasecmp(optype, "delete") )
    	{
    		type = 1;
    		dbus_send_mpk_data_updated(type, opindex, 0, "", "", 0, extIndex);
    	}
    	buffer_append_string (b, "Response=Success\r\n");
    }else
    {
    	buffer_append_string (b, "Response=Error\r\n");
    }
}

static int handle_applyresponse (buffer *b)
{
    char res[32] = "";

    buffer_append_string (b, "Response=Success\r\n");

    snprintf(res, sizeof(res), "phrebootresponse=%d\r\n", phonerebooting);
    buffer_append_string(b, res);

    return 0;
}

static int handle_applypvalue(buffer *b)
{
    if( phonerebooting )
    {
        buffer_append_string(b, "Response=Error\r\n");
        return 0;
    }

    int result = apply_cache_pvalue(0);
    if(result != 0)
    {
        buffer_append_string(b, "Response=Error\r\n");
    }
    else
    {
        buffer_append_string(b, "Response=Success\r\n");
        dbus_send_cfupdated();
        dbus_send_applyed();
    }
    return 1;
}

static int handle_put(buffer *b, const struct message *m)
{
    const char *resType = NULL;
    char *temp = NULL;
    const char * jsonCallback = NULL;

    resType = msg_get_header(m, "format");

    if( phonerebooting )
    {
        if((resType != NULL) && !strcasecmp(resType, "json"))
        {
            jsonCallback = msg_get_header( m, "jsoncallback" );

            if(jsonCallback != NULL)
            {
                temp = malloc(128 + strlen(jsonCallback));
                snprintf(temp, 128 + strlen(jsonCallback),
                         "%s(%s)", jsonCallback, "{\"res\": \"error\", \"msg\" : \"phone rebooting\"}");
            }
            else
            {
                temp = malloc(128);
                snprintf(temp, 128, "%s", "{\"res\": \"error\", \"msg\" : \"phone rebooting\"}");
            }
                
            buffer_append_string( b, temp );
            free(temp);
        }
        else
        {
            buffer_append_string(b, "Response=Error\r\n");
        }

        return -1;
    }

    int x;
    int wfile = 1;
    int cfdbus = 1;
    char hdr[64] = "";
    char *val = NULL;
    const char *var = NULL, *tempval= NULL;

    var = msg_get_header(m, "flag");
	
    int tmpflag = 1;
    if ( var != NULL )
    {
        wfile = atoi(var);
        tmpflag = wfile;
        printf("var is %s, wfile is %d\n", var, wfile);
        if( wfile == 2 )
        {
            cfdbus = 0;
            wfile = 0;
        }   
    }
    else
    {
        wfile = 0;
        tmpflag = 1;
    }
    
    /*if ( !wfile )
    {
        if( !access(TEMP_PVALUES, 0) )
        {
            tmpflag = 1;
        }
    }*/

    if((resType != NULL) && !strcasecmp(resType, "json"))
    {
        jsonCallback = msg_get_header( m, "jsoncallback" );

        if(jsonCallback != NULL)
        {
            temp = malloc(128 + strlen(jsonCallback));
            snprintf(temp, 128 + strlen(jsonCallback),
                     "%s({\"res\": \"success\", \"flag\" : \"%d\"})", jsonCallback, tmpflag);
        }
        else
        {
            temp = malloc(128);
            snprintf(temp, 128, "{\"res\": \"success\", \"flag\" : \"%d\"}", tmpflag);
        }
                
        buffer_append_string( b, temp );
        free(temp);
    }
    else
    {
        snprintf(hdr, sizeof(hdr), "Response=Success\r\nflag=%d", tmpflag);
        buffer_append_string(b, hdr);
    }

    for (x = 0; x < 10000; x++) {
        snprintf(hdr, sizeof(hdr), "var-%04d", x);
        var = msg_get_header(m, hdr);
        if ( (var == NULL) )
        {
            break;
        }else if( protected_pvalue_find(pvalue_protect, (char *) var) )
        {
            continue;
        }
        snprintf(hdr, sizeof(hdr), "val-%04d", x);
        tempval = msg_get_header(m, hdr);
	if(tempval == NULL){
	break;
	}
        val = malloc(strlen(tempval) + 16);
        memset(val, 0, strlen(tempval) + 16);
        strncpy(val, tempval, strlen(tempval));
        uri_decode(val);
        if( wfile )
        {
            pvalue_cache = pvaluelist_append(pvalue_cache, var, val );
             printf("put var is %s, val is %s\n", var, val );
        }
        else
        {
#ifdef BUILD_ON_ARM
            nvram_set(var, val);
#endif
        }
        free(val);
    } 
    if( wfile )
    {
        if( access(DATA_DIR, 0) ) {
            mkdir(DATA_DIR, 0755);
        }
        if( access(DATATMP_DIR, 0) ) {
            mkdir(DATATMP_DIR, 0755);
        }
        FILE *file_fd = NULL;
        file_fd = fopen(TEMP_PVALUES, "w+");

        if (file_fd != NULL)
        {
            PvalueList *curPtr = pvalue_cache;
            char *strToWrite = malloc( 512 );
            memset(strToWrite, 0, 512);
            int sizeOfStrToWrite = 512;

            while ( curPtr != NULL )
            {
                int newsize = strlen( strToWrite ) + strlen(curPtr->pvalue ) + strlen(curPtr->data )  + 4;
                printf("newsize is %d\n" , newsize );
                if ( sizeOfStrToWrite < newsize  )
                {
                    strToWrite = realloc( strToWrite, newsize );
                }
                snprintf( hdr, sizeof(hdr), "%s=%s\n", (curPtr->pvalue ), (curPtr->data ) );
                strcat( strToWrite, hdr );
                curPtr = curPtr->next;
            }
            printf(" add content %s to file\n", strToWrite );
            fwrite( strToWrite, 1, strlen(strToWrite), file_fd );
            fclose( file_fd );
            sync();
        }
    }
    else
    {
#ifdef BUILD_ON_ARM
        nvram_commit();
#endif
        if( cfdbus )
            dbus_send_cfupdated();
    }   

    return 0;
}

static int get_mac_address(char *ifname, char *mac)
{
    struct ifreq ifr;
    int fd;

    if (mac == NULL) {
        return -1;
    }
    strcpy (mac, "none");

    fd = socket(AF_INET, SOCK_DGRAM, 0);
    if (fd >= 0) {
        strcpy(ifr.ifr_name, ifname);
        if (ioctl (fd, SIOCGIFHWADDR, &ifr) == 0) {
            sprintf(mac, "%02x-%02x-%02x-%02x-%02x-%02x", 
                    (unsigned char)ifr.ifr_hwaddr.sa_data[0],
                    (unsigned char)ifr.ifr_hwaddr.sa_data[1],
                    (unsigned char)ifr.ifr_hwaddr.sa_data[2],
                    (unsigned char)ifr.ifr_hwaddr.sa_data[3],
                    (unsigned char)ifr.ifr_hwaddr.sa_data[4],
                    (unsigned char)ifr.ifr_hwaddr.sa_data[5]);
            close( fd );
            return 0;
        }

        close( fd );
    }
    
    return -1;
}

static int get_gateway(char *gateway)
{
    FILE *fp = fopen("/proc/net/route", "r");
    char line[256] = "";
    //size_t len = 0;
    //ssize_t readd;
    char dev[64];
    unsigned int dest;
    unsigned int gw;

    if (fp == NULL)
        return -1;

    if (gateway == NULL) {
        fclose( fp );
        return -1;
    }
    strcpy (gateway, "none");

    //while ((readd = getline (&line, &len, fp)) != -1) {
    while (fgets( &line, sizeof(line), fp ) ) {
        if (sscanf (line, "%s %x %x", dev, &dest, &gw) > 0) {
            if (dest == 0x0) {
                gw = ntohl (gw);
                sprintf (gateway, "%u.%u.%u.%u", (gw >> 24) & 0xff,
                        (gw >> 16) & 0xff,
                        (gw >> 8) & 0xff,
                        gw & 0xff);
                
                memset(line, 0, sizeof(line));
                fclose( fp );
                return 0;
            }
        }
    }

    /*if (line != NULL) {
        free(line);
        line = NULL;
    }*/
 
    fclose( fp );
    return -1;
}

static int get_dns_server(char *dns_server)
{
    system("getprop net.dns1 > /tmp/dns");
    FILE *fp = fopen("/tmp/dns", "r");
    char line[32] = "";

    if (fp == NULL)
        return -1;
        
    if (dns_server == NULL) {
        fclose( fp );
        return -1;
    }
    strcpy(dns_server, "none");

    while (fgets( &line, sizeof(line), fp ) ) {
            if(line[strlen(line)-1] == '\n'){
                line[strlen(line)-1] = '\0';
            }
        strcpy (dns_server, line);
    }
    fclose(fp);

    return 0;
}

static int get_dns2_server(char *dns_server)
{
    system("getprop net.dns2 > /tmp/dns");
    FILE *fp = fopen("/tmp/dns", "r");
    char line[32] = "";

    if (fp == NULL)
        return -1;

    if (dns_server == NULL) {
        fclose( fp );
        return -1;
    }
    strcpy(dns_server, "none");

    while (fgets( &line, sizeof(line), fp ) ) {
        if(line[strlen(line)-1] == '\n'){
            line[strlen(line)-1] = '\0';
        }
        strcpy (dns_server, line);
    }
    fclose(fp);

    return 0;
}

static void print_iter( DBusMessage *message, int depth)
{
    DBusMessageIter iter;
    int current_type;
    dbus_uint32_t valuint32;
    dbus_int32_t valint32;
    char* valstring;
    dbus_bool_t valbool;
    
     dbus_message_iter_init (message, &iter);
     while ((current_type = dbus_message_iter_get_arg_type (&iter)) != DBUS_TYPE_INVALID)
     {
        switch ( current_type )
        {
            case DBUS_TYPE_UINT32:
                dbus_message_iter_get_basic(&iter, &valuint32);
                printf( "unint 32 type, %d\n", valuint32 );
                break;

            case DBUS_TYPE_INT32:
                dbus_message_iter_get_basic(&iter, &valint32);
                printf( "nint 32 type, %d\n", valint32 );
                break;

            case DBUS_TYPE_STRING:
                dbus_message_iter_get_basic(&iter, &valstring);
                printf( "string type, %s\n", valstring );
                break;

            case DBUS_TYPE_BOOLEAN:
                dbus_message_iter_get_basic(&iter, &valbool);
                printf( "boolean type, %d\n", valbool );
                break;
                
            default:
                break;
        }

        dbus_message_iter_next (&iter);
    }
}

static void print_message (DBusMessage *message )
{
    const char *sender;
    const char *destination;
    int message_type;
    message_type = dbus_message_get_type( message );
    sender = dbus_message_get_sender( message );
    destination = dbus_message_get_destination( message );
    print_iter ( message, 1);
}


static int handle_endcall(server *srv, connection *con, buffer *b, const struct message *m)
{
#ifdef BUILD_ON_ARM
    DBusMessage* message = NULL;
    DBusError error;
    DBusMessageIter iter;
    DBusBusType type;
    int reply_timeout = 3000;
    DBusMessage *reply = NULL;
    DBusConnection *conn = NULL;
    char *temp = NULL;
    int lineIndex = -1;
    char res[128] = "";
    char *info = NULL;
    
    temp = msg_get_header(m, "line");
    if ( temp  == NULL ) {
        lineIndex = -1;
    } else {
        lineIndex = atoi(temp);
    }

    type = DBUS_BUS_SYSTEM;
    dbus_error_init (&error);
    conn = dbus_bus_get (type, &error);
    if (conn == NULL)
    {
        printf ( "Failed to open connection to %s message bus: %s\n", (type == DBUS_BUS_SYSTEM) ? "system" : "session", error.message);
        dbus_error_free (&error);
        return -1;
    }

    fprintf(stderr, "handle_endCall\n");
    message = dbus_message_new_method_call( dbus_dest, dbus_path, dbus_interface, "endCall" );

    if (message != NULL)
    {
        dbus_message_set_auto_start (message, TRUE);
        dbus_message_iter_init_append( message, &iter );

        if ( !dbus_message_iter_append_basic( &iter, DBUS_TYPE_INT32, &lineIndex ) )
        {
            printf( "Out of Memory!\n" );
            exit( 1 );
        }

        //dbus_message_iter_append_basic(&iter,DBUS_TYPE_INVALID);
        dbus_message_append_args( message,  DBUS_TYPE_INVALID );

        dbus_error_init( &error );
        reply = dbus_connection_send_with_reply_and_block( conn, message, reply_timeout, &error );
        if ( dbus_error_is_set( &error ) )
        {
            fprintf(stderr, "Error %s: %s\n",
                error.name,
                error.message);
        }

        if ( reply )
        {
            print_message( reply );
            int current_type;
            char *res = NULL;
            dbus_message_iter_init( reply, &iter );

            while ( ( current_type = dbus_message_iter_get_arg_type( &iter ) ) != DBUS_TYPE_INVALID )
            {
                switch ( current_type )
                {
                    case DBUS_TYPE_STRING:
                        dbus_message_iter_get_basic(&iter, &res);
                        break;

                    default:
                        break;
                }

                dbus_message_iter_next (&iter);
            }

            if ( res != NULL )
            {
                info = (char*)malloc((1+ strlen(res)) * sizeof(char));
                sprintf(info, "%s", res);
                temp = info;
            }
            else
            {
                temp = "{\"res\": \"error\", \"msg\": \"can't end call\"}";
            }

            temp = build_JSON_formate( srv, con, m, temp );

            if(info != NULL)
            {
                free(info);
            }

            if ( temp != NULL )
            {
                buffer_append_string( b, temp );
                free(temp);
            }
            dbus_message_unref( reply );
        }

        dbus_message_unref( message );
    }
#endif
    return 0;
}

static int handle_getLineStatus(server *srv, connection *con, buffer *b, const struct message *m)
{
printf("  handle_getLineStatus \r\n");
#ifdef BUILD_ON_ARM
    DBusMessage* message = NULL;
    DBusError error;
    DBusMessageIter iter;
    DBusBusType type;
    int reply_timeout = 3000;
    DBusMessage *reply = NULL;
    DBusConnection *conn = NULL;
    char *temp = NULL;
    int lineIndex = 0;
    char res[128] = "";
    char *info = NULL;

    temp = msg_get_header(m, "line");
    if ( temp  == NULL || strlen(temp) == 0)
    {
        const char *resType = msg_get_header(m, "format");
        if ( (resType != NULL) && !strcasecmp( resType, "json" ) )
        {
            temp = "{\"res\": \"error\", \"msg\": \"line can't be null\"}";
            temp = build_JSON_res( srv, con, m, temp );
            buffer_append_string( b, temp );
            free(temp);
        }
        else
        {
            buffer_append_string (b, "Response=Error\r\n");
            snprintf(res, sizeof(res), "Message=line can't be null\r\n" );
            buffer_append_string(b, res);
        }
    }
    else
    {
        lineIndex = atoi(temp);
        if( lineIndex > 5 || lineIndex < 0 )
        {
          const char *resType = msg_get_header(m, "format");
              if ( (resType != NULL) && !strcasecmp( resType, "json" ) )
            {
                temp = "{\"res\": \"error\", \"msg\": \"line invalid\"}";
                temp = build_JSON_res( srv, con, m, temp );
                buffer_append_string( b, temp );
                free(temp);
            }
            else
            {
                buffer_append_string (b, "Response=Error\r\n");
                snprintf(res, sizeof(res), "Message=line invalid\r\n" );
                buffer_append_string(b, res);
            }
            return;
        }
        type = DBUS_BUS_SYSTEM;
        dbus_error_init (&error);
        conn = dbus_bus_get (type, &error);
        if (conn == NULL)
        {
            printf ( "Failed to open connection to %s message bus: %s\n", (type == DBUS_BUS_SYSTEM) ? "system" : "session", error.message);
            dbus_error_free (&error);
            return -1;
        }

        fprintf(stderr, "handle_lineStatus\n");
        message = dbus_message_new_method_call( dbus_dest, dbus_path, dbus_interface, "getLineStatus" );

        if (message != NULL)
        {
            dbus_message_set_auto_start (message, TRUE);
            dbus_message_iter_init_append( message, &iter );

            if ( !dbus_message_iter_append_basic( &iter, DBUS_TYPE_INT32, &lineIndex ) )
            {
                printf( "Out of Memory!\n" );
                exit( 1 );
            }
            //dbus_message_iter_append_basic(&iter,DBUS_TYPE_INVALID);
            dbus_message_append_args( message,  DBUS_TYPE_INVALID );

         //   dbus_error_init( &error );
            reply = dbus_connection_send_with_reply_and_block( conn, message, reply_timeout, &error );
            if ( dbus_error_is_set( &error ) )
            {
                fprintf(stderr, "Error %s: %s\n",
                    error.name,
                    error.message);
            }

            if ( reply )
            {
                print_message( reply );
                int current_type;
                char *res = NULL;
                dbus_message_iter_init( reply, &iter );

                while ( ( current_type = dbus_message_iter_get_arg_type( &iter ) ) != DBUS_TYPE_INVALID )
                {
                    switch ( current_type )
                    {
                        case DBUS_TYPE_STRING:
                            dbus_message_iter_get_basic(&iter, &res);
                            break;

                        default:
                            break;
                    }

                    dbus_message_iter_next (&iter);
                }

                if ( res != NULL )
                {
                    info = (char*)malloc((1+ strlen(res)) * sizeof(char));
                    sprintf(info, "%s", res);
                    temp = info;
                }
                else
                {
                    temp = "{\"res\": \"error\", \"msg\": \"can't get line status\"}";
                }

                temp = build_JSON_formate( srv, con, m, temp );

                if(info != NULL)
                {
                    free(info);
                }

                if ( temp != NULL )
                {
                    buffer_append_string( b, temp );
                    free(temp);
                }
                dbus_message_unref( reply );
            }

            dbus_message_unref( message );
        }
    }
#endif
    return 0;
}

static int handle_originatecall (server *srv, connection *con, 
    buffer *b, const struct message *m)
{
#ifdef BUILD_ON_ARM
    DBusMessage* message = NULL;
    DBusError error;
    DBusMessageIter iter;
    DBusBusType type;
    int reply_timeout = 3000;
    DBusMessage *reply = NULL;
    DBusConnection *conn = NULL;
    int account = 0;
    int isVideo = 0;
    int isDialPlan = 0;
    const char *num = NULL;
    const char *headerString = "";
    char *temp = NULL;
    char res[128] = "";

    num = msg_get_header(m, "destnum");

    if ( num  == NULL || strlen(num) == 0)
    {
        const char *resType = msg_get_header(m, "format");
        if ( (resType != NULL) && !strcasecmp( resType, "json" ) )
        {
            temp = "{\"res\": \"error\", \"msg\": \"destnum can't be null\"}";
            temp = build_JSON_res( srv, con, m, temp );
            buffer_append_string( b, temp );
            free(temp);
        }
        else
        {
            buffer_append_string (b, "Response=Error\r\n");
            snprintf(res, sizeof(res), "Message=Number can't be null\r\n" );
            buffer_append_string(b, res);
        }
    }
    else
    {
        type = DBUS_BUS_SYSTEM;
        dbus_error_init (&error);
        conn = dbus_bus_get (type, &error);
        if (conn == NULL)
        {
            printf ( "Failed to open connection to %s message bus: %s\n", (type == DBUS_BUS_SYSTEM) ? "system" : "session", error.message);
            dbus_error_free (&error);
            return -1;
        }

        fprintf(stderr, "handle_originatecall\n");
        message = dbus_message_new_method_call( dbus_dest, dbus_path, dbus_interface, "originateCall" );

        if (message != NULL)
        {
            dbus_message_set_auto_start (message, TRUE);
            dbus_message_iter_init_append( message, &iter );

            temp = msg_get_header(m, "account");
            if ( temp != NULL )
            {
                account = atoi( temp );
printf("account: %d\n", account);
printf("destnum: %s\n", num);
            }
            temp = msg_get_header(m, "isvideo");
             printf("isVideo: temp %s\n", temp);
            if ( temp != NULL )
            {
                if ( !strcasecmp( temp, "1" ) )
                {
                    isVideo = 1;
                }
            }
            printf("isVideo: %d\n", isVideo);

            temp = msg_get_header(m, "isdialplan");
            if ( temp != NULL )
            {
                if ( !strcasecmp( temp, "1" ) )
                {
                    isDialPlan = 1;
                }
            }
            temp = msg_get_header(m, "headerstring");
            if ( temp != NULL )
            {
                headerString = temp;
            }
            if ( !dbus_message_iter_append_basic( &iter, DBUS_TYPE_INT32, &account ) )
            {
                printf( "Out of Memory!\n" );
                exit( 1 );
            }
                if ( !dbus_message_iter_append_basic( &iter, DBUS_TYPE_INT32, &isVideo ) )
            {
                printf( "Out of Memory!\n" );
                exit( 1 );
            } 
            if ( !dbus_message_iter_append_basic( &iter, DBUS_TYPE_INT32, &isDialPlan ) )
            {
                printf( "Out of Memory!\n" );
                exit( 1 );
            } 
            if ( !dbus_message_iter_append_basic( &iter, DBUS_TYPE_STRING, &num ) )
            {
                printf( "Out of Memory!\n" );
                exit( 1 );
            } 
            if ( !dbus_message_iter_append_basic( &iter, DBUS_TYPE_STRING, &headerString ) )
            {
                printf( "Out of Memory!\n" );
                exit( 1 );
            } 
            //dbus_message_iter_append_basic(&iter,DBUS_TYPE_INVALID);
	    dbus_message_append_args( message,  DBUS_TYPE_INVALID );

            dbus_error_init( &error );
            reply = dbus_connection_send_with_reply_and_block( conn, message, reply_timeout, &error );
            if ( dbus_error_is_set( &error ) )
            {
                fprintf(stderr, "Error %s: %s\n",
                    error.name,
                    error.message);
            }

            if ( reply )
            {
                print_message( reply );
                int current_type;
                char *res2 = NULL;
                dbus_message_iter_init( reply, &iter );
                while ( ( current_type = dbus_message_iter_get_arg_type( &iter ) ) != DBUS_TYPE_INVALID )
                {
                    switch ( current_type )
                    {
                        case DBUS_TYPE_STRING:
                            dbus_message_iter_get_basic(&iter, &res2);
                            printf( "string type, %s\n", res2 );
                            break;
                            
                        default:
                            break;
                    }

                    dbus_message_iter_next (&iter);
                }
                if ( res2 != NULL )
                {
                    temp = "{\"res\": \"success\", \"msg\": \"call orinagated\"}";
                }
                else
                {
                    temp = "{\"res\": \"error\", \"msg\": \"timeout\"}";
                }
                temp = build_JSON_res( srv, con, m, temp );
                if ( temp != NULL )
                {
                    buffer_append_string( b, temp );
                    free(temp);
                }
                dbus_message_unref( reply );
            }
            dbus_message_unref( message );
        }
    }
#endif
    return 0;
}

static int handle_vendor (server *srv, connection *con, 
    buffer *b, const struct message *m)
{
    char res[128] = "";
    char buf[128] = "";
    FILE *sys_file;
    char *temp = NULL;
    int ret = -1;
    
    sys_file = fopen ("/proc/gxvboard/dev_info/vendor_fullname", "r");
    
    if (sys_file != NULL) {
        fread (buf, 127, 1, sys_file);
        fclose (sys_file);

        const char *resType = msg_get_header(m, "format");
        if ( (resType != NULL) && !strcasecmp( resType, "json" ) )
        {
            snprintf( res, sizeof( res ),
                    "%s: \"%s\"}", "{\"res\" : \"success\", \"vendor\" ", buf );
            temp = build_JSON_res( srv, con, m, res );
            buffer_append_string( b, temp );
            free(temp);
        }
        else
        {
            buffer_append_string (b, "Response=Success\r\n");
            snprintf(res, sizeof(res), "Vendor=%s\r\n", buf);
            buffer_append_string(b, res);
        }
        ret = 1;
    } else {
        const char *resType = msg_get_header(m, "format");
        if ( (resType != NULL) && !strcasecmp( resType, "json" ) )
        {
            snprintf( res, sizeof( res ),
                    "%s", "{\"res\": \"error\", \"msg\": \"can't get vendor\"}" );
            temp = build_JSON_res( srv, con, m, res );
            buffer_append_string( b, temp );
            free(temp);
        }
        else
        {
            buffer_append_string(b, "Response=Error\r\n"
                    "Message=Can't get vendor\r\n");
        }
        ret = -1;
    }

    return ret;
}

#endif

/*Duplicate with handle_product && handle_vendor for save http request purpose*/
static int handle_productinfo (server *srv, connection *con, 
    buffer *b, const struct message *m)
{
    char res[128] = "";
    char buf[128] = "";
    char vendorBuf[128] = "";
    FILE *sys_file;
    char * temp = NULL;

    sys_file = fopen ("/proc/gxvboard/dev_info/vendor_fullname", "r");
    
    if (sys_file != NULL) {
        fread (vendorBuf, 127, 1, sys_file);
        fclose (sys_file);
    }

    sys_file = fopen ("/proc/gxvboard/dev_info/dev_alias", "r");

    if (sys_file != NULL) {
        fread (buf, 127, 1, sys_file);
        fclose (sys_file);

        const char *resType = msg_get_header(m, "format");
        if ( (resType != NULL) && !strcasecmp( resType, "json" ) )
        {
            snprintf( res, sizeof( res ),
                    "%s: \"%s\", \"vendor\":\"%s\"}", "{\"res\": \"success\", \"product\" ", buf, vendorBuf );
            temp = build_JSON_res( srv, con, m, res );
            buffer_append_string( b, temp );
            free(temp);
        }
        else
        {
            buffer_append_string (b, "Response=Success\r\n");

            snprintf(res, sizeof(res), "Product=%s\r\nVendor=%s\r\n", buf, vendorBuf );
            buffer_append_string(b, res);
        }
        return 1;
    } else {
        const char *resType = msg_get_header(m, "format");
        if ( (resType != NULL) && !strcasecmp( resType, "json" ) )
        {
            snprintf( res, sizeof( res ),
                    "%s: \"%s\"}", "{\"res\": \"error\", \"msg\" ", "can't get product information" );
            temp = build_JSON_res( srv, con, m, res );
            buffer_append_string( b, temp );
            free(temp);
        }
        else
        {
            buffer_append_string(b, "Response=Error\r\n"
                    "Message=Can't get product model\r\n");
        }
        return -1;
    }

    return -1;
}

static int handle_product (server *srv, connection *con, 
    buffer *b, const struct message *m)
{
    char res[128] = "";
    char buf[128] = "";
    FILE *sys_file;
    char * temp = NULL;

    sys_file = fopen ("/proc/gxvboard/dev_info/dev_alias", "r");

    if (sys_file != NULL) {
        fread (buf, 127, 1, sys_file);
        fclose (sys_file);

        const char *resType = msg_get_header(m, "format");
        if ( (resType != NULL) && !strcasecmp( resType, "json" ) )
        {
            snprintf( res, sizeof( res ),
                    "%s: \"%s\"}", "{\"res\": \"success\", \"product\" ", buf );
            temp = build_JSON_res( srv, con, m, res );
            buffer_append_string( b, temp );
            free(temp);
        }
        else
        {
            buffer_append_string (b, "Response=Success\r\n");

            snprintf(res, sizeof(res), "Product=%s\r\n", buf);
            buffer_append_string(b, res);
        }
        return 1;
    } else {
        const char *resType = msg_get_header(m, "format");
        if ( (resType != NULL) && !strcasecmp( resType, "json" ) )
        {
            snprintf( res, sizeof( res ),
                    "%s: \"%s\"}", "{\"res\": \"error\", \"msg\" ", "can't get product model" );
            temp = build_JSON_res( srv, con, m, res );
            buffer_append_string( b, temp );
            free(temp);
        }
        else
        {
            buffer_append_string(b, "Response=Error\r\n"
                    "Message=Can't get product model\r\n");
        }
        return -1;
    }

    return -1;
}

static int handle_hardware (server *srv, connection *con, 
    buffer *b, const struct message *m)
{
    char res[128] = "";
    char buf[128] = "";
    FILE *sys_file;
    char *temp = NULL;
    
    sys_file = fopen ("/proc/gxvboard/dev_info/dev_rev", "r");
    
    if (sys_file != NULL) {
        fread (buf, 127, 1, sys_file);
        fclose (sys_file);

        const char *resType = msg_get_header(m, "format");
        if ( (resType != NULL) && !strcasecmp( resType, "json" ) )
        {
            snprintf( res, sizeof( res ),
                    "%s: \"%s\"}", "{\"res\": \"success\", \"hardware\" ", buf );
            temp = build_JSON_res( srv, con, m, res );
            buffer_append_string( b, temp );
            free(temp);
        }
        else
        {
            snprintf(res,sizeof(res), "Response=Success\r\nHardware=%s\r\n" , buf);
            buffer_append_string (b, res);
        }
        return 1;
    } else {
         const char *resType = msg_get_header(m, "format");
        if ( (resType != NULL) && !strcasecmp( resType, "json" ) )
        {
            snprintf( res, sizeof( res ),
                    "%s: \"%s\"}", "{\"res\": \"error\", \"msg\" ", "can't get hardware version" );
            temp = build_JSON_res( srv, con, m, res );
            buffer_append_string( b, temp );
            free(temp);
        }
        else
        {
            buffer_append_string (b, "Response=Error\r\n"
                    "Message=Can't get Hardware version\r\n");
        }
        return -1;
    }

    return -1;
}

static int start_daemon(void)
{
    /* Our process ID and Session ID */
    pid_t pid = -1, sid = -1;

    /* Fork off the parent process */
    pid = fork();
    if ( pid < 0 )
    {
        exit( -2 );
    }
    /* If we got a good PID, then
       we can exit the parent process. */
    if ( pid > 0 )
    {
//exit the parent process
        exit( 0 );
    }

    /* Change the file mode mask */
    umask(0);

    /* Open any logs here */

    /* Create a new SID for the child process */
    sid = setsid();
    if ( sid < 0 )
    {
/* Log the failure */
        exit( -2 );
    }

    /* Change the current working directory */
    if ( (chdir("/")) < 0 )
    {
/* Log the failure */
        exit( -2 );
    }

    /* Close out the standard file descriptors */
    close(STDIN_FILENO);
    close(STDOUT_FILENO);
    close(STDERR_FILENO);

    /* Daemon-specific initialization goes here */

    // Child process.
    if ( pid == 0 )
    {
        system("am broadcast --user all -a com.base.module.systemmanager.UPGRADE_OR_REBOOT --es type reboot");
    }

    exit(EXIT_SUCCESS);
}

static pid_t start_reboot( )
{
    //This process is used as daemon's parent, which will be ended when daemon is forked.
    pid_t pid = fork();

    // Fork error
    if ( pid == -1 )
    {
        return -1;
    }
    else if ( pid > 0 )
    {
        waitpid( pid, NULL, 0 );
    }
    // Child process.
    else if ( pid == 0 )
    {
        start_daemon();
    }

    return pid;
}

static int handle_reboot(buffer *b)
{
    buffer_append_string(b, "Response=Success\r\n"
            "Message=Reboot Success\r\n");

    start_reboot();

    return 0;
}

#ifndef BUILD_RECOVER
static int handle_pn (server *srv, connection *con, 
    buffer *b, const struct message *m)
{
    char res[128] = "";
    char buf[128] = "";
    FILE *sys_file;

    sys_file = fopen ( "/proc/gxvboard/dev_info/PN", "r" );
    
    if (sys_file != NULL) {
        fread (buf, 127, 1, sys_file);
        fclose (sys_file);
        const char *resType = msg_get_header(m, "format");
        if ( (resType != NULL) && !strcasecmp( resType, "json" ) )
        {
            snprintf( res, sizeof( res ),
                    "%s: \"%s\"}", "{\"res\": \"success\", \"pn\" ", buf );
            char *temp = build_JSON_res( srv, con, m, res );
            buffer_append_string( b, temp );
            free(temp);
        }
        else
        {
            buffer_append_string (b, "Response=Success\r\n");
            snprintf(res, sizeof(res), "PN=%s\r\n", buf );
            buffer_append_string(b, res);
        }
        return 1;
    } else {
        const char *resType = msg_get_header(m, "format");
        if ( (resType != NULL) && !strcasecmp( resType, "json" ) )
        {
            snprintf( res, sizeof( res ),
                    "%s: \"%s\"}", "{\"res\": \"error\", \"msg\" ", "can't get pn" );
            char *temp = build_JSON_res( srv, con, m, res );
            buffer_append_string( b, temp );
            free(temp);
        }
        else
        {
            buffer_append_string(b, "Response=Error\r\n"
                    "Message=Can't get PN\r\n");
        }
        return -1;
    }

    return 1;
}

static int handle_sn (server *srv, connection *con, 
    buffer *b, const struct message *m)
{
    char buf[128] = "";
    char res[128] = "";

    char pn[128] = "";
    FILE *sys_file = fopen ( "/proc/gxvboard/dev_info/PN", "r" );
    
    if (sys_file != NULL) 
    {
        fread (pn, 127, 1, sys_file);
        fclose (sys_file);
    }
    

    get_mac_address ("eth0", buf);
    const char *resType = msg_get_header(m, "format");
    if ( (resType != NULL) && !strcasecmp( resType, "json" ) )
    {
        if ( ( strcasestr( pn, "963-40017" ) != NULL ) || ( strcasestr( pn, "96340017" ) != NULL ) )
        {
            snprintf( res, sizeof( res ),
                    "%s: \"%s\"}", "{\"res\": \"success\", \"sn: 00100300YY0200100000\" ", buf );
        }
        else if ( ( strcasestr( pn, "963-50017" ) != NULL ) || ( strcasestr( pn, "96350017" ) != NULL ) )
        {
            snprintf( res, sizeof( res ),
                    "%s: \"%s\"}", "{\"res\": \"success\", \"sn: 00100300TF0200100000\" ", buf );
        }
        else if ( ( strcasestr( pn, "963-30017" ) != NULL ) || ( strcasestr( pn, "96330017" ) != NULL ) )
        {
            snprintf( res, sizeof( res ),
                    "%s: \"%s\"}", "{\"res\": \"success\", \"sn: 00100300SB0100100000\" ", buf );
        }
        else if ( ( strcasestr( pn, "963-20015" ) != NULL ) || ( strcasestr( pn, "96320015" ) != NULL ) 
			|| ( strcasestr( pn, "963-30015" ) != NULL ) || ( strcasestr( pn, "96330015" ) != NULL ) )
        {
            snprintf( res, sizeof( res ),
                    "%s: \"%s\"}", "{\"res\": \"success\", \"sn: 00100300ZX3100100000\" ", buf );
        }
        else if ( ( strcasestr( pn, "963-70017" ) != NULL ) || ( strcasestr( pn, "96370017" ) != NULL ) )
        {
            snprintf( res, sizeof( res ),
                    "%s: \"%s\"}", "{\"res\": \"success\", \"sn: 00100300ZX4100100000\" ", buf );
        }
        else
        {
            snprintf( res, sizeof( res ),
                    "%s: \"%s\"}", "{\"res\": \"success\", \"sn: 00100300CL0200100000\" ", buf );
        }
        char *temp = build_JSON_res( srv, con, m, res );
        buffer_append_string( b, temp );
        free(temp);
    }
    else
    {
        buffer_append_string (b, "Response=Success\r\n");
         if ( ( strcasestr( pn, "963-40017" ) != NULL ) || ( strcasestr( pn, "96340017" ) != NULL ) )
        {
             snprintf(res, sizeof(res), "sn=00100300YY0200100000%s\r\n", buf );
        }
        else if ( ( strcasestr( pn, "963-50017" ) != NULL ) || ( strcasestr( pn, "96350017" ) != NULL ) )
        {
            snprintf(res, sizeof(res), "sn=00100300TF0200100000%s\r\n", buf );
        }
        else if ( ( strcasestr( pn, "963-30017" ) != NULL ) || ( strcasestr( pn, "96330017" ) != NULL ) )
        {
            snprintf(res, sizeof(res), "sn=00100300SB0100100000%s\r\n", buf );
        }
        else if ( ( strcasestr( pn, "963-20015" ) != NULL ) || ( strcasestr( pn, "96320015" ) != NULL ) 
			|| ( strcasestr( pn, "963-30015" ) != NULL ) || ( strcasestr( pn, "96330015" ) != NULL ) )
        {
            snprintf(res, sizeof(res), "sn=00100300ZX3100100000%s\r\n", buf );
        }
        else if ( ( strcasestr( pn, "963-70017" ) != NULL ) || ( strcasestr( pn, "96370017" ) != NULL ) )
        {
            snprintf(res, sizeof(res), "sn=00100300ZX4100100000%s\r\n", buf );
        }
        else if ( !strcasecmp( pn, "963-90015" ) || !strcasecmp( pn, "96390015" ) )
        {
            snprintf(res, sizeof(res), "sn=00100300CL0200200000%s\r\n", buf );
        }
        else
        {
            snprintf(res, sizeof(res), "sn=00100300CL0200100000%s\r\n", buf );
        }
       
        buffer_append_string (b, res);
    }
    return 0;
}

static int dbus_send_proxyupdated ( void )
{
#ifdef BUILD_ON_ARM
    DBusMessage* message;

    if ( bus == NULL )
    {
        printf( "Error: Dbus bus is NULL\n" );
        return 1;
    }

    message = dbus_message_new_signal( DBUS_PATH, DBUS_INTERFACE, SIGNAL_PROXYUPDATED);
    if ( message == NULL )
    {
        printf( "message is NULL\n" );
        return 1;
    }

    dbus_message_append_args( message,  DBUS_TYPE_INVALID );

    dbus_connection_send( bus, message, NULL );
    dbus_message_unref( message );
#endif
    return 0;
}

static int handle_factset (buffer *b,const struct message *m)
{
    /*FILE *file_fd = NULL;
    file_fd = fopen( "/proc/bootloader_bcd", "w+");

    if (file_fd != NULL)
    {
        const char *temp = NULL;
        temp = msg_get_header(m, "resetstyle");
        if(temp != NULL && strcmp(temp,"1") == 0) {
            const char *resetclear = "factory_reset 1 2 3 4";
            fwrite( resetclear, sizeof(resetclear), strlen("factory_reset 1 2 3 4") + 1, file_fd );
        }else{
            const char *reset = "factory_reset 1 2 3";
            fwrite( reset, sizeof(reset), strlen("factory_reset 1 2 3") + 1, file_fd );
        }
        //fwrite( "factory_reset 1 2 3", 1, strlen("factory_reset 1 2 3"), file_fd );
        fclose( file_fd );
        sync();
    }*/

    const char *temp = NULL;
    temp = msg_get_header(m, "resetstyle");
    int result;
    if(temp != NULL && strcmp(temp,"1") == 0) {
        result = system("fixed_factory_reset 15");   // 1|2|4|8
    }else{
        result = system("fixed_factory_reset 7");   // 1|2|4
    }
    sync();
    
    if( result == 0 )
        buffer_append_string (b, "Response=Success\r\n");
    else
        buffer_append_string (b, "Response=Error\r\n");

    return 1;
}

static int handle_backupcfg(buffer *b)
{
    int result = system("restorenvram -backup");
    if( result == 0 )
        buffer_append_string(b, "Response=Success\r\n");
    else
        buffer_append_string(b, "Response=Error\r\n");
}

static int handle_restorecfg(buffer *b)
{
    int result = system("restorenvram -restore");
    if( result == 0 )
        buffer_append_string(b, "Response=Success\r\n");
    else
        buffer_append_string(b, "Response=Error\r\n");
}

static int get_ip_mask(char* ifname, char *mask)
{
    struct ifreq ifr;
    int fd;

    if (mask == NULL) {
        return -1;
    }
    strcpy (mask, "none");

    fd = socket (AF_INET, SOCK_DGRAM, 0);
    if (fd >= 0) {
        u_int32_t ip;

        strcpy( ifr.ifr_name, ifname );

        if (ioctl (fd, SIOCGIFNETMASK, &ifr) == 0) {
            ip = ntohl (((struct sockaddr_in*)&ifr.ifr_addr)->sin_addr.s_addr);
            sprintf (mask, "%u.%u.%u.%u", (ip >> 24) & 0xff, (ip >> 16) & 0xff,
                    (ip >> 8) & 0xff, ip &0xff);
        } else {
            close(fd);
            return -1;
        }

        close(fd);
        return 0;
    }
    return -1;
}

/*static int dbus_send_factfun ( const int arg1 )
{
    DBusMessage* message;

    if ( bus == NULL )
    {
        printf( "Error: Dbus bus is NULL\n" );
        return 1;
    }

    message = dbus_message_new_signal( DBUS_PATH, DBUS_INTERFACE, SIGNAL_FACTFUN);
    if ( message == NULL )
    {
        printf( "message is NULL\n" );
        return 1;
    }

    dbus_message_append_args( message, DBUS_TYPE_INT32, &arg1, DBUS_TYPE_INVALID );

    dbus_connection_send( bus, message, NULL );
    dbus_message_unref( message );

    return 0;
}*/

static int get_ip_address(char* ifname, char *addr)
{
    struct ifreq ifr;
    int fd;

    if (addr == NULL) {
        return -1;
    }
    strcpy(addr, "none");

    fd = socket (AF_INET, SOCK_DGRAM, 0);
    if (fd >= 0) {
        u_int32_t ip;

        strcpy (ifr.ifr_name, ifname);
        if (ioctl (fd, SIOCGIFADDR, &ifr) == 0) {
            ip = ntohl (((struct sockaddr_in*)&ifr.ifr_addr)->sin_addr.s_addr);
            sprintf (addr, "%u.%u.%u.%u", (ip >> 24) & 0xff, (ip >> 16) & 0xff,
            (ip >> 8) & 0xff, ip & 0xff);
        } else {
            close (fd);
            return -1;
        }

        close (fd);
        return 0;
    }
    return -1;
}

static int handle_network (server *srv, connection *con,
    buffer *b, const struct message *m)
{
    char buf[128] = "";
    char res[128] = "";
    char mac[25] = "";
    char ip[25] = "";
    char mask[25] = "";
    char gateway[25] = "";
    char dns[25] = "\0";
    char dns2[25] = "\0";
    char type[25] = "";
    char *info = NULL;
    char *temp = NULL;
    char *val = NULL;
    const char *resType = NULL;
    resType = msg_get_header(m, "format");
#ifdef BUILD_ON_ARM
    char *p_value = nvram_get("wan_device");
#else
    char *p_value = NULL;
#endif

    if ( (resType == NULL) || strcasecmp( resType, "json" ) )
    {
        buffer_append_string (b, "Response=Success\r\n");
    }
    
    if(p_value != NULL && p_value[0] != '\0' && strstr(p_value, "ppp") == NULL)
    {
        get_mac_address(p_value, buf);
    }
    else
    {
        get_mac_address("eth0", buf);
    }
    
    if ( (resType != NULL) && !strcasecmp( resType, "json" ) )
    {
        snprintf(mac, sizeof(mac), "%s", buf );
    }
    else
    {
        snprintf(res, sizeof(res), "Mac=%s\r\n", buf );
        buffer_append_string (b, res);
    }
    
    if (p_value != NULL && p_value[0] != '\0')
    {
        get_ip_address(p_value, buf);
    }
    else
    {
        get_ip_address ("eth0", buf);
    }

    if ( (resType != NULL) && !strcasecmp( resType, "json" ) )
    {
        snprintf(ip, sizeof(ip), "%s", buf );
    }
    else
    {
        snprintf(res, sizeof(res), "IP=%s\r\n", buf );
        buffer_append_string (b, res);
    }
    
    if (p_value != NULL && p_value[0] != '\0')
    {
        get_ip_mask(p_value, buf);
    }
    else
    {
        get_ip_mask("eth0", buf);
    }
    
    if ( (resType != NULL) && !strcasecmp( resType, "json" ) )
    {
        snprintf(mask, sizeof(mask), "%s", buf );
    }
    else
    {
        snprintf(res, sizeof(res), "Mask=%s\r\n", buf );
        buffer_append_string (b, res);
    }
    
    get_gateway (buf);

    if ( (resType != NULL) && !strcasecmp( resType, "json" ) )
    {
        snprintf(gateway, sizeof(gateway), "%s", buf );
    }
    else
    {
        snprintf(res, sizeof(res), "Gateway=%s\r\n", buf );
        buffer_append_string (b, res);
    }
    
    get_dns_server (buf);

    if ( (resType != NULL) && !strcasecmp( resType, "json" ) )
    {
        snprintf(dns, sizeof(dns), "%s", buf );
    }
    else
    {
        snprintf(res, sizeof(res), "DNS=%s\r\n", buf );
        buffer_append_string (b, res);
    }

    get_dns2_server (buf);

    if ( (resType != NULL) && !strcasecmp( resType, "json" ) )
    {
       snprintf(dns2,sizeof(dns2),"%s",buf);
        /*if(strlen(dns) == 0){
           snprintf(dns, sizeof(dns), "%s", buf );
        }else{
           strcat(dns," ");
           strcat(dns,buf);
        }*/
    }
    else
    {
        snprintf(res, sizeof(res), "DNS2=%s\r\n", buf );
        buffer_append_string (b, res);
    }
    
#ifdef BUILD_ON_ARM
    val = nvram_my_get ("8");
#else
    val = "0";
#endif
    if ( (resType != NULL) && !strcasecmp( resType, "json" ) )
    { 
        if (strcmp (val, "0") == 0) {
            snprintf(type, sizeof(type), "dhcp" );
        } else if (strcmp (val, "2") == 0) {
            snprintf(type, sizeof(type), "pppoe" );
        } else {
            snprintf(type, sizeof(type), "static" );
        }

        info = (char*)malloc((150 + strlen(mac) + strlen(ip) + strlen(mask) + strlen(gateway) + strlen(dns) +strlen(dns2) + strlen(type)) * sizeof(char));

        sprintf(info,
                "{\"res\" : \"success\", \"mac\" : \"%s\", \"ip\" : \"%s\", \"mask\" : \"%s\", \"gateway\" : \"%s\", \"dns\" : \"%s\",\"dns2\" : \"%s\",  \"type\" : \"%s\"}",
                mac, ip, mask, gateway, dns,dns2, type);
        temp = info;
        temp = build_JSON_formate( srv, con, m, temp );

        if(info != NULL)
        {
            free(info);
        }

        if ( temp != NULL )
        {
            buffer_append_string( b, temp );
            free(temp);
        }
    }
    else
    {
        if (strcmp (val, "0") == 0) {
            snprintf(res, sizeof(res), "type=dhcp\r\n" );
        } else if (strcmp (val, "2") == 0) {
            snprintf(res, sizeof(res), "type=pppoe\r\n" );
        } else {
            snprintf(res, sizeof(res), "type=static\r\n" );
        }
        buffer_append_string (b, res);
    }
    
    return 1;
}

static int handle_fxoexist(buffer *b)
{
    char res[128] = "";
    char buf[128] = "";
    int fxoexist;
    FILE *sys_file;
    
    sys_file = fopen ("/proc/gxvboard/dev_info/have_FXO", "r");
    
    if (sys_file != NULL) {
        fread (buf, 127, 1, sys_file);
        fclose (sys_file);

        sscanf (buf, "%d", &fxoexist);
        snprintf(res, sizeof(res), "Response=Success\r\n"
            "fxoexist=%d\r\n",fxoexist);
        buffer_append_string (b, res);
        return 1;

    } else {
        buffer_append_string(b, "Response=Error\r\n"
                "Message=Can't get fxo status\r\n");
        return -1;
    } 
}

static int handle_fxostatus(buffer *b)
{
    char res[64] = "";

    snprintf(res, sizeof(res), "Response=Success\r\n"
            "fxocon=%d\r\n",fxocon );
    buffer_append_string (b, res);
    
    snprintf(res, sizeof(res), "fxostatus=%d\r\n",fxostatus );
    buffer_append_string (b, res);

    return 1;
}


static int handle_uptime (server *srv, connection *con, 
    buffer *b, const struct message *m)
{
    char res[128] = "";
    char buf[128] = "";
    int day, hour, min, sec;
    long long sys_time;
    FILE *sys_file;
    
    sys_file = fopen ("/proc/uptime", "r");
    
    if (sys_file != NULL) {
        sys_time = 0;
        fread (buf, 127, 1, sys_file);
        fclose (sys_file);

        sscanf (buf, "%lld", &sys_time);

        day = sys_time / (24 * 3600);
        sys_time %= (24 * 3600);
        hour = sys_time / 3600;
        sys_time %= 3600;
        min = sys_time / 60;
        sec = sys_time % 60;

        const char *resType = msg_get_header(m, "format");
        if ( (resType != NULL) && !strcasecmp( resType, "json" ) )
        {
            snprintf( res, sizeof( res ),
                    "{\"res\": \"success\", \"day\": \"%d\", \"hour\" : \"%d\","
                    " \"min\" : \"%d\", \"sec\" : \"%d\"}", day, hour, min, sec );
            char *temp = build_JSON_res( srv, con, m, res );
            buffer_append_string( b, temp );
            free(temp);
        }
        else
        {
            buffer_append_string (b, "Response=Success\r\n");

            snprintf(res, sizeof(res), "Day=%d\r\n"
                "Hour=%d\r\n"
                "Min=%d\r\n"
                "Sec=%d\r\n",
                day, hour, min, sec );
            buffer_append_string(b, res);
        }
    } else {
    const char *resType = msg_get_header(m, "format");
        if ( (resType != NULL) && !strcasecmp( resType, "json" ) )
        {
            snprintf( res, sizeof( res ),
                    "{\"res\": \"error\", \"msg\": \"can't get uptime\"}" );
            char *temp = build_JSON_res( srv, con, m, res );
            buffer_append_string( b, temp );
            free(temp);
        }
        else
        {
            buffer_append_string(b, "Response=Error\r\n"
                    "Message=Can't get uptime\r\n");
        }
    }

    return 1;
}

static int handle_status (  server *srv, connection *con,buffer *b, const struct message *m)
{
    char res[128] = "";
    int order[6] = {0, 1, 2, 3, 4, 5};
    const char *servers[6] = {"Unknown", "Unknown", "Unknown, Unknown", "Unknown", "Unknown"};
    const char *numbers[6] = {"Unknown", "Unknown", "Unknown, Unknown", "Unknown", "Unknown"};
    int statuses[6] = {accountstatus.acc1, accountstatus.acc2, accountstatus.acc3, accountstatus.acc4, accountstatus.acc5, accountstatus.acc6};
    const char *activate[6] = {"0", "0", "0", "0", "0", "0"};
    int tmporder;
    const char *var = NULL;
    const char *resType = NULL;
    const char *jsonCallback = NULL;

#ifdef BUILD_ON_ARM
    pthread_mutex_lock (&dbusmutex);

    servers[0] = nvram_my_get("47");
    servers[1] = nvram_my_get("402");
    servers[2] = nvram_my_get("502");
    servers[3] = nvram_my_get("602");
    servers[4] = nvram_my_get("1702");
    servers[5] = nvram_my_get("1802");

    numbers[0] = nvram_my_get("35");
    numbers[1] = nvram_my_get("404");
    numbers[2] = nvram_my_get("504");
    numbers[3] = nvram_my_get("604");
    numbers[4] = nvram_my_get("1704");
    numbers[5] = nvram_my_get("1804");
    var = nvram_my_get("gsid_0");
    if (strlen(var) > 2)
    {
        for(int ipvideo = 0; ipvideo < 6; ipvideo ++)
        {
            if (strcasestr(servers[ipvideo], "ipvideotalk") != NULL)
            {
                numbers[ipvideo] = nvram_my_get("gsid_0");
                break;
            }
        } 
    }
    
    activate[0] = nvram_my_get("271");
    activate[1] = nvram_my_get("401");
    activate[2] = nvram_my_get("501");
    activate[3] = nvram_my_get("601");
    activate[4] = nvram_my_get("1701");
    activate[5] = nvram_my_get("1801");
#endif

    resType = msg_get_header(m, "format");
    int onum = 0;

    if ( (resType == NULL) || strcasecmp( resType, "json" ) )
    {
        buffer_append_string (b, "Response=Success\r\n");
        for( onum = 0; onum < 6; onum++ )
        {
            tmporder = order[onum];
            snprintf(res, sizeof(res), "Account_%d_SERVER=%s\r\n", tmporder, servers[ tmporder ] );
            buffer_append_string(b, res);
            snprintf(res, sizeof(res), "Account_%d_NO=%s\r\n", tmporder, numbers[ tmporder ] );
            buffer_append_string(b, res);
            snprintf(res, sizeof(res), "Account_%d_STATUS=%d\r\n", tmporder, statuses[ tmporder ] );
            buffer_append_string(b, res);
        }
    }
    else
    {
         response_header_overwrite(srv, con, CONST_STR_LEN("Content-Type"),
                CONST_STR_LEN("application/x-javascript; charset=utf-8"));

        jsonCallback = msg_get_header( m, "jsoncallback" );
        if(jsonCallback != NULL){
            buffer_append_string(b,jsonCallback);
             buffer_append_string(b,"(");

        }

        buffer_append_string(b, "{\"Response\":\"Success\",\"Data\":[");
        int first = 0;
        for( onum = 0; onum < 6; onum++ )
        {
            tmporder = order[onum];
            if( !first )
            {
                snprintf(res, sizeof(res), "{\"Index\":\"%d\"", tmporder ); //account order
            }else
            {
                snprintf(res, sizeof(res), ",{\"Index\":\"%d\"", tmporder ); //account order
            }
            buffer_append_string(b, res);
            snprintf(res, sizeof(res), ",\"Server\":\"%s\"", servers[ tmporder ] ); //server
            buffer_append_string(b, res);
            snprintf(res, sizeof(res), ",\"Number\":\"%s\"", numbers[ tmporder ] ); //number
            buffer_append_string(b, res);
            snprintf(res, sizeof(res), ",\"Status\":\"%d\"", statuses[ tmporder ] ); //status
            buffer_append_string(b, res);
            snprintf(res, sizeof(res), ",\"Activate\":\"%s\"}", activate[ tmporder ] ); //activate
            buffer_append_string(b, res);
            first ++;
        }
        buffer_append_string(b, "]}");

        if(jsonCallback != NULL){
            buffer_append_string(b,")");
        }
    }

#ifdef BUILD_ON_ARM
    pthread_mutex_unlock(&dbusmutex);
#endif
    return 0;
}

static int handle_getPageItems(buffer *b)
{
    xmlChar *name = NULL;
    xmlDoc *doc = NULL;
    xmlNode *root_element = NULL;
    xmlNode *cur_node = NULL, *son_node = NULL, *son2_node = NULL;
    char *res = NULL;
    int i = 0;

    doc = xmlReadFile(CONF_MENU, NULL, 0);

    if (doc == NULL)
    {
        printf("error: could not parse file %s\n", CONF_MENU);
        buffer_append_string(b, "Response=Error\r\n"
                "Message=Configuration File Not Found\r\n");
        return -1;
    }

    buffer_append_string(b, "{\"Response\":\"Success\",\"Items\":[");
    root_element = xmlDocGetRootElement(doc);

    for (cur_node = root_element->xmlChildrenNode; cur_node; cur_node = cur_node->next)
    {
        if (cur_node->type == XML_ELEMENT_NODE)
        {
            if ((!xmlStrcmp(cur_node->name, BAD_CAST "plugin")))
            {
                name = xmlGetProp(cur_node, BAD_CAST "name");
                if (name != NULL)
                {
                    res = malloc( strlen((char *) name)+4);
                    if( !i )
                    {
                        sprintf(res, "\"%s\"", (char *) name );
                    }else
                    {
                        sprintf(res, ",\"%s\"", (char *) name );
                    }
                    buffer_append_string(b, res);
                    i++;
                    xmlFree(name);
                    free(res);
                }
            }else if ((!xmlStrcmp(cur_node->name, BAD_CAST "MenuGroup")))
            {
                for (son_node = cur_node->xmlChildrenNode; son_node; son_node = son_node->next)
                {
                    if ((!xmlStrcmp(son_node->name, BAD_CAST "subMenu")))
                    {
                        for (son2_node = son_node->xmlChildrenNode; son2_node; son2_node = son2_node->next)
                        {
                            if ((!xmlStrcmp(son2_node->name, BAD_CAST "plugin")))
                            {
                                name = xmlGetProp(son2_node, BAD_CAST "name");
                                if (name != NULL)
                                {
                                    res = malloc( strlen((char *) name)+4);
                                    if( !i )
                                    {
                                        sprintf(res, "\"%s\"", (char *) name );
                                    }else
                                    {
                                        sprintf(res, ",\"%s\"", (char *) name );
                                    }
                                    buffer_append_string(b, res);
                                    i++;
                                    xmlFree(name);
                                    free(res);
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    buffer_append_string(b, "]}");
    return 1;
}

static int handle_getcallfunc (buffer *b)
{
    xmlChar *key = NULL;
    xmlDoc *doc = NULL;
    xmlNode *root_element = NULL;
    xmlNode *cur_node = NULL;
    xmlNode *son_node = NULL;
    int i = 0;
    char *res = NULL;

    doc = xmlReadFile(CONF_CALLFUNC, NULL, 0);

    if (doc == NULL)
    {
        printf("error: could not parse file %s\n", CONF_CALLFUNC);
        buffer_append_string(b, "Response=Error\r\n"
                "Message=Configuration File Not Found\r\n");
        return -1;
    }

    buffer_append_string(b, "{\"Response\":\"Success\",");
    root_element = xmlDocGetRootElement(doc);

    for (cur_node = root_element->xmlChildrenNode; cur_node; cur_node = cur_node->next)
    {
        if (cur_node->type == XML_ELEMENT_NODE)
        {
            if ((!xmlStrcmp(cur_node->name, BAD_CAST "funcload")))
            {
                xmlChar  *attr = NULL;
                xmlNodePtr temp_node = NULL;
                temp_node = cur_node;
                attr = xmlGetProp(temp_node, BAD_CAST "default");
                if( attr != NULL )
                {
                    buffer_append_string(b, "\"Defaultpage\":\"");
                    buffer_append_string(b, (char *) attr);
                }else
                {
                    buffer_append_string(b, "\"Defaultpage\":\"Keyboard");
                }
                xmlFree(attr);
                attr = xmlGetProp(temp_node, BAD_CAST "forward");
                if( attr != NULL )
                {
                    buffer_append_string(b, "\",\"enableForward\":\"");
                    buffer_append_string(b, (char *) attr);
                    buffer_append_string(b, "\",\"Functions\":[");
                }else
                {
                    buffer_append_string(b, "\",\"enableForward\":\"1\",\"Functions\":[");
                }
                xmlFree(attr);
                for (son_node = cur_node->xmlChildrenNode; son_node; son_node = son_node->next)
                {
                    if ((!xmlStrcmp(son_node->name, BAD_CAST "function")))
                    {
                        key = xmlNodeListGetString(doc, son_node->xmlChildrenNode, 1);
                        if (key != NULL)
                        {
                            res = malloc( strlen((char *) key)+8);
                            if( !i )
                            {
                                sprintf(res, "\"%s(1)\"", (char *) key );
                            }else
                            {
                                sprintf(res, ",\"%s(1)\"", (char *) key );
                            }
                            buffer_append_string(b, res);
                            i++;
                            xmlFree(key);
                            free(res);
                        }
                    }
                }
            }else
            {
                for (son_node = cur_node->xmlChildrenNode; son_node; son_node = son_node->next)
                {
                    if ((!xmlStrcmp(son_node->name, BAD_CAST "function")))
                    {
                        key = xmlNodeListGetString(doc, son_node->xmlChildrenNode, 1);
                        if (key != NULL)
                        {
                            res = malloc( strlen((char *) key)+8);
                            if( !i )
                            {
                                sprintf(res, "\"%s(0)\"", (char *) key );
                            }else
                            {
                                sprintf(res, ",\"%s(0)\"", (char *) key );
                            }
                            buffer_append_string(b, res);
                            i++;
                            xmlFree(key);
                            free(res);
                        }
                    }
                }
            }
        }
    }

    buffer_append_string(b, "]}");

    /*free the document */
    xmlFreeDoc(doc);
    return 1;
}

static int handle_putcallfunc (buffer *b, const struct message *m)
{
    xmlDoc *doc = NULL;
    xmlNode *root_element = NULL;
    int i = 0;
    const char *temp = NULL;
    char *tempfunc = NULL;
    int num = 0;

    doc = xmlReadFile(CONF_CALLFUNC, NULL, 0);

    if (doc == NULL)
    {
        printf("error: could not parse file %s\n", CONF_CALLFUNC);
        buffer_append_string(b, "Response=Error\r\n"
                "Message=Configuration File Not Found\r\n");
        return -1;
    }

    root_element = xmlDocGetRootElement(doc);
    xmlUnlinkNode( root_element );
    xmlFreeNode( root_element );

    xmlNodePtr new_root = NULL;
    new_root = xmlNewChild(doc, NULL, BAD_CAST "call", NULL);
    xmlNodePtr new_node = NULL;
    new_node = xmlNewChild(new_root, NULL, BAD_CAST "funcload", NULL);
    if ( new_node != NULL )
    {
        temp = msg_get_header(m, "defaultpage");
        if( temp != NULL )
            xmlNewProp(new_node, BAD_CAST "default", BAD_CAST temp );
        else
            xmlNewProp(new_node, BAD_CAST "default", BAD_CAST "Keyboard" );
        temp = msg_get_header(m, "enableforward");
        if( temp != NULL )
            xmlNewProp(new_node, BAD_CAST "forward", BAD_CAST temp );
        else
            xmlNewProp(new_node, BAD_CAST "forward", BAD_CAST "1" );
        temp = msg_get_header(m, "load");
        num = atoi( msg_get_header(m, "loadnum") );
        for( i = 0; i < num; i ++ )
        {
            printf("temp is %s\n", temp);
            tempfunc = strsep(&temp, "_");
            xmlNewChild(new_node, NULL, BAD_CAST "function", BAD_CAST tempfunc);
        }
    }

    //xmlNodePtr new_node2 = NULL;
    new_node = xmlNewChild(new_root, NULL, BAD_CAST "funcunload", NULL);
    if ( new_node != NULL )
    {
        temp = msg_get_header(m, "unload");
        num = atoi( msg_get_header(m, "unloadnum") );
        for( i = 0; i < num; i ++ )
        {
            printf("temp is %s\n", temp);
            tempfunc = strsep(&temp, "_");
            xmlNewChild(new_node, NULL, BAD_CAST "function", BAD_CAST tempfunc);
        }
    }

    buffer_append_string (b, "Response=Success\r\n");

    /*free the document */
    xmlSaveFormatFileEnc(CONF_CALLFUNC, doc, "UTF-8", 1);
    xmlFreeDoc(doc);
    xmlCleanupParser();
    xmlMemoryDump();
    sync();

    dbus_send_string(SIGNAL_CALLUPDATED);
    return 1;
}

static void xmlNodeSetEncodeContent(xmlDocPtr doc, xmlNodePtr cur, const xmlChar * content)
{
    xmlChar * encode_buf = NULL;
    
    if ((cur != NULL) && (content != NULL))
    {
        encode_buf = xmlEncodeEntitiesReentrant(doc, (xmlChar *) content);
        if (encode_buf != NULL)
        {
            xmlNodeSetContent(cur, (xmlChar *) encode_buf);
            xmlFree(encode_buf);
            encode_buf = NULL;
        }
    }
}

static int handle_gethwservers(buffer *b)
{
    xmlChar *key = NULL;
    xmlDoc *doc = NULL;
    xmlNode *root_element = NULL;
    xmlNode *cur_node = NULL;
    char res[128] = "";

    doc = xmlReadFile(CONF_HWPHBK, NULL, 0);

    if (doc == NULL)
    {
        printf("error: could not parse file %s\n", CONF_HWPHBK);
        buffer_append_string(b, "Response=Error\r\n"
                "Message=Configuration File Not Found\r\n");
        return -1;
    }

    buffer_append_string (b, "Response=Success\r\n");

    /*Get the root element node */
    root_element = xmlDocGetRootElement(doc);
    for (cur_node = root_element->xmlChildrenNode; cur_node; cur_node = cur_node->next)
    {
        if (cur_node->type == XML_ELEMENT_NODE)
        {
            if ((!xmlStrcmp(cur_node->name, BAD_CAST "search")))
            {
                key = xmlNodeListGetString(doc, cur_node->xmlChildrenNode, 1);
                if (key == NULL)
                {
                    buffer_append_string(b, "searchurl=\r\n");
                }
                else
                {
                    snprintf(res, sizeof(res), "searchurl=%s\r\n", (char *) key);
                    buffer_append_string(b, res);
                    xmlFree(key);
                }
            }else if ((!xmlStrcmp(cur_node->name, BAD_CAST "status")))
            {
                key = xmlNodeListGetString(doc, cur_node->xmlChildrenNode, 1);
                if (key == NULL)
                {
                    buffer_append_string(b, "statusurl=\r\n");
                }
                else
                {
                    snprintf(res, sizeof(res), "statusurl=%s\r\n", (char *) key);
                    buffer_append_string(b, res);
                    xmlFree(key);
                }
            }else if ((!xmlStrcmp(cur_node->name, BAD_CAST "photo")))
            {
                key = xmlNodeListGetString(doc, cur_node->xmlChildrenNode, 1);
                if (key == NULL)
                {
                    buffer_append_string(b, "photourl=\r\n");
                }
                else
                {
                    snprintf(res, sizeof(res), "photourl=%s\r\n", (char *) key);
                    buffer_append_string(b, res);
                    xmlFree(key);
                }
            }
        }
    }

    /*free the document */
    xmlFreeDoc(doc);
    return 1;
}

static int handle_puthwservers (buffer *b, const struct message *m)
{
    xmlDocPtr doc = NULL;
    xmlNode *root_element = NULL;
    xmlNode *cur_node = NULL;
    const char *temp = NULL;
    char *val = NULL;

    doc = xmlReadFile(CONF_HWPHBK, NULL, 0);

    if (doc == NULL)
    {
        printf("error: could not parse file %s\n", CONF_HWPHBK);
        buffer_append_string(b, "Response=Error\r\n"
                "Message=Configuration File Not Found\r\n");
        return -1;
    }

    /*Get the root element node */
    root_element = xmlDocGetRootElement(doc);
    for (cur_node = root_element->xmlChildrenNode; cur_node; cur_node = cur_node->next)
    {
        if (cur_node->type == XML_ELEMENT_NODE)
        {
            if ((!xmlStrcmp(cur_node->name, BAD_CAST "search")))
            {
                temp = msg_get_header(m, "searchurl");
                if ( temp != NULL )
                {
                    val = strdup( (char*)temp );
                    uri_decode(val);
                    xmlNodeSetEncodeContent(doc, cur_node, (xmlChar *)val);
                    free(val);
                }
            }else if ((!xmlStrcmp(cur_node->name, BAD_CAST "status")))
            {
                temp = msg_get_header(m, "statusurl");
                if ( temp != NULL )
                {
                    val = strdup( (char*)temp );
                    uri_decode(val);
                    xmlNodeSetEncodeContent(doc, cur_node, (xmlChar *)val);
                    free(val);
                }
            }else if ((!xmlStrcmp(cur_node->name, BAD_CAST "photo")))
            {
                temp = msg_get_header(m, "photourl");
                if ( temp != NULL )
                {
                    val = strdup( (char*)temp );
                    uri_decode(val);
                    xmlNodeSetEncodeContent(doc, cur_node, (xmlChar *)val);
                    free(val);
                }
            }
        }
    }

    xmlSaveFormatFileEnc(CONF_HWPHBK, doc, "UTF-8", 1);
    xmlFreeDoc(doc);
    xmlCleanupParser();
    xmlMemoryDump();
    sync();

    buffer_append_string (b, "Response=Success\r\n");

    return 1;
}

static int handle_androidverion(buffer *b)
{
    system("getprop ro.build.version.release > /tmp/androidver");
    FILE *fp = fopen("/tmp/androidver", "r");
    char androidver[8] = "";
    char country[3] = "";
    if (fp == NULL)
    {
        buffer_append_string (b, "Response=Success\r\nandroidver=\r\n");
        return -1;
    }

    fgets( &androidver, sizeof(androidver), fp );
    fclose(fp);
    buffer_append_string (b, "Response=Success\r\nandroidver=");
    buffer_append_string (b, androidver);
    buffer_append_string (b, "\r\n");

    return 1;
}

static int check_provision_pid()
{
	system("chmod +x /bin/pidof");
    char *cmdstr = NULL;
    cmdstr = malloc(40);
    sprintf(cmdstr, "pidof lighttpd > /tmp/tmppid &");
    printf("cmdstr is %s\n", cmdstr);
    int result = system(cmdstr);
    sleep(1);
    if(result == 0)
    {
        FILE *cur_pidfile;
        cur_pidfile = fopen ("/tmp/tmppid", "r");

        if (cur_pidfile != NULL) {
            char buf[32] = "";
            fread (buf, 32, 1, cur_pidfile);
            fclose (cur_pidfile);
            int pid = atoi(buf);
            if( pid != 0 )
            {
            	FILE *pid_file;
        		pid_file = fopen ("/tmp/PROVISION.PID", "r");
        		if (pid_file != NULL)
        		{
        			char buf2[32] = "";
			        fread (buf2, 32, 1, pid_file);
			        fclose (pid_file);
			        int pid2 = atoi(buf2);
                    if( pid == pid2 )
			        {
                        system("echo ' ' > /tmp/PROVISION.PID");
						return 1;
                    }
        		}
            }
        }
    }
    return 0;
}

static int handle_initupstatus(buffer *b)
{
    if( m_uploading )
    {
        check_provision_pid();
        m_uploading = 0;
    }
    buffer_append_string (b, "Response=Success\r\n");
}

static int handle_provisioninit(buffer *b)
{
    if( m_uploading )
    {
        buffer_append_string (b, "0");
        return 0;
    }
    provision_ret = provision_init(&provision_local_fd, &provision_destaddr);
    if(provision_ret)
    {
        check_provision_pid();
        buffer_append_string (b, "0");
        return 0;
    }

    m_uploading = 1;
    int result = inform_gparse_update(provision_local_fd, &provision_destaddr);
    printf("inform_gparse_update result is %d\n", result);
    if( result )
        buffer_append_string (b, "0");
    else
        buffer_append_string (b, "1");
    return 1;
}

static int handle_upgradenow (buffer *b)
{
    //unsigned int size;

    /* write fireware to /tmp/gparse.fifo */
    //size = file_manager_file_copy(FW_PATH, FIFO_PATH);
    //size = write2fifo(FIFO_PATH, FW_PATH);
    //printf("%u write to fifo\n", size >> 20);
    inform_gparse_end(provision_local_fd, &provision_destaddr);
    if( access(FIFO_PATH, 0) ) {
        buffer_append_string (b, "Response=Success\r\nresult=2\r\n");
        check_provision_pid();
        m_uploading = 0;
        return -1;
    }
    provision_ret = wait_for_gparse_result(provision_local_fd, &provision_destaddr);
    char res[32] = "";
    snprintf(res, sizeof(res), "Response=Success\r\nresult=%d\r\n", provision_ret);
    buffer_append_string (b, res);
    check_provision_pid();
    m_uploading = 0;
    return 0;
}

static int handle_getcountry (buffer *b)
{
    xmlChar *key = NULL;
    xmlDoc *doc = NULL;
    xmlNode *root_element = NULL;
    xmlNode *cur_node = NULL;
    xmlNode *cur_sub_node = NULL;
    char res[64] = "";

    doc = xmlReadFile(CONF_AUTOCONFIG, NULL, 0);

    if (doc == NULL)
    {
        printf("error: could not parse file %s\n", CONF_AUTOCONFIG);
        buffer_append_string(b, "Response=Error\r\n"
                "Message=Configuration File Not Found\r\n");
        return -1;
    }

    buffer_append_string (b, "Response=Success\r\n");

    /*Get the root element node */
    root_element = xmlDocGetRootElement(doc);

    for (cur_node = root_element->xmlChildrenNode; cur_node; cur_node = cur_node->next)
    {
        if (cur_node->type == XML_ELEMENT_NODE)
        {
            if ((!xmlStrcmp(cur_node->name, BAD_CAST "config")))
            {
                for (cur_sub_node = cur_node->xmlChildrenNode; cur_sub_node; cur_sub_node = cur_sub_node->next)
                {
                    if (cur_sub_node->type == XML_ELEMENT_NODE)
                    {
                        if ((!xmlStrcmp(cur_sub_node->name, BAD_CAST "country")))
                        {
                            key = xmlNodeListGetString(doc, cur_sub_node->xmlChildrenNode, 1);
                            if (key == NULL)
                            {
                                buffer_append_string(b, "country=\r\n");
                            }
                            else
                            {
                                snprintf(res, sizeof(res), "country=%s\r\n", (char *) key);
                                buffer_append_string(b, res);
                                xmlFree(key);
                            }
                        }
                    }
                }
            }
        }
    }

    /*free the document */
    xmlFreeDoc(doc);
    return 1;
}

static int handle_savephbk(buffer *b, const struct message *m)
{
    const char *resType = NULL;
    const char * jsonCallback = NULL;
    char *temp = NULL;
    // remove by jlxu, the follow four code
/*
    if( access( TMP_PHONEBOOKPATH, 0 ) )
    {
        mkdir(TMP_PHONEBOOKPATH, 0755);
    }
    dbus_send_lighttpd( SIGNAL_LIGHTTPD_PHBKUPLOAD);*/
    /*const char *temp = NULL;
    temp = msg_get_header(m, "mode");
    if(strcmp(temp,"1") == 0 || strcmp(temp,"2") == 0)
        dbus_send_lighttpd( SIGNAL_LIGHTTPD_PHBKUPLOAD);
    else{
        if (file_manager_file_copy(DATA_PHONEBOOK,TMP_GS_PHONEBOOK) == -2){
            buffer_append_string (b, "Response=Error\r\nMessage=can't find the phonebook!\r\n");
            return -1;
        }
        else if (file_manager_file_copy(DATA_PHONEBOOK,TMP_GS_PHONEBOOK) == -3){
            buffer_append_string (b, "Response=Error\r\nMessage=can't create the phonebook!\r\n");
            return -1;
        }
        else if (file_manager_file_copy(DATA_PHONEBOOK,TMP_GS_PHONEBOOK) == -1){
            buffer_append_string (b, "Response=Error\r\nMessage=Copy failed!\r\n");
            return -1;
        }
        else {
            buffer_append_string (b, "Response=Sucess\r\n");
        }
    }*/
    resType = msg_get_header(m, "format");

    if((resType != NULL) && !strcasecmp(resType, "json"))
    {
        jsonCallback = msg_get_header( m, "jsoncallback" );
    }

    if(jsonCallback != NULL)
    {
        temp = malloc((strlen(jsonCallback) + 32) * sizeof(char));

        if(temp != NULL)
        {
            sprintf(temp, "%s(%s)", jsonCallback, "{\"res\" : \"success\"}");
            buffer_append_string (b, temp);
            free(temp);
        }
    }
    else
    {
        buffer_append_string (b, "Response=Sucess\r\n");
    }

    return 1;
}

static int handle_getparams (buffer *b,const char*fileconf)
{
    xmlDocPtr doc = NULL;
    xmlNode *root_element = NULL;
    xmlNode *son2_node = NULL;
    //xmlNodePtr son2_node = NULL;
    xmlChar *key = NULL;
    xmlChar *nameattr = NULL;
    char res[128] = "";

    doc = xmlReadFile(fileconf, NULL, 0);

    if (doc == NULL)
    {
        printf("error: could not parse file %s\n", fileconf);
        buffer_append_string(b, "Response=Error\r\n"
                "Message=Configuration File Not Found\r\n");
        return -1;
    }

    buffer_append_string (b, "Response=Success\r\n");
    /*Get the root element node */
    root_element = xmlDocGetRootElement(doc);

    for (son2_node = root_element->xmlChildrenNode; son2_node; son2_node = son2_node->next)
    {
        //if (cur_node->type == XML_ELEMENT_NODE)
        {
            if ((!xmlStrcmp(son2_node->name, (const xmlChar *)"string")))
            {
                //son2_node = cur_node ->xmlChildrenNode;
                nameattr = xmlGetProp(son2_node, BAD_CAST "name");

                printf("xml parse node is %s\n", son2_node->name);
                if (nameattr != NULL)
                {
                    if (!xmlStrcmp(nameattr, (const xmlChar *)"import_file_type"))
                    {
                        key = xmlNodeListGetString(doc, son2_node->xmlChildrenNode, 1);
                        if (key == NULL)
                        {
                            buffer_append_string(b, "port-type=\r\n");
                        }
                        else
                        {
                            snprintf(res, sizeof(res), "port-type=%s\r\n", (char *) key);
                            buffer_append_string(b, res);
                            xmlFree(key);
                        }
                    }
                    else if (!xmlStrcmp(nameattr, (const xmlChar *)"import_replace_duplicate"))
                    {
                        key = xmlNodeListGetString(doc, son2_node->xmlChildrenNode, 1);
                        if (key == NULL)
                        {
                            buffer_append_string(b, "port-replace=\r\n");
                        }
                        else
                        {
                            snprintf(res, sizeof(res), "port-replace=%s\r\n", (char *) key);
                            buffer_append_string(b, res);
                            xmlFree(key);
                        }
                    }
                    else if (!xmlStrcmp(nameattr, (const xmlChar *)"import_clear_old"))
                    {
                        key = xmlNodeListGetString(doc, son2_node->xmlChildrenNode, 1);
                        if (key == NULL)
                        {
                            buffer_append_string(b, "port-clear=\r\n");
                        }
                        else
                        {
                            snprintf(res, sizeof(res), "port-clear=%s\r\n", (char *) key);
                            buffer_append_string(b, res);
                            xmlFree(key);
                        }
                    }
                    else if (!xmlStrcmp(nameattr, (const xmlChar *)"import_encoding"))
                    {
                        key = xmlNodeListGetString(doc, son2_node->xmlChildrenNode, 1);
                        if (key == NULL)
                        {
                            buffer_append_string(b, "port-encode=\r\n");
                        }
                        else
                        {
                            snprintf(res, sizeof(res), "port-encode=%s\r\n", (char *) key);
                            buffer_append_string(b, res);
                            xmlFree(key);
                        }
                    }
                    xmlFree(nameattr);
                    //son2_node = son2_node->next;
                }
            }
            /*else if ((!xmlStrcmp(cur_node->name, (const xmlChar *)"Download")))
            {
                son2_node = cur_node ->xmlChildrenNode;

                while (son2_node != NULL)
                {
                    if (!xmlStrcmp(son2_node->name, (const xmlChar *)"downloadMode"))
                    {
                        key = xmlNodeListGetString(doc, son2_node->xmlChildrenNode, 1);
                        if (key == NULL)
                        {
                            buffer_append_string(b, "down-mode=\r\n");
                        }

                        else
                        {
                            snprintf(res, sizeof(res), "down-mode=%s\r\n", (char *) key);
                            buffer_append_string(b, res);
                            xmlFree(key);
                        }
                    }

                    else if (!xmlStrcmp(son2_node->name, (const xmlChar *)"url"))
                    {
                        key = xmlNodeListGetString(doc, son2_node->xmlChildrenNode, 1);
                        if (key == NULL)
                        {
                            buffer_append_string(b, "down-url=\r\n");
                        }
                        else
                        {
                            snprintf(res, sizeof(res), "down-url=%s\r\n", (char *) key);
                            buffer_append_string(b, res);
                            xmlFree(key);
                        }
                    }

                    else if (!xmlStrcmp(son2_node->name, (const xmlChar *)"fileType"))
                    {
                        key = xmlNodeListGetString(doc, son2_node->xmlChildrenNode, 1);
                        if (key == NULL)
                        {
                            buffer_append_string(b, "down-type=\r\n");
                        }
                        else
                        {
                            snprintf(res, sizeof(res), "down-type=%s\r\n", (char *) key);
                            buffer_append_string(b, res);
                            xmlFree(key);
                        }
                      }
                    else if (!xmlStrcmp(son2_node->name, (const xmlChar *)"replaceDup"))
                    {
                        key = xmlNodeListGetString(doc, son2_node->xmlChildrenNode, 1);
                        if (key == NULL)
                        {
                            buffer_append_string(b, "down-replace=\r\n");
                        }
                        else
                        {
                            snprintf(res, sizeof(res), "down-replace=%s\r\n", (char *) key);
                            buffer_append_string(b, res);
                            xmlFree(key);
                        }
                      }

                      else if (!xmlStrcmp(son2_node->name, (const xmlChar *)"clearOld"))
                      {
                        key = xmlNodeListGetString(doc, son2_node->xmlChildrenNode, 1);
                        if (key == NULL)
                        {
                            buffer_append_string(b, "down-clear=\r\n");
                        }
                        else
                        {
                            snprintf(res, sizeof(res), "down-clear=%s\r\n", (char *) key);
                            buffer_append_string(b, res);
                            xmlFree(key);
                        }
                    }

                      else if (!xmlStrcmp(son2_node->name, (const xmlChar *)"interval"))
                      {
                        key = xmlNodeListGetString(doc, son2_node->xmlChildrenNode, 1);
                        if (key == NULL)
                        {
                            buffer_append_string(b, "down-interval=\r\n");
                        }
                        else
                        {
                            snprintf(res, sizeof(res), "down-interval=%s\r\n", (char *) key);
                            buffer_append_string(b, res);
                            xmlFree(key);
                        }
                    }
                      else if (!xmlStrcmp(son2_node->name, (const xmlChar *)"encoding"))
                        {
                            key = xmlNodeListGetString(doc, son2_node->xmlChildrenNode, 1);
                            if (key == NULL)
                            {
                                buffer_append_string(b, "down-encode=\r\n");
                            }
                            else
                            {
                                snprintf(res, sizeof(res), "down-encode=%s\r\n", (char *) key);
                                buffer_append_string(b, res);
                                xmlFree(key);
                            }
                        }

                    son2_node = son2_node->next;

                }
            }
            */
        }
    }

    xmlFreeDoc(doc);
    return 1;
}

static int handle_putportphbk (buffer *b, const struct message *m) {
    const char *path = NULL;
    const char *flag = NULL;
    const char *opmode = NULL;
    const char *portType = NULL;
    const char *portReplace = NULL;
    const char *portClear = NULL;
    const char *portEncode = NULL;
    const char *resType = NULL;
    const char *jsonCallback = NULL;
    const char *status = NULL;
    char *json = NULL;
    char *result = NULL;
    char *temp = NULL;
    int len = 0;
    int reply_timeout = 10000;
    DBusMessage *message = NULL;
    DBusMessage *reply = NULL;
    DBusBusType type;
    DBusError error;
    DBusConnection *conn = NULL;
    DBusMessageIter iter;

    resType = msg_get_header(m, "format");
    if (resType != NULL && !strcasecmp(resType, "json")) {
        jsonCallback = msg_get_header(m, "jsoncallback");
    }

    flag = msg_get_header(m, "flag");
    if (flag == NULL) {
        if (jsonCallback != NULL) {
            result = malloc((strlen(jsonCallback) + 64) * sizeof(char));
            if (result != NULL) {
                sprintf(result, "%s({\"res\": \"error\", \"flag\": \"null\"})", jsonCallback);
                buffer_append_string(b, result);
                free(result);
            }
        } else {
            buffer_append_string(b, "{\"res\": \"error\", \"flag\": \"null\"}");
        }
    }

    status = nvram_get("phonebook_status");
    if (status != NULL && !strcasecmp(status, "1")) {
        if (jsonCallback != NULL) {
            result = malloc((strlen(jsonCallback) + 64) * sizeof(char));
            if (result != NULL) {
                sprintf(result, "%s({\"res\": \"success\", \"portphbkresponse\": \"1\"})", jsonCallback);
                buffer_append_string(b, result);
                free(result);
            }
        } else {
            buffer_append_string(b, "{\"res\": \"success\", \"portphbkresponse\": \"1\"}");
        }

        return 0;
    }

    opmode = msg_get_header(m, "opmode");
    if (opmode == NULL) {
        opmode = "";
    }
    portEncode = msg_get_header(m, "portEncode");
    if (portEncode == NULL) {
        portEncode = "";
    }
    portType = msg_get_header(m, "portType");
    if (portType == NULL) {
        portType = "";
    }
    portReplace = msg_get_header(m, "portReplace");
    if (portReplace == NULL) {
        portReplace = "";
    }
    portClear = msg_get_header(m, "portClear");
    if (portClear == NULL) {
        portClear = "";
    }

    if( access( TMP_PHONEBOOKPATH, 0 ) )
    {
        mkdir(TMP_PHONEBOOKPATH, 0777);
    }

    path = malloc(strlen(TMP_PHONEBOOKPATH) + strlen("/phonebook.xml") + 4);
    sprintf(path, "%s/%s", TMP_PHONEBOOKPATH, "phonebook.xml");

    if ( 0 == access(path, 0) ) {
        chmod(path, 0777);
    }

    if (!strcasecmp(flag, "0")) {
        message = dbus_message_new_method_call(dbus_dest, dbus_path, dbus_interface, "exportPhonebook");
        printf("handle_exportPhonebook");

    } else {
        message = dbus_message_new_method_call(dbus_dest, dbus_path, dbus_interface, "importPhonebook");
        printf("handle_importPhonebook");
    }

    type = DBUS_BUS_SYSTEM;
    dbus_error_init(&error);
    conn = dbus_bus_get(type, &error);
    if (conn == NULL) {
        printf("Failed to open connection to %s message bus: %s\n", (type == DBUS_BUS_SYSTEM) ? "system" : "session", error.message);
        dbus_error_free(&error);
        if (message != NULL) {
            dbus_message_unref(message);
        }
        free(path);

        return -1;
    }

    if (message != NULL) {
        dbus_message_set_auto_start(message, TRUE);
        dbus_message_iter_init_append(message, &iter);

        len = 8;
        if (opmode != NULL) {
            len += strlen(opmode) + strlen(", \"mode\": \"\"");
        }
        if (portEncode != NULL) {
            len += strlen(portEncode) + strlen(", \"encode\": \"\"");
        }
        if (portType != NULL) {
            len += strlen(portType) + strlen(", \"type\": \"\"");
        }
        if (portReplace != NULL) {
            len += strlen(portReplace) + strlen(", \"replace\": \"\"");
        }
        if (portClear != NULL) {
            len += strlen(portClear) + strlen(", \"clear\": \"\"");
        }
        len += strlen(path) + strlen(", \"path\": \"\"");

        json = malloc(len * sizeof(char));
        if (json != NULL) {
            snprintf(json, len-1, 
                     "{\"path\": \"%s\", \"mode\": \"%s\", \"encode\": \"%s\", \"type\": \"%s\", \"replace\": \"%s\", \"clear\": \"%s\"}",
                     path, opmode, portEncode, portType, portReplace, portClear);

            if (!dbus_message_iter_append_basic(&iter, DBUS_TYPE_STRING, &json)) {
                printf("Out of Memory!\n");
                free(path);
                free(json);
                exit(1);
            }

            nvram_set("phonebook_status", "99");

            reply = dbus_connection_send_with_reply_and_block(conn, message, reply_timeout, &error);
            if (dbus_error_is_set(&error)) {
                fprintf(stderr, "Error %s: %s\n", error.name, error.message);
            }

            free(json);

            if (reply) {
                print_message(reply);
                int current_type;
                dbus_message_iter_init(reply, &iter);
                
                while((current_type = dbus_message_iter_get_arg_type(&iter)) != DBUS_TYPE_INVALID) {
                    switch(current_type) {
                        case DBUS_TYPE_STRING:
                            dbus_message_iter_get_basic(&iter, &result);
                            break;
                        default:
                            break;
                    }

                    dbus_message_iter_next(&iter);
                }

                if (result != NULL) {
                    if (jsonCallback != NULL) {
                        temp = malloc((strlen(jsonCallback) + strlen(result) + 8) * sizeof(char));
                        if (temp != NULL) {
                            sprintf(temp, "%s(%s)", jsonCallback, result);
                            buffer_append_string(b, temp);
                            free(temp);
                        }
                    } else {
                        buffer_append_string(b, "Response=Success\r\n");
                        buffer_append_string(b, result);
                    }
                }

                dbus_message_unref(reply);
            }
        }

        dbus_message_unref(message);
    }

    free(path);

    return 0;
}

static int handle_putdownphbk (buffer *b, const struct message *m) {
    char res[128];
    const char *flag = NULL;
    const char *opmode = NULL;
    const char *serverUrl = NULL;
    const char *interval = NULL;
    const char *downReplace = NULL;
    const char *downClear = NULL;
    const char *downEncode = NULL;
    const char *resType = NULL;
    const char *jsonCallback = NULL;
    const char *status = NULL;
    char *json = NULL;
    char *result = NULL;
    char *temp = NULL;
    int len = 0;
    int reply_timeout = 10000;
    DBusMessage *message = NULL;
    DBusMessage *reply = NULL;
    DBusBusType type;
    DBusError error;
    DBusConnection *conn = NULL;
    DBusMessageIter iter;

    status = nvram_get("phonebook_status");
    if (status != NULL && !strcasecmp(status, "1")) {
        if (jsonCallback != NULL) {
            result = malloc((strlen(jsonCallback) + 64) * sizeof(char));
            if (result != NULL) {
                sprintf(result, "%s({\"res\": \"success\", \"phbkresponse\": \"1\"})", jsonCallback);
                buffer_append_string(b, result);
                free(result);
            }
        } else {
            buffer_append_string(b, "{\"res\": \"success\", \"phbkresponse\": \"1\"}");
        }

        return 0;
    }

    resType = msg_get_header(m, "format");
    if (resType != NULL && !strcasecmp(resType, "json")) {
        jsonCallback = msg_get_header(m, "jsoncallback");
    }

    flag = msg_get_header(m, "flag");
    if (flag == NULL) {
        flag = "1";
    }

    opmode = msg_get_header(m, "downMode");
    if (opmode == NULL) {
        opmode = "";
    }
    serverUrl = msg_get_header(m, "downUrl");
    uri_decode(serverUrl);
    if (serverUrl == NULL) {
        serverUrl = "";
    }
    interval = msg_get_header(m, "downInterval");
    if (interval == NULL) {
        interval = "";
    }
    downReplace = msg_get_header(m, "downReplace");
    if (downReplace == NULL) {
        downReplace = "";
    }
    downClear = msg_get_header(m, "downClear");
    if (downClear == NULL) {
        downClear = "";
    }
    downEncode = msg_get_header(m, "downEncode");
    if (downEncode == NULL) {
        downEncode = "";
    }

    message = dbus_message_new_method_call(dbus_dest, dbus_path, dbus_interface, "downloadPhonebook");

    type = DBUS_BUS_SYSTEM;
    dbus_error_init(&error);
    conn = dbus_bus_get(type, &error);
    if (conn == NULL) {
        printf("Failed to open connection to %s message bus: %s\n", (type == DBUS_BUS_SYSTEM) ? "system" : "session", error.message);
        dbus_error_free(&error);
        if (message != NULL) {
            dbus_message_unref(message);
        }

        return -1;
    }

    if (message != NULL) {
        dbus_message_set_auto_start(message, TRUE);
        dbus_message_iter_init_append(message, &iter);

        len = 8;
        if (opmode != NULL) {
            len += strlen(opmode) + strlen(", \"mode\": \"\"");
        }
        if (serverUrl != NULL) {
            len += strlen(serverUrl) + strlen(", \"url\": \"\"");
        }
        if (interval != NULL) {
            len += strlen(interval) + strlen(", \"interval\": \"\"");
        }
        if (downReplace != NULL) {
            len += strlen(downReplace) + strlen(", \"replace\": \"\"");
        }
        if (downClear != NULL) {
            len += strlen(downClear) + strlen(", \"clear\": \"\"");
        }
        if (downEncode != NULL) {
            len += strlen(downEncode) + strlen(", \"encode\": \"\"");
        }
        len += strlen(flag) + strlen(", \"flag\": \"\"");

        json = malloc(len * sizeof(char));
        if (json != NULL) {
            snprintf(json, len-1, 
                     "{\"flag\": \"%s\", \"mode\": \"%s\", \"url\": \"%s\", \"interval\": \"%s\", \"replace\": \"%s\", \"clear\": \"%s\", \"encode\": \"%s\"}",
                     flag, opmode, serverUrl, interval, downReplace, downClear, downEncode);

            if (!dbus_message_iter_append_basic(&iter, DBUS_TYPE_STRING, &json)) {
                printf("Out of Memory!\n");
                free(json);
                exit(1);
            }

            nvram_set("phonebook_status", "99");

            reply = dbus_connection_send_with_reply_and_block(conn, message, reply_timeout, &error);
            if (dbus_error_is_set(&error)) {
                fprintf(stderr, "Error %s: %s\n", error.name, error.message);
            }

            free(json);

            if (reply) {
                print_message(reply);
                int current_type;
                dbus_message_iter_init(reply, &iter);
                
                while((current_type = dbus_message_iter_get_arg_type(&iter)) != DBUS_TYPE_INVALID) {
                    switch(current_type) {
                        case DBUS_TYPE_STRING:
                            dbus_message_iter_get_basic(&iter, &result);
                            break;
                        default:
                            break;
                    }

                    dbus_message_iter_next(&iter);
                }

                if (result != NULL) {
                    if (jsonCallback != NULL) {
                        temp = malloc((strlen(jsonCallback) + strlen(result) + 8) * sizeof(char));
                        if (temp != NULL) {
                            sprintf(temp, "%s(%s)", jsonCallback, result);
                            buffer_append_string(b, temp);
                            free(temp);
                        }
                    } else {
                        if ((resType != NULL) && !strcasecmp(resType, "json"))
                        {
                            buffer_append_string(b, result);
                        }
                        else
                        {
                            snprintf(res, sizeof(res), "flag=%s\r\n", flag);
                            buffer_append_string(b, res);
                        }
                    }
                }

                dbus_message_unref(reply);
            }
        }

        dbus_message_unref(message);
    }

    return 0;
}

static int handle_portphbkresponse (buffer *b, const struct message *m) {
    const char* resType = NULL;
    const char* jsonCallback = NULL;
    char* status = NULL;
    char* result = NULL;

    resType = msg_get_header(m, "format");
    if (resType != NULL && !strcasecmp(resType, "json")) {
        jsonCallback = msg_get_header(m, "jsoncallback");
    }

    status = nvram_get("phonebook_status");
    if (status != NULL) {
        if (!strcasecmp(status, "1")) {
            status = "1";
        } else if (!strcasecmp(status, "99")) {
            status = "1";
        } else if (!strcasecmp(status, "4")) {
            status = "4";
        } else if (!strcasecmp(status, "0")) {
            status = "0";
        }

        if (jsonCallback != NULL) {
            result = malloc((strlen(jsonCallback) + 64) * sizeof(char));
            if (result != NULL) {
                sprintf(result, "%s({\"res\": \"success\", \"portphbkresponse\": \"%s\"})", jsonCallback, status);
                buffer_append_string(b, result);
                free(result);
            }
        } else {
            result = malloc(64 * sizeof(char));
            if (result != NULL) {
                buffer_append_string (b, "Response=Success\r\n");
                sprintf(result, "portphbkresponse=%s\r\n", status);
               // sprintf(result, "{\"res\": \"success\", \"portphbkresponse\": \"%s\"}", status);
                buffer_append_string(b, result);
                free(result);
            }
        }
    }

    return 0;
}

static int handle_phbkresponse (buffer *b, const struct message *m) {
    const char* resType = NULL;
    const char* jsonCallback = NULL;
    char* status = NULL;
    char* result = NULL;

    resType = msg_get_header(m, "format");
    if (resType != NULL && !strcasecmp(resType, "json")) {
        jsonCallback = msg_get_header(m, "jsoncallback");
    }

    status = nvram_get("phonebook_status");
    if (status != NULL) {
        if (!strcasecmp(status, "1")) {
            status = "1";
        } else if (!strcasecmp(status, "99")) {
            status = "9";
        } else if (!strcasecmp(status, "4")) {
            status = "4";
        } else if (!strcasecmp(status, "0")) {
            status = "0";
        }

        if (jsonCallback != NULL) {
            result = malloc((strlen(jsonCallback) + 64) * sizeof(char));
            if (result != NULL) {
                sprintf(result, "%s({\"res\": \"success\", \"phbkresponse\": \"%s\"})", jsonCallback, status);
                buffer_append_string(b, result);
                free(result);
            }
        } else {
            result = malloc(64 * sizeof(char));
            if (result != NULL) {
                buffer_append_string (b, "Response=Success\r\n");
                sprintf(result, "phbkresponse=%s\r\n", status);
               // sprintf(result, "{\"res\": \"success\", \"phbkresponse\": \"%s\"}", status);
                buffer_append_string(b, result);
                free(result);
            }
        }
    }

    return 0;
}


/*static int handle_lanrsps(buffer *b)
{
    char res[32] = "";

    buffer_append_string (b, "Response=Success\r\n");
    
    snprintf(res, sizeof(res), "lanrsps=%d\r\n", lan_reload_flag);
    buffer_append_string(b, res);
    
    return 0;
}
*/

static int handle_setsyslogd(buffer *b)
{
    system("setprop ctl.start syslogd");
    buffer_append_string(b, "Response=Success\r\n");
    return 1;
}

static int handle_exec_command(buffer *b, const struct message *m)
{
    const char *cmd = NULL;
    cmd = msg_get_header(m, "command");
    int result = -1;

    if( cmd != NULL )
    {
        uri_decode(cmd);
        result = system(cmd);
    }

    if( result == 0 )
        buffer_append_string(b, "Response=Success\r\n");
    else
        buffer_append_string(b, "Response=Error\r\n");
    return 1;
}

static int handle_clearlogcat (buffer *b)
{
    int result = system("logcat -c");
    if(result == 0)
    {
        buffer_append_string (b, "Response=Success\r\n");
    }else
        buffer_append_string (b, "Response=Error\r\n");
    return 1;
}

static int handle_getlogcat (buffer *b, const struct message *m)
{
    const char *tag = NULL;
    const char *priority = NULL;
    char cmd[128] = "";

    tag = msg_get_header(m, "tag");
    if( tag == NULL || strcasecmp(tag, "") == 0 )
        tag = "*";
    priority = msg_get_header(m, "priority");
    if( priority == NULL )
        priority = "*";
    snprintf(cmd, sizeof(cmd), "logcat -ds %s:%s > /tmp/logcat.txt &", tag, priority);
    printf("cmd is %s\n",cmd);
    int result = system(cmd);
    if(result == 0)
    {
        buffer_append_string (b, "Response=Success\r\n");
    }else
        buffer_append_string (b, "Response=Error\r\n");
    return 1;
}

static int handle_getlanguages (buffer *b)
{
    system("getprop persist.sys.language > /tmp/language");
    system("getprop persist.sys.country > /tmp/country");
    FILE *fp = fopen("/tmp/language", "r");
    FILE *fp2 = fopen("/tmp/country", "r");
    char lan[3] = "";
    char country[3] = "";
    if (fp == NULL || fp2 == NULL)
    {
        buffer_append_string (b, "Response=Success\r\nlanguage=en_US\r\n");
        return -1;
    }

    fgets( &lan, sizeof(lan), fp );
    fclose(fp);
    fgets( &country, sizeof(country), fp2 );
    fclose(fp2);
    buffer_append_string (b, "Response=Success\r\nlanguage=");
    buffer_append_string (b, lan);
    buffer_append_string (b, "_");
    buffer_append_string (b, country);
    buffer_append_string (b, "\r\n");

    return 1;
}

static int handle_putlanguage (buffer *b, const struct message *m)
{
    const char *lan = NULL;
    const char *country = NULL;
    char cmd[128] = "";

    lan = msg_get_header(m, "lan");
    country = msg_get_header(m, "country");
    snprintf(cmd, sizeof(cmd), "am broadcast -a com.android.settings.LanguageUpdate -e \"language\" \"%s\" -e \"country\" \"%s\"", lan, country);
    system(cmd);
    printf("cmd is %s\n", cmd);
    buffer_append_string (b, "Response=Success\r\n");
    return 0;
}

static int handle_saveconf(buffer *b)
{
    int result = system("nvram show > /tmp/configold.txt");
    if( result != 0 )
    {
        buffer_append_string (b, "Response=Error\r\n");
        return -1;
    }

    FILE *file_fd = NULL;
    file_fd = fopen("/tmp/config", "w+");
    if( file_fd == NULL )
    {
        buffer_append_string (b, "Response=Error\r\n");
        return -1;
    }

    FILE *fp = fopen( "/tmp/configold.txt" , "r");
    char * line = NULL;
    char *var = NULL;
    int tpvalue;
    char *strToWrite = NULL;
    int sizeOfStrToWrite = 256;
    line = malloc(sizeOfStrToWrite);
    memset(line, 0, sizeOfStrToWrite);

    while ((  fp != NULL) && !feof( fp ) )
    {
        fgets( line, sizeOfStrToWrite, fp );
        strToWrite = malloc( sizeOfStrToWrite );
        memset(strToWrite, 0, sizeOfStrToWrite);
        snprintf(strToWrite, sizeOfStrToWrite, "P%s", line);
        var = strtok( line, "=");
        if ( var != NULL )
        {
            tpvalue = atoi(var);
            if( tpvalue == 0 )
                continue;
            switch(tpvalue)
            {
                case 34:        /*acct1-6 sip account passwords*/
                case 406:
                case 506:
                case 606:
                case 1706:
                case 1806:
                case 2:         /*admin password*/
                case 196:       /*user password*/
                case 1361:      /*http password*/
                case 1359:      /*xml password*/
                case 7903:      /*802.1x MD5 password*/
                case 83:        /*PPPoE password*/
                case 4505:      /*ACS password*/
                case 4512:      /*ACS connect password*/
                case 8024:      /*LDAP password*/
                case 279:       /*SIP TLS Certificate*/
                case 280:       /*SIP TLS Private Key*/
                case 281:       /*SIP TLS private key password*/
                case 1383:      /*Lock/Unlock password*/
                case 2352:      /*acct1-6 Auto User Presence password*/
                case 2452:
                case 2552:
                case 2652:
                case 2752:
                case 2852:
                    break;
                default:
                    fwrite(strToWrite, strlen(strToWrite), 1, file_fd);
                    break;
            }
        }
        free(strToWrite);
        memset(line, 0, sizeof(line));
    }

    buffer_append_string (b, "Response=Success\r\n");
    free(line);
    fclose( fp );
    fclose( file_fd );
    unlink("/tmp/configold.txt");
    return 1;
}

static int handle_cfupdated (buffer *b)
{
    buffer_append_string (b, "Response=Success\r\n");
    dbus_send_cfupdated();
    return 1;
}

static int handle_vbupdated (buffer *b, const struct message *m)
{
    const char *temp = NULL;
    temp = msg_get_header(m, "account");
    if (temp == NULL)
    {
        buffer_append_string (b, "Response=ERROR\r\nMessage=Missed Parameter\r\n");
    }else
    {
        buffer_append_string (b, "Response=Success\r\n");
        int account = atoi(temp);
#ifdef BUILD_ON_ARM
        DBusMessage* message;

        if ( bus == NULL )
        {
            printf( "Error: Dbus bus is NULL\n" );
            return 1;
        }

        message = dbus_message_new_signal( DBUS_PATH, DBUS_INTERFACE, SIGNAL_VBRATEUPDATED);
        if ( message == NULL )
        {
            printf( "message is NULL\n" );
            return 1;
        }

        dbus_message_append_args( message,  DBUS_TYPE_INT32, &account, DBUS_TYPE_INVALID );
        dbus_message_append_args( message,  DBUS_TYPE_INVALID );

        dbus_connection_send( bus, message, NULL );
        dbus_message_unref( message );
#endif
    }
    return 1;
}

static int handle_autoanswer(buffer *b, const struct message *m)
{
    const char *account = NULL;
    const char *value = NULL;
    int acct_code = 0;
    int val_code = 0;

    account = msg_get_header(m, "acct");
    value = msg_get_header(m, "value");
    if ((account == NULL) || (value == NULL))
    {
        buffer_append_string (b, "Response=ERROR\r\nMessage=Missed Parameter\r\n");
    }
    else
    {
        sscanf (account, "%d", &acct_code);
        sscanf (value, "%d", &val_code);

        if (acct_code < 1 || acct_code > 3 || val_code < 0 || val_code > 1)
        {
            buffer_append_string (b, "Response=ERROR\r\nMessage=Parameter Invalid\r\n");
        }
        else
        {
            buffer_append_string (b, "Response=Success\r\n");
            dbus_send_lighttpd(SIGNAL_ACCT1_AUTO_ANSWER_OFF + 2 *(acct_code - 1) + val_code);
        }
    }

    return 1;
}

static int dbus_send_callforward(const int arg1, const char *arg2)
{
#ifdef BUILD_ON_ARM
    DBusMessage* message;

    if ( bus == NULL )
    {
        printf( "Error: Dbus bus is NULL\n" );
        return 1;
    }

    message = dbus_message_new_signal( DBUS_PATH, DBUS_INTERFACE, SIGNAL_CALLFORWARD);
    if ( message == NULL )
    {
        printf( "message is NULL\n");
        return 1;
    }

    dbus_message_append_args( message, DBUS_TYPE_INT32, &arg1, DBUS_TYPE_STRING, &arg2, DBUS_TYPE_INVALID );

    dbus_connection_send( bus, message, NULL );
    dbus_message_unref( message );
#endif

    return 0;
}

static int handle_callforward(buffer *b, const struct message *m)
{
    const char *account = NULL;
    const char *value = NULL, *type = NULL;
    int acct_code = 0;
    int val_code = 0;

    account = msg_get_header(m, "acct");
    value = msg_get_header(m, "value");
    type = msg_get_header(m, "type");
    if ((account == NULL) || (value == NULL && type == NULL) )
    {
        buffer_append_string (b, "Response=ERROR\r\nMessage=Missed Parameter\r\n");
    }
    else
    {
        sscanf (account, "%d", &acct_code);
        if( value != NULL )
        {
            sscanf (value, "%d", &val_code);

            if (acct_code < 1 || acct_code > 3 || val_code < 0 || val_code > 1)
            {
                buffer_append_string (b, "Response=ERROR\r\nMessage=Parameter Invalid\r\n");
            }
            else
            {
                buffer_append_string (b, "Response=Success\r\n");
                dbus_send_lighttpd( SIGNAL_ACCT1_TRANSFER_OFF + 2 *(acct_code - 1) + val_code);
            }
        }else if( type != NULL )
        {
            buffer_append_string (b, "Response=Success\r\n");
            dbus_send_callforward((acct_code - 1), type);
        }

    }

    return 1;
}

/*static int handle_settimezone (buffer *b, const struct message *m)
{
    const char *temp = NULL;
    char val[256] = "";
    char cmd[256] = "";

    temp = msg_get_header(m, "timezone");
    if (temp == NULL)
    {
        buffer_append_string (b, "Response=Miss parater\r\n");
        return -1;
    }
    memset(val, 0, sizeof(val));
    memset(cmd, 0, sizeof(cmd));
    strncpy(val, temp, sizeof(val) - 1);
    uri_decode(val);
    char * c_ptr = nvram_get("override_time_zone");
    if ( ( c_ptr == NULL ) || ( strlen ( c_ptr ) == 0 ) )
    {
        snprintf(cmd, sizeof(cmd), "/bin/echo \"%s\" > /etc/TZ", val);
        system(cmd);
    }

    buffer_append_string (b, "Response=Success\r\n");
    dbus_send_lighttpd( SIGNAL_LIGHTTPD_TIMEZONE_CHANGED);
    return 1;
}
*/

static int handle_savetimeset (buffer *b, const struct message *m)
{
    const char *temp = NULL;
    char cmd[128] = "";
    int result;

    temp = msg_get_header(m, "timezone");
    if (temp != NULL)
    {
        memset(cmd, 0, sizeof(cmd));
        snprintf(cmd, sizeof(cmd), "setprop persist.sys.timezone %s", temp);
        result = system(cmd);
        if(result == 0)
        {
            memset(cmd, 0, sizeof(cmd));
            snprintf(cmd, sizeof(cmd), "am broadcast -a android.intent.action.TIMEZONE_CHANGED -e time-zone %s", temp);
            system(cmd);
        }
    }
    temp = msg_get_header(m, "timefmt");
    if (temp != NULL)
    {
        memset(cmd, 0, sizeof(cmd));
        snprintf(cmd, sizeof(cmd), "am broadcast -a android.intent.action.TIME_SET_SYNC -e time_12_24 %s", temp);
        result = system(cmd);
    }
    temp = msg_get_header(m, "datefmt");
    if (temp != NULL)
    {
        memset(cmd, 0, sizeof(cmd));
        snprintf(cmd, sizeof(cmd), "am broadcast -a android.intent.action.DATE_FORMAT_SYNC -e date_format %s", temp);
        result = system(cmd);
    }
    temp = msg_get_header(m, "auto");
    if (temp != NULL)
    {
        const char *usentp, *ntpserver = NULL;
        usentp = msg_get_header(m, "usentp");
        ntpserver = msg_get_header(m, "ntpserver");
        if( usentp != NULL && ntpserver != NULL )
        memset(cmd, 0, sizeof(cmd));
        snprintf(cmd, sizeof(cmd), "am broadcast -a com.base.module.setting.ntp_set -e auto_time %s -e use_defined_addr %s -e defined_addr \"%s\"", temp, usentp, ntpserver);
        result = system(cmd);
    }
    buffer_append_string (b, "Response=Success\r\n");
    return 1;
}

void print_offset(buffer *b, long millis_offsets[], int n)
{
    int i;
    int hour, min;
    long offset;
    char sign;
    char gmtvalue[16] = "";
    for (i = 0; i < n; i++)
    {
        offset = millis_offsets[i] / 60000;
        sign = '+';
        if(offset < 0)
        {
            offset = - offset;
            sign = '-';
        }
        hour = (int)(offset/60);
        min  = (int)(offset%60);

        printf("%d, GMT%c%d:%02d\n", i, sign, hour, min);
        if( i == 0 )
        {
            snprintf(gmtvalue, sizeof(gmtvalue), "\"GMT%c%d:%02d\"", sign, hour, min );
        }else
        {
            snprintf(gmtvalue, sizeof(gmtvalue), ",\"GMT%c%d:%02d\"", sign, hour, min );
        }
        buffer_append_string(b, gmtvalue);
    }
}

static int handle_gettimezone (buffer *b)
{
    void *dp;
    int n, i;
    long *result;

    system("getprop persist.sys.timezone > /tmp/timezone");
    FILE *fp = fopen("/tmp/timezone", "r");
    char line[32] = "";

    if (fp == NULL)
        return -1;

    fgets( &line, sizeof(line), fp );
    fclose(fp);
    snprintf(line, strlen(line), "%s", line);

    buffer_append_string(b, "{\"Response\":\"Success\",");
    buffer_append_string(b, "\"timezone\":\"");
    buffer_append_string(b, (char *) line);
    buffer_append_string(b, "\",\"citygmt\":[");
    //dp=dlopen(SOFILE, RTLD_LAZY);
    //get_timezone_offset = dlsym(dp,"get_timezone_offset");

    //if(get_timezone_offset) {
        n = sizeof(ids)/sizeof(ids[0]);
        result = (long*)malloc(n * sizeof(long));

        //czheng
	//get_timezone_offset(ids, n, result);
        print_offset(b, result, n);

        free(result);
    //}
    buffer_append_string(b, "]}");

/*    buffer_append_string (b, "Response=Success\r\ntimezone=");
    buffer_append_string (b, line);
    buffer_append_string (b, "\r\n");*/

    return 1;
}

static int handle_capture (buffer *b, const struct message *m)
{
    const char *temp = NULL;
	struct statfs fs;
	long long freespace = 0;
	long long pcap_size = 0;

    temp = msg_get_header(m, "mode");
    if (!strcasecmp(temp, "on"))
    {
        capmode = 1;
        printf("timestr is on\n");
        if( access(PCAP_PATH, 0) ) {
            mkdir(PCAP_PATH, 0777);
        }
        time_t timer;
        struct tm *tblock;

        /* gets time of day */
        timer = time(NULL);

        /* converts date/time to a structure */
        tblock = localtime(&timer);
        char timestr[32] = "";
        snprintf(timestr, sizeof(timestr), "%4d%02d%02d%02d%02d%02d", 1900+tblock->tm_year, 1+tblock->tm_mon, tblock->tm_mday, tblock->tm_hour, tblock->tm_min, tblock->tm_sec );
        printf("timestr is %s\n", timestr);

		if (statfs(PCAP_PATH, &fs) < 0)
			return -1;
		freespace = (((long long)fs.f_bsize*(long long)fs.f_bfree)/(long long)1024);
		printf("free space: %lld\n", freespace);

		pcap_size = (freespace/(long long)(2*1024));
		printf("pcap_size: %lld\n", pcap_size);

		if(pcap_size <= 100)
		{
			buffer_append_string (b, "Response=Error\r\n");
			return -1;
		}

        char cmdstr[128] = "";
        //snprintf(cmdstr, sizeof(cmdstr), "tcpdump -s 0 -w %s/%s.pcap &", PCAP_PATH, timestr);
		snprintf(cmdstr, sizeof(cmdstr), "tcpdump -s 0 -w %s/%s.pcap -C %lld -W 1 &", PCAP_PATH, timestr, pcap_size);
        printf("cmdstr is %s\n", cmdstr);
        system(cmdstr);
        buffer_append_string (b, "Response=Success\r\n");
    }else if (!strcasecmp(temp, "off"))
    {
        capmode = 0;
        system("killall -9 tcpdump");
        buffer_append_string (b, "Response=Success\r\n");
    }else if (!strcasecmp(temp, "mode")) {
        buffer_append_string (b, "Response=Success\r\n");
        if (capmode == 1)
        {
            buffer_append_string(b, "mode=on\r\n");
        } else {
            buffer_append_string(b, "mode=off\r\n");
        }
    }

    return 1;
}

char* substr(const char*str, unsigned start, unsigned end)
{
    unsigned n = end - start;
    static char stbuf[256];
    strncpy(stbuf, str + start, n);
    stbuf[n] = 0;
    return stbuf;
}

int file_manager_file_copy(const char *old_file, const char *new_file)
{
    FILE *old_fd = NULL, *new_fd = NULL;
    char *buf = NULL;
    size_t len = 0;

    if (old_file == NULL || new_file == NULL ||
        old_file[0] == '\0' || new_file[0] == '\0')
    {
        return -1;
    }

    old_fd = fopen(old_file, "r+");
    new_fd = fopen(new_file, "w+");
    if (old_fd == NULL || new_fd == NULL)
    {
        if (old_fd != NULL)
        {
            fclose(old_fd);
            return -2;
        }
        if (new_fd != NULL)
        {
            fclose(new_fd);
            return -3;
        }
    }

    buf = malloc(1024 * 8);
    while (feof(old_fd) == 0)
    {
        len = fread(buf, 1, 1024 * 8, old_fd);
        fwrite(buf, 1, len, new_fd);
    }
    free(buf);
    fflush(new_fd);
    fclose(new_fd);
    fclose(old_fd);

    return 0;
}

static int dbus_send_lighttpd ( const int arg1 )
{
#ifdef BUILD_ON_ARM
    DBusMessage* message;

    if ( bus == NULL )
    {
        printf( "Error: Dbus bus is NULL\n" );
        return 1;
    }

    message = dbus_message_new_signal( DBUS_PATH, DBUS_INTERFACE, SIGNAL_LIGHTTPD);
    if ( message == NULL )
    {
        printf( "message is NULL\n");
        return 1;
    }

    dbus_message_append_args( message, DBUS_TYPE_INT32, &arg1, DBUS_TYPE_INVALID );

    dbus_connection_send( bus, message, NULL );
    dbus_message_unref( message );
#endif

    return 0;
}

static int handle_gettonename(buffer *b, const struct message *m)
{
    int x, len;
    char hdr[64] = "";
    char *res = NULL;
    char *tempval = NULL;
    const char *val = NULL, *var = NULL;
    char *ptr;

    buffer_append_string(b, "Response=Success\r\n");

    for (x = 0; x < 10000; x++) {
    	snprintf(hdr, sizeof(hdr), "var-%04d", x);
    	var = msg_get_header(m, hdr);

    	if ((!var || (*var == '\0')))
    		break;
#ifdef BUILD_ON_ARM
        val = nvram_my_get(var);
#else
        val = "0";
#endif

        if(strlen(val) == 0)
        {
            buffer_append_string(b, var);
            buffer_append_string(b, "=Ring tone 1\r\n");
            continue;
        }else if(strlen(val) == 1){
            tempval = malloc( 16 );
            snprintf(tempval, 16, "Ring tone %d", atoi(val) + 1);
            //printf("ddddddddddddd is- %s---\r\n", tempval);
        }
        else {
            ptr = strrchr(val, '/');
            if(ptr == NULL)
                continue;
            tempval = strdup(ptr+1);
        }
        
        uri_decode(tempval);
        len = strlen(var) + strlen(tempval) + 4;
        res = malloc(len);
        snprintf(res, len, "%s=%s\r\n", var, tempval);
        buffer_append_string(b, res);
        /*buffer_append_string(b, var);
        buffer_append_string(b, "=");
        buffer_append_string(b, tempval);
        buffer_append_string(b, "\r\n");*/
        free(tempval);
        free(res);
    }

    return 0;
}

static int handle_getnetwork(buffer *b)
{
    printf("-----handle_getnetwork--\n");
    sqlite3 *db;
    int rc;
    char * errmsg = NULL;
    char **dbResult;
    int nRow, nColumn;
    int i , j;
    int index;
    char *sqlstr = NULL, *resstr = NULL;

    rc = sqlite3_open("/data/data/com.android.providers.settings/databases/settings.db", &db);
    if( rc ){
        printf(stderr, "Can't open database: %s\n", sqlite3_errmsg(db));
        sqlite3_close(db);
        return 0;
    }
    buffer_append_string(b, "Response=Success\r\n");
    const char *netval[5] = {"eth_ip", "eth_mask", "eth_route", "eth_dns", "eth_dns2"};

    for( int si = 0; si < 5; si ++ )
    {
        printf("fined %d\n", si);
        sqlstr = malloc(64);
        snprintf(sqlstr, 64, "select * from secure where name=\"%s\";", netval[si]);
        printf("fined str %s\n", sqlstr);
        rc = sqlite3_get_table ( db, sqlstr , &dbResult, &nRow, &nColumn, &errmsg );
        if( rc == SQLITE_OK )
        {
            printf("-----handle_ok 111111111--\n");
            index = nColumn;
            printf( "query %d records.\n", nRow );
            for( i = 0; i < nRow ; i++ )
            {
                printf("Record %d:\n" , i+1 );
                for( j = 0 ; j < nColumn; j++ )
                {
                    if( !strcasecmp(dbResult[j], "value") )
                    {
                        resstr = malloc(32);
                        if( dbResult[index] != NULL )
                            snprintf(resstr, 32, "%s=%s\r\n", netval[si], dbResult[index]);
                        else
                            snprintf(resstr, 32, "%s=\r\n", netval[si]);
                        buffer_append_string(b, resstr);
                        free(resstr);
                    }
                    printf( "index:%d, name:%s, value:%s\n", index, dbResult[j], dbResult[index] );
                    ++index;
                }
                printf("---index--%d--\n" , index);
            }
        }else
        {
            printf("-----handle_error 111111111--\n");
            resstr = malloc(32);
            snprintf(resstr, 32, "%s=\r\n", netval[si]);
            buffer_append_string(b, resstr);
            free(resstr);
            printf(stderr, "SQL error: %s\n", errmsg);
            sqlite3_free(errmsg);
        }
        free(sqlstr);
        sqlite3_free_table ( dbResult );
    }

    sqlite3_close(db);
    return 1;
}

static int handle_putnetwork(buffer *b, const struct message *m)
{
    system("am broadcast -a android.intent.action.ETHERNET_WEB_SAVED");
    buffer_append_string(b, "Response=Success\r\n");

    return 1;
}

static int handle_tonelist1 (buffer *b)
{
    printf("handle_tonelist\n");
    //const char *sqlstr = NULL;

    sqlite3 *db;
    int rc;
    char * errmsg = NULL;
    char **dbResult;
    int nRow, nColumn;
    int i , j, count = 0, isTone = 0, curId;
    int index, len;
    char *temp = NULL, *name = NULL, *path = NULL;

    rc = sqlite3_open("/data/data/com.android.providers.media/databases/external.db", &db);
    if( rc ){
        printf(stderr, "Can't open database: %s\n", sqlite3_errmsg(db));
        sqlite3_close(db);
        return 0;
    }
    printf("db open suc\n");
    /*rc = sqlite3_exec(db, sqlstr, callback, 0, &errmsg);
    if( rc!=SQLITE_OK )
    {
        printf(stderr, "SQL error: %s\n", errmsg);
        sqlite3_free(errmsg);
    }*/
    rc = sqlite3_get_table ( db, "select * from audio_meta where is_ringtone=1 order by title;" , &dbResult, &nRow, &nColumn, &errmsg );
    if( rc == SQLITE_OK )
    {
        index = nColumn;
        printf( "query %d records, nColumn is %d.\n", nRow, nColumn );
        buffer_append_string(b, "{\"Response\":\"Success\",\"Ringtone\":[");
        for( i = 0; i < nRow ; i++ )
        {
            printf("Record %d:\n" , i+1 );
            isTone = 0;
            for( j = 0 ; j < nColumn; j++ )
            {
                if( !strcasecmp(dbResult[j], "_id") )
                {
                    curId = atoi(dbResult[index]);
                }
                else if( !strcasecmp(dbResult[j], "_data") )
                {
                    /*if( strstr(dbResult[index], "/system/media/audio/ringtones/") != NULL)
                    {
                        isTone = 1;
                    }*/
					path = dbResult[index];
                }
				else if( !strcasecmp(dbResult[j], "title"))
				{
					len = strlen(dbResult[index]) + strlen(path) + 32;
					temp = malloc ( len );

					if(!count)
					{
						snprintf(temp, len, "{\"data\":\"%s\",\"title\":\"%s\"}", path, dbResult[index]);
					}
					else
					{
						snprintf(temp, len, ",{\"data\":\"%s\",\"title\":\"%s\"}", path, dbResult[index]);
					}
					count ++;
					buffer_append_string(b,temp);
					free(temp);
				}
					
				/*else if( !strcasecmp(dbResult[j], "title") )
                {
                    len =  strlen(dbResult[index]) + 32;
                    temp = malloc( len );
                    if(!count)
                    {
                        snprintf(temp, len, "\"%s(%d)\"", dbResult[index], curId);
                    }
                    else
                    {
                        snprintf(temp, len, ",\"%s(%d)\"", dbResult[index], curId);
                    }
                    count++;
                    buffer_append_string(b, temp);
                    free(temp);
                }*/
                //printf( "index:%d, name:%s, value:%s\n", index, dbResult[j], dbResult[index] );
                ++index;
            }
        }
        buffer_append_string(b, "]}");
    }else
    {
        printf(stderr, "SQL error: %s\n", errmsg);
        sqlite3_free(errmsg);
    }
    sqlite3_free_table ( dbResult );
    sqlite3_close(db);
    
    return 1;
    
}

static int handle_tonelist (buffer *b)
{
    struct dirent *dp;
    DIR *dir;
    char *ptr = NULL;
    int j=0,len;
    char name[256] = "";
    //char *fileExt = NULL;

    if( access( TONELIST_PATH, 0 ) )
    {
        buffer_append_string(b, "Response=Error\r\n"
                "Message=The ringtone directory doesn't exist\r\n");
        return -1;
    }

    if( (dir = opendir(TONELIST_PATH))== NULL )
    {
        buffer_append_string(b, "Response=Error\r\n"
                "Message=Ring tone directory open failed\r\n");
        return -1;
    }

    buffer_append_string(b, "{\"Response\":\"Success\",\"Ringtone\":[");

    while ((dp = readdir( dir )) != NULL)
    {
        if(dp == NULL)
        {
            printf("dp is null\n");
            break;
        }
        if (strcmp(dp->d_name, ".") != 0 && strcmp(dp->d_name, "..") != 0)
        {
            sprintf(name, dp->d_name);
            if( name[0] != '.' )
            {
                len = strlen(name);
                uri_decode(name);
                ptr = strrchr(name, '.');
                if(ptr != NULL)
                {
                    //fileExt = strdup(ptr+1);
                    /*if( strcasecmp(fileExt, "aac") == 0
                        || strcasecmp(fileExt, "mp3") == 0
                        || strcasecmp(fileExt, "wma") == 0
                        || strcasecmp(fileExt, "ogg") == 0
                        || strcasecmp(fileExt, "flac") == 0
                        || strcasecmp(fileExt, "wav") == 0 )*/
                    {
                        if(!j)
                        {
                            buffer_append_string(b, "\"");
                        }
                        else
                        {
                            buffer_append_string(b, ",\"");
                        }
                        buffer_append_string(b, name);
                        buffer_append_string(b, "\"");
                        j++;
                    }
                    //free(fileExt);
                    //fileExt = NULL;
                }
            }
        }
    }
    buffer_append_string(b, "]}");

    closedir(dir);
    return 1;

}

static int handle_deltone(buffer *b, const struct message *m)
{
    int x, len;
    char hdr[64] = "";
    const char *file = NULL;
    char *path = NULL;
    char val[256] = "";
    int done = 0;
    

    for (x = 0; x < 10000; x++) {
        snprintf(hdr, sizeof(hdr), "file-%04d", x);
        file = msg_get_header(m, hdr);
        if (file == NULL)
        {
            break;
        }
        memset(val, 0, sizeof(val));
        strncpy(val, file, sizeof(val) - 1);
        uri_decode(val);

        len = strlen(RINGTONE_PATH) + strlen(val) + 4;
        path = malloc(len);
        snprintf(path, len, "%s/%s", RINGTONE_PATH, val);
        if( access(path, 0) == 0 )
        {
            unlink(path);
            done = 1;
        }
        free(path);
    }

    if (done)
    {
        buffer_append_string(b, "Response=Success\r\n");
    }
    else
    {
        buffer_append_string(b, "Response=Error\r\nMessage=File not exist");
    }

    return 1;
}

void sha1_vector(size_t num_elem, const u8 *addr[], const size_t *len, u8 *mac);

/**
 * hmac_sha1_vector - HMAC-SHA1 over data vector (RFC 2104)
 * @key: Key for HMAC operations
 * @key_len: Length of the key in bytes
 * @num_elem: Number of elements in the data vector
 * @addr: Pointers to the data areas
 * @len: Lengths of the data blocks
 * @mac: Buffer for the hash (20 bytes)
 */
void hmac_sha1_vector(const u8 *key, size_t key_len, size_t num_elem,
		      const u8 *addr[], const size_t *len, u8 *mac)
{
	unsigned char k_pad[64]; /* padding - key XORd with ipad/opad */
	unsigned char tk[20];
	const u8 *_addr[6];
	size_t _len[6], i;

	if (num_elem > 5) {
		/*
		 * Fixed limit on the number of fragments to avoid having to
		 * allocate memory (which could fail).
		 */
		return;
	}

        /* if key is longer than 64 bytes reset it to key = SHA1(key) */
        if (key_len > 64) {
		sha1_vector(1, &key, &key_len, tk);
		key = tk;
		key_len = 20;
        }

	/* the HMAC_SHA1 transform looks like:
	 *
	 * SHA1(K XOR opad, SHA1(K XOR ipad, text))
	 *
	 * where K is an n byte key
	 * ipad is the byte 0x36 repeated 64 times
	 * opad is the byte 0x5c repeated 64 times
	 * and text is the data being protected */

	/* start out by storing key in ipad */
	memset(k_pad, 0, sizeof(k_pad));
	memcpy(k_pad, key, key_len);
	/* XOR key with ipad values */
	for (i = 0; i < 64; i++)
		k_pad[i] ^= 0x36;

	/* perform inner SHA1 */
	_addr[0] = k_pad;
	_len[0] = 64;
	for (i = 0; i < num_elem; i++) {
		_addr[i + 1] = addr[i];
		_len[i + 1] = len[i];
	}
	sha1_vector(1 + num_elem, _addr, _len, mac);

	memset(k_pad, 0, sizeof(k_pad));
	memcpy(k_pad, key, key_len);
	/* XOR key with opad values */
	for (i = 0; i < 64; i++)
		k_pad[i] ^= 0x5c;

	/* perform outer SHA1 */
	_addr[0] = k_pad;
	_len[0] = 64;
	_addr[1] = mac;
	_len[1] = SHA1_MAC_LEN;
	sha1_vector(2, _addr, _len, mac);
}


/**
 * hmac_sha1 - HMAC-SHA1 over data buffer (RFC 2104)
 * @key: Key for HMAC operations
 * @key_len: Length of the key in bytes
 * @data: Pointers to the data area
 * @data_len: Length of the data area
 * @mac: Buffer for the hash (20 bytes)
 */
void hmac_sha1(const u8 *key, size_t key_len, const u8 *data, size_t data_len,
	       u8 *mac)
{
	hmac_sha1_vector(key, key_len, 1, &data, &data_len, mac);
}

static void pbkdf2_sha1_f(const char *passphrase, const char *ssid,
			  size_t ssid_len, int iterations, unsigned int count,
			  u8 *digest)
{
	unsigned char tmp[SHA1_MAC_LEN], tmp2[SHA1_MAC_LEN];
	int i, j;
	unsigned char count_buf[4];
	const u8 *addr[2];
	size_t len[2];
	size_t passphrase_len = strlen(passphrase);

	addr[0] = (u8 *) ssid;
	len[0] = ssid_len;
	addr[1] = count_buf;
	len[1] = 4;

	/* F(P, S, c, i) = U1 xor U2 xor ... Uc
	 * U1 = PRF(P, S || i)
	 * U2 = PRF(P, U1)
	 * Uc = PRF(P, Uc-1)
	 */

	count_buf[0] = (count >> 24) & 0xff;
	count_buf[1] = (count >> 16) & 0xff;
	count_buf[2] = (count >> 8) & 0xff;
	count_buf[3] = count & 0xff;
	hmac_sha1_vector((u8 *) passphrase, passphrase_len, 2, addr, len, tmp);
	memcpy(digest, tmp, SHA1_MAC_LEN);

	for (i = 1; i < iterations; i++) {
		hmac_sha1((u8 *) passphrase, passphrase_len, tmp, SHA1_MAC_LEN,
			  tmp2);
		memcpy(tmp, tmp2, SHA1_MAC_LEN);
		for (j = 0; j < SHA1_MAC_LEN; j++)
			digest[j] ^= tmp2[j];
	}
}


/**
 * pbkdf2_sha1 - SHA1-based key derivation function (PBKDF2) for IEEE 802.11i
 * @passphrase: ASCII passphrase
 * @ssid: SSID
 * @ssid_len: SSID length in bytes
 * @iterations: Number of iterations to run
 * @buf: Buffer for the generated key
 * @buflen: Length of the buffer in bytes
 *
 * This function is used to derive PSK for WPA-PSK. For this protocol,
 * iterations is set to 4096 and buflen to 32. This function is described in
 * IEEE Std 802.11-2004, Clause H.4. The main construction is from PKCS#5 v2.0.
 */
void pbkdf2_sha1(const char *passphrase, const char *ssid, size_t ssid_len,
		 int iterations, u8 *buf, size_t buflen)
{
	unsigned int count = 0;
	unsigned char *pos = buf;
	size_t left = buflen, plen;
	unsigned char digest[SHA1_MAC_LEN];

	while (left > 0) {
		count++;
		pbkdf2_sha1_f(passphrase, ssid, ssid_len, iterations, count,
			      digest);
		plen = left > SHA1_MAC_LEN ? SHA1_MAC_LEN : left;
		memcpy(pos, digest, plen);
		pos += plen;
		left -= plen;
	}
}


#ifdef INTERNAL_SHA1

struct SHA1Context {
	u32 state[5];
	u32 count[2];
	unsigned char buffers[64];
};

typedef struct SHA1Context SHA1_CTX;

static void SHA1Transform(u32 state[5], const unsigned char buffers[64]);


/**
 * sha1_vector - SHA-1 hash for data vector
 * @num_elem: Number of elements in the data vector
 * @addr: Pointers to the data areas
 * @len: Lengths of the data blocks
 * @mac: Buffer for the hash
 */
void sha1_vector(size_t num_elem, const u8 *addr[], const size_t *len,
		 u8 *mac)
{
	SHA1_CTX ctx;
	size_t i;

	SHA1Init(&ctx);
	for (i = 0; i < num_elem; i++)
		SHA1Update(&ctx, addr[i], len[i]);
	SHA1Final(mac, &ctx);
}


/* ===== start - public domain SHA1 implementation ===== */

/*
SHA-1 in C
By Steve Reid <sreid@sea-to-sky.net>
100% Public Domain

-----------------
Modified 7/98 
By James H. Brown <jbrown@burgoyne.com>
Still 100% Public Domain

Corrected a problem which generated improper hash values on 16 bit machines
Routine SHA1Update changed from
	void SHA1Update(SHA1_CTX* context, unsigned char* data, unsigned int
len)
to
	void SHA1Update(SHA1_CTX* context, unsigned char* data, unsigned
long len)

The 'len' parameter was declared an int which works fine on 32 bit machines.
However, on 16 bit machines an int is too small for the shifts being done
against
it.  This caused the hash function to generate incorrect values if len was
greater than 8191 (8K - 1) due to the 'len << 3' on line 3 of SHA1Update().

Since the file IO in main() reads 16K at a time, any file 8K or larger would
be guaranteed to generate the wrong hash (e.g. Test Vector #3, a million
"a"s).

I also changed the declaration of variables i & j in SHA1Update to 
unsigned long from unsigned int for the same reason.

These changes should make no difference to any 32 bit implementations since
an
int and a long are the same size in those environments.

--
I also corrected a few compiler warnings generated by Borland C.
1. Added #include <process.h> for exit() prototype
2. Removed unused variable 'j' in SHA1Final
3. Changed exit(0) to return(0) at end of main.

ALL changes I made can be located by searching for comments containing 'JHB'
-----------------
Modified 8/98
By Steve Reid <sreid@sea-to-sky.net>
Still 100% public domain

1- Removed #include <process.h> and used return() instead of exit()
2- Fixed overwriting of finalcount in SHA1Final() (discovered by Chris Hall)
3- Changed email address from steve@edmweb.com to sreid@sea-to-sky.net

-----------------
Modified 4/01
By Saul Kravitz <Saul.Kravitz@celera.com>
Still 100% PD
Modified to run on Compaq Alpha hardware.  

-----------------
Modified 4/01
By Jouni Malinen <j@w1.fi>
Minor changes to match the coding style used in Dynamics.

Modified September 24, 2004
By Jouni Malinen <j@w1.fi>
Fixed alignment issue in SHA1Transform when SHA1HANDSOFF is defined.

*/

/*
Test Vectors (from FIPS PUB 180-1)
"abc"
  A9993E36 4706816A BA3E2571 7850C26C 9CD0D89D
"abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq"
  84983E44 1C3BD26E BAAE4AA1 F95129E5 E54670F1
A million repetitions of "a"
  34AA973C D4C4DAA4 F61EEB2B DBAD2731 6534016F
*/

#define SHA1HANDSOFF

#define rol(value, bits) (((value) << (bits)) | ((value) >> (32 - (bits))))

/* blk0() and blk() perform the initial expand. */
/* I got the idea of expanding during the round function from SSLeay */
#ifndef WORDS_BIGENDIAN
#define blk0(i) (block->l[i] = (rol(block->l[i], 24) & 0xFF00FF00) | \
	(rol(block->l[i], 8) & 0x00FF00FF))
#else
#define blk0(i) block->l[i]
#endif
#define blk(i) (block->l[i & 15] = rol(block->l[(i + 13) & 15] ^ \
	block->l[(i + 8) & 15] ^ block->l[(i + 2) & 15] ^ block->l[i & 15], 1))

/* (R0+R1), R2, R3, R4 are the different operations used in SHA1 */
#define R0(v,w,x,y,z,i) \
	z += ((w & (x ^ y)) ^ y) + blk0(i) + 0x5A827999 + rol(v, 5); \
	w = rol(w, 30);
#define R1(v,w,x,y,z,i) \
	z += ((w & (x ^ y)) ^ y) + blk(i) + 0x5A827999 + rol(v, 5); \
	w = rol(w, 30);
#define R2(v,w,x,y,z,i) \
	z += (w ^ x ^ y) + blk(i) + 0x6ED9EBA1 + rol(v, 5); w = rol(w, 30);
#define R3(v,w,x,y,z,i) \
	z += (((w | x) & y) | (w & x)) + blk(i) + 0x8F1BBCDC + rol(v, 5); \
	w = rol(w, 30);
#define R4(v,w,x,y,z,i) \
	z += (w ^ x ^ y) + blk(i) + 0xCA62C1D6 + rol(v, 5); \
	w=rol(w, 30);

/* Hash a single 512-bit block. This is the core of the algorithm. */

static void SHA1Transform(u32 state[5], const unsigned char buffers[64])
{
	u32 a, b, c, d, e;
	typedef union {
		unsigned char c[64];
		u32 l[16];
	} CHAR64LONG16;
	CHAR64LONG16* block;
#ifdef SHA1HANDSOFF
	u32 workspace[16];
	block = (CHAR64LONG16 *) workspace;
	memcpy(block, buffers, 64);
#else
	block = (CHAR64LONG16 *) buffers;
#endif
	/* Copy context->state[] to working vars */
	a = state[0];
	b = state[1];
	c = state[2];
	d = state[3];
	e = state[4];
	/* 4 rounds of 20 operations each. Loop unrolled. */
	R0(a,b,c,d,e, 0); R0(e,a,b,c,d, 1); R0(d,e,a,b,c, 2); R0(c,d,e,a,b, 3);
	R0(b,c,d,e,a, 4); R0(a,b,c,d,e, 5); R0(e,a,b,c,d, 6); R0(d,e,a,b,c, 7);
	R0(c,d,e,a,b, 8); R0(b,c,d,e,a, 9); R0(a,b,c,d,e,10); R0(e,a,b,c,d,11);
	R0(d,e,a,b,c,12); R0(c,d,e,a,b,13); R0(b,c,d,e,a,14); R0(a,b,c,d,e,15);
	R1(e,a,b,c,d,16); R1(d,e,a,b,c,17); R1(c,d,e,a,b,18); R1(b,c,d,e,a,19);
	R2(a,b,c,d,e,20); R2(e,a,b,c,d,21); R2(d,e,a,b,c,22); R2(c,d,e,a,b,23);
	R2(b,c,d,e,a,24); R2(a,b,c,d,e,25); R2(e,a,b,c,d,26); R2(d,e,a,b,c,27);
	R2(c,d,e,a,b,28); R2(b,c,d,e,a,29); R2(a,b,c,d,e,30); R2(e,a,b,c,d,31);
	R2(d,e,a,b,c,32); R2(c,d,e,a,b,33); R2(b,c,d,e,a,34); R2(a,b,c,d,e,35);
	R2(e,a,b,c,d,36); R2(d,e,a,b,c,37); R2(c,d,e,a,b,38); R2(b,c,d,e,a,39);
	R3(a,b,c,d,e,40); R3(e,a,b,c,d,41); R3(d,e,a,b,c,42); R3(c,d,e,a,b,43);
	R3(b,c,d,e,a,44); R3(a,b,c,d,e,45); R3(e,a,b,c,d,46); R3(d,e,a,b,c,47);
	R3(c,d,e,a,b,48); R3(b,c,d,e,a,49); R3(a,b,c,d,e,50); R3(e,a,b,c,d,51);
	R3(d,e,a,b,c,52); R3(c,d,e,a,b,53); R3(b,c,d,e,a,54); R3(a,b,c,d,e,55);
	R3(e,a,b,c,d,56); R3(d,e,a,b,c,57); R3(c,d,e,a,b,58); R3(b,c,d,e,a,59);
	R4(a,b,c,d,e,60); R4(e,a,b,c,d,61); R4(d,e,a,b,c,62); R4(c,d,e,a,b,63);
	R4(b,c,d,e,a,64); R4(a,b,c,d,e,65); R4(e,a,b,c,d,66); R4(d,e,a,b,c,67);
	R4(c,d,e,a,b,68); R4(b,c,d,e,a,69); R4(a,b,c,d,e,70); R4(e,a,b,c,d,71);
	R4(d,e,a,b,c,72); R4(c,d,e,a,b,73); R4(b,c,d,e,a,74); R4(a,b,c,d,e,75);
	R4(e,a,b,c,d,76); R4(d,e,a,b,c,77); R4(c,d,e,a,b,78); R4(b,c,d,e,a,79);
	/* Add the working vars back into context.state[] */
	state[0] += a;
	state[1] += b;
	state[2] += c;
	state[3] += d;
	state[4] += e;
	/* Wipe variables */
	a = b = c = d = e = 0;
#ifdef SHA1HANDSOFF
	memset(block, 0, 64);
#endif
}


/* SHA1Init - Initialize new context */

void SHA1Init(SHA1_CTX* context)
{
	/* SHA1 initialization constants */
	context->state[0] = 0x67452301;
	context->state[1] = 0xEFCDAB89;
	context->state[2] = 0x98BADCFE;
	context->state[3] = 0x10325476;
	context->state[4] = 0xC3D2E1F0;
	context->count[0] = context->count[1] = 0;
}


/* Run your data through this. */

void SHA1Update(SHA1_CTX* context, const void *_data, u32 len)
{
	u32 i, j;
	const unsigned char *data = _data;

#ifdef VERBOSE
	SHAPrintContext(context, "before");
#endif
	j = (context->count[0] >> 3) & 63;
	if ((context->count[0] += len << 3) < (len << 3))
		context->count[1]++;
	context->count[1] += (len >> 29);
	if ((j + len) > 63) {
		memcpy(&context->buffers[j], data, (i = 64-j));
		SHA1Transform(context->state, context->buffers);
		for ( ; i + 63 < len; i += 64) {
			SHA1Transform(context->state, &data[i]);
		}
		j = 0;
	}
	else i = 0;
	memcpy(&context->buffers[j], &data[i], len - i);
#ifdef VERBOSE
	SHAPrintContext(context, "after ");
#endif
}


/* Add padding and return the message digest. */

void SHA1Final(unsigned char digest[20], SHA1_CTX* context)
{
	u32 i;
	unsigned char finalcount[8];

	for (i = 0; i < 8; i++) {
		finalcount[i] = (unsigned char)
			((context->count[(i >= 4 ? 0 : 1)] >>
			  ((3-(i & 3)) * 8) ) & 255);  /* Endian independent */
	}
	SHA1Update(context, (unsigned char *) "\200", 1);
	while ((context->count[0] & 504) != 448) {
		SHA1Update(context, (unsigned char *) "\0", 1);
	}
	SHA1Update(context, finalcount, 8);  /* Should cause a SHA1Transform()
					      */
	for (i = 0; i < 20; i++) {
		digest[i] = (unsigned char)
			((context->state[i >> 2] >> ((3 - (i & 3)) * 8)) &
			 255);
	}
	/* Wipe variables */
	i = 0;
	memset(context->buffers, 0, 64);
	memset(context->state, 0, 20);
	memset(context->count, 0, 8);
	memset(finalcount, 0, 8);
}

/* ===== end - public domain SHA1 implementation ===== */

#endif /* INTERNAL_SHA1 */
/*
static int handle_sysconfig_acct(xmlDocPtr doc, xmlNodePtr root_node, buffer *b)
{
    xmlNodePtr cur_node = NULL, child_node = NULL, son2_node = NULL;
    xmlChar *key = NULL;
    char res[256] = "";
    int i = 1;
    
    if (root_node == NULL)
    {
        return -1;
    }

    buffer_append_string(b, "Response=Success\r\n");

    cur_node = root_node->xmlChildrenNode;
    while (cur_node != NULL)
    {
        if (!xmlStrcmp(cur_node->name, BAD_CAST "account"))
        {
            son2_node = cur_node->xmlChildrenNode;
            while (son2_node != NULL)
            {
                if ( (!xmlStrcmp(son2_node->name, BAD_CAST "account1"))
                    || (!xmlStrcmp(son2_node->name, BAD_CAST "account2"))
                    || (!xmlStrcmp(son2_node->name, BAD_CAST "account3")))
                {
                    if( !xmlStrcmp(son2_node->name, BAD_CAST "account1") )
                    {
                        i = 1;
                    }else if( !xmlStrcmp(son2_node->name, BAD_CAST "account2") )
                    {
                        i = 2;
                    }else if( !xmlStrcmp(son2_node->name, BAD_CAST "account3") )
                    {
                        i = 3;
                    }
                    child_node = son2_node->xmlChildrenNode;
                    while (child_node != NULL)
                    {
                        if (!xmlStrcmp(child_node->name, BAD_CAST "isHide"))
                        {
                            key = xmlNodeListGetString(doc, child_node->xmlChildrenNode, 1);
                            if (key == NULL)
                            {
                                snprintf(res, sizeof(res), "hide%d=\r\n", i);
                                buffer_append_string(b, res);
                            }
                            else
                            {
                                snprintf(res, sizeof(res), "hide%d=%s\r\n", i, (char *) key);
                                buffer_append_string(b, res);
                                xmlFree(key);
                            }
                        }else if (!xmlStrcmp(child_node->name, BAD_CAST "isLock"))
                        {
                            key = xmlNodeListGetString(doc, child_node->xmlChildrenNode, 1);
                            if (key == NULL)
                            {
                                snprintf(res, sizeof(res), "lock%d=\r\n", i);
                                buffer_append_string(b, res);
                            }
                            else
                            {
                                snprintf(res, sizeof(res), "lock%d=%s\r\n", i, (char *) key);
                                buffer_append_string(b, res);
                                xmlFree(key);
                            }
                        }
                        child_node = child_node->next;
                    }
                }
                son2_node = son2_node->next;
            }
        }
        cur_node = cur_node->next;
    }
    return 1;
}

static int handle_sysconfig_upgrade(xmlDocPtr doc, xmlNodePtr root_node, buffer *b)
{
    xmlNodePtr cur_node = NULL, child_node = NULL, son2_node = NULL;
    xmlChar *key = NULL;
    char res[128] = "";
    
    if (root_node == NULL)
    {
        return -1;
    }

    buffer_append_string(b, "Response=Success\r\n");

    cur_node = root_node->xmlChildrenNode;
    while (cur_node != NULL)
    {
        if (!xmlStrcmp(cur_node->name, BAD_CAST "maitenance"))
        {
            son2_node = cur_node->xmlChildrenNode;
            while (son2_node != NULL)
            {
                if (!xmlStrcmp(son2_node->name, BAD_CAST "factoryReset"))
                {
                    child_node = son2_node->xmlChildrenNode;
                    while (child_node != NULL)
                    {
                        if (!xmlStrcmp(child_node->name, BAD_CAST "isHide"))
                        {
                            key = xmlNodeListGetString(doc, child_node->xmlChildrenNode, 1);
                            if (key == NULL)
                            {
                                buffer_append_string(b, "hidereset=\r\n");
                            }
                            else
                            {
                                snprintf(res, sizeof(res), "hidereset=%s\r\n", (char *) key);
                                buffer_append_string(b, res);
                                xmlFree(key);
                            }
                        }else if (!xmlStrcmp(child_node->name, BAD_CAST "isLock"))
                        {
                            key = xmlNodeListGetString(doc, child_node->xmlChildrenNode, 1);
                            if (key == NULL)
                            {
                                buffer_append_string(b, "lockreset=\r\n");
                            }
                            else
                            {
                                snprintf(res, sizeof(res), "lockreset=%s\r\n", (char *) key);
                                buffer_append_string(b, res);
                                xmlFree(key);
                            }
                        }
                        child_node = child_node->next;
                    }
                }
                else if (!xmlStrcmp(son2_node->name, BAD_CAST "upgradePara"))
                {
                    child_node = son2_node->xmlChildrenNode;
                    while (child_node != NULL)
                    {
                        if (!xmlStrcmp(child_node->name, BAD_CAST "isHide"))
                        {
                            key = xmlNodeListGetString(doc, child_node->xmlChildrenNode, 1);
                            if (key == NULL)
                            {
                                buffer_append_string(b, "hidefirm=\r\n");
                            }
                            else
                            {
                                snprintf(res, sizeof(res), "hidefirm=%s\r\n", (char *) key);
                                buffer_append_string(b, res);
                                xmlFree(key);
                            }
                        }else if (!xmlStrcmp(child_node->name, BAD_CAST "isLock"))
                        {
                            key = xmlNodeListGetString(doc, child_node->xmlChildrenNode, 1);
                            if (key == NULL)
                            {
                                buffer_append_string(b, "lockfirm=\r\n");
                            }
                            else
                            {
                                snprintf(res, sizeof(res), "lockfirm=%s\r\n", (char *) key);
                                buffer_append_string(b, res);
                                xmlFree(key);
                            }
                        }
                        child_node = child_node->next;
                    }
                }
                son2_node = son2_node->next;
            }
        }
        cur_node = cur_node->next;
    }
    return 1;
}

static int handle_sysconfig(buffer *b, const struct message *m)
{        
    xmlDocPtr doc = NULL;
    xmlNode *cur_node = NULL;
    const char *temp = NULL;

    doc = xmlReadFile(SYS_CONFIG_FILE, NULL, 0);
 
    if (doc == NULL) 
    {
        printf("error: could not parse file %s\n", SYS_CONFIG_FILE);
        buffer_append_string(b, "Response=Error\r\n"
                "Message=Configuration File Not Found\r\n");
        return -1;
    }
    
    cur_node = xmlDocGetRootElement(doc);
    
    cur_node = cur_node->xmlChildrenNode;
    while (cur_node != NULL)
    {
        if (!xmlStrcmp(cur_node->name, BAD_CAST "option"))
        {
            printf("option\n");
            temp = msg_get_header(m, "systype");
            if(temp != NULL)
            {
                if(strcmp(temp,SYS_CONFIG_ACCT) == 0)
                {
                    handle_sysconfig_acct(doc, cur_node, b);
                }
                else if(strcmp(temp,SYS_CONFIG_UPGRADE) == 0)
                {
                    handle_sysconfig_upgrade(doc, cur_node, b);
                }
            }
        }
        cur_node = cur_node->next;
    }

    xmlFreeDoc(doc);
    return 1;

}
*/

static int handle_getPhoneStatus(buffer *b, const struct message *m)
{
    char *funcname = NULL;
    char *cmdstr = NULL;
    char *statusresult = NULL;

    funcname = msg_get_header(m, "funcname");
    if( funcname != NULL )
    {
        system("chmod +x /bin/pidof");
        cmdstr = malloc(strlen(funcname)+32);
        sprintf(cmdstr, "pidof %s > /tmp/gmitmp &", funcname);
        printf("cmdstr is %s\n", cmdstr);
        int result = system(cmdstr);
        sleep(1);
        if(result == 0)
        {
            FILE *pid_file;
            pid_file = fopen ("/tmp/gmitmp", "r");

            if (pid_file != NULL) {
                char buf[32] = "";
                fread (buf, 32, 1, pid_file);
                fclose (pid_file);
                int pid = atoi(buf);
                if( pid != 0 )
                {
                    printf("pid is %s\n", buf);
                    sprintf(cmdstr, "cat /proc/%d/stat > /tmp/gmitmp2&", pid);
                    printf("cmdstr is %s\n", cmdstr);
                    int result2 = system(cmdstr);
                    sleep(1);
                    if( result2 == 0 )
                    {
                        FILE *stat_file;
                        stat_file = fopen ("/tmp/gmitmp2", "r");
                        if (stat_file != NULL)
                        {
                            char buf2[128] = "";
                            fread (buf2, 128, 1, stat_file);
                            fclose (stat_file);
                            printf("status buf is %s\n", buf2);
                            char *p = buf2;
                            strsep(&p, " ");
                            printf("%s\n", p);
                            strsep(&p, " ");
                            printf("%s\n", p);
                            statusresult = strsep(&p, " ");
                            printf("statusresult is %s\n", statusresult);
                            printf("%s\n", p);
                        } 
                    }
                    remove("/tmp/gmitmp2");
                 }
            }
        }
        free(cmdstr);
        remove("/tmp/gmitmp");
    }

    funcname = msg_get_header(m, "format");
    const char * jsonCallback = NULL;
    if((funcname != NULL) && !strcasecmp(funcname, "json"))
    {
        jsonCallback = msg_get_header( m, "jsoncallback" );
    }

    if(jsonCallback != NULL)
    {
        cmdstr = malloc((strlen(jsonCallback) + 32) * sizeof(char));

        if( cmdstr != NULL && statusresult != NULL )
        {
            sprintf(cmdstr, "%s(%s)", jsonCallback, statusresult);
        }else
        {
            sprintf(cmdstr, "%s(%s)", jsonCallback, "Unknown");
        }
        buffer_append_string (b, cmdstr);
        free(cmdstr);
    }
    else
    {
        if( statusresult != NULL )
        {
            buffer_append_string(b, statusresult);
        }
        else
        {
            buffer_append_string(b, "Unknown");
        }
    }
    return 0;
}


static int handle_getGmiVersion(server *srv, connection *con,buffer *b, const struct message *m)
{
char *gversion = NULL;


#ifndef BUILD_ARM
    gversion = nvram_get("gmi_version");
#else
    gversion = "Unknown";
#endif
    const char *resType = NULL;
    char * temp = NULL;
      char res[128] = "";
    resType = msg_get_header(m, "format");
    if (resType != NULL && !strcasecmp(resType, "json")) {
        snprintf( res, sizeof(res)-1,"%s: \"%s\"}", "{\"res\" : \"success\", \"msg\" ", gversion );
        temp = build_JSON_formate( srv, con, m, res );
        buffer_append_string(b,temp);
    }else{
        buffer_append_string(b, gversion);
    }

    return 1;
}

#endif

#ifndef BUILD_RECOVER
char *generate_file_name(buffer *b, const struct message *m)
{
    const char *type = NULL;
    char *file_name = NULL;
    char *temp = NULL;

    type = msg_get_header(m, "type");
    if (type == NULL)
    {
        buffer_append_string(b, "Response=Error\r\nMessage=Missing Type\r\n");
    }
    else
    {
        if( access(DATA_DIR, 0) ) {
            mkdir(DATA_DIR, 0755);
        }
        if( access(VPN_PATH, 0) )
        {
            mkdir(VPN_PATH, 0755);
        }
        if( access(DIR_802MODE, 0) )
        {
            mkdir(DIR_802MODE, 0755);
        }
        if( access(PATH_802MODE, 0) )
        {
            mkdir(PATH_802MODE, 0755);
        }
        if (!strcasecmp(type, "ca"))
        {
            file_name = strdup(VPN_PATH"/ca.crt");
        }
        else if (!strcasecmp(type, "cert")) 
        {
            file_name = strdup(VPN_PATH"/gxv3140.crt");
        }
        if (!strcasecmp(type, "802ca"))
        {
            file_name = strdup(PATH_802MODE"/ca.pem");
        }
        else if (!strcasecmp(type, "802client"))
        {
            file_name = strdup(PATH_802MODE"/client.pem");
        }
        else if (!strcasecmp(type, "key"))
        {
            file_name = strdup(VPN_PATH"/gxv3140.key");
        }
        else if (!strcasecmp(type, "g3conf"))
        {
            if( access(DATA_PPP, 0) )
            {
                mkdir(DATA_PPP, 0755);
            }
            file_name = strdup(DATA_PPP"/3g");
        }
        else if (!strcasecmp(type, "g3script"))
        {
            if( access(DATA_PPP, 0) )
            {
                mkdir(DATA_PPP, 0755);
            }
            file_name = strdup(DATA_PPP"/chat-3g");
        }
        else if (!strcasecmp(type, "phonebook")) //modified by jlxu, upload phonebook savepath
        {
            if ( access(TMP_PHONEBOOKPATH, 0) )
            {
                mkdir(TMP_PHONEBOOKPATH, 0777);
            }
            file_name = strdup(TMP_PHONEBOOKPATH"/phonebook.xml");
            //file_name = strdup(TEMP_PATH"/phonebook_import");
        }
        else if (!strcasecmp(type, "upgradefile"))
        {
            file_name = strdup(FIFO_PATH);
        }
        else if (!strcasecmp(type, "ringtone"))
        {
            temp = (char *)msg_get_header(m, "name");
            if (temp == NULL)
            {
                /*snprintf(res, sizeof(res), "Response=Error\r\nMessage=Name Required\r\n");
                buffer_append_string(b, res);
                free(res);*/
                file_name = strdup(TEMP_PATH"/ringtone.mp3");
            }
            else
            {
                char *val = malloc(strlen(temp) + 32);
                memset(val, 0, strlen(temp) + 32);
                strncpy(val, temp, strlen(temp));
                uri_decode(val);
                file_name = malloc(strlen(val)+32);
                sprintf(file_name, RINGTONE_PATH"/%s", val);
                free(val);
            }
        }
        else if (!strcasecmp(type, "audiofile")) //move from 2200
        {
            char *cmd;
            char *acct = msg_get_header(m, "acct");

            /* filepath: /user_data/moh/account.../  */
            char *filepath = malloc(64);
            sprintf(filepath, TMP_AUDIOFILEPATH"%s", acct);

            //if (access(TMP_AUDIOFILEPATH, 0))
            if (access(filepath, 0))
            {
                cmd = malloc(strlen(filepath) + 32);
                memset(cmd, 0, sizeof(cmd));
                sprintf(cmd, "mkdir -p %s", filepath);
                system(cmd);

                memset(cmd, 0, sizeof(cmd));
                sprintf(cmd, "chmod 777 %s", filepath);
                system(cmd);
                free(cmd);
                //mkdir(TMP_AUDIOFILEPATH, 0777);
            }

            /* the entire filename is /user_data/moh/account.../audiofile */
            file_name = malloc(64);
            sprintf(file_name, "%s/audiofile", filepath);
            //sprintf(file_name, TMP_AUDIOFILEPATH"/audiofile.%s", ext);
            free(filepath);
        }
        else
        {
            buffer_append_string(b, "Response=Error\r\nMessage=Unknow Type\r\n");
        }
    }

    return file_name;
}
#else
char *generate_file_name_recover(buffer *b, const struct message *m)
{
    const char *type = NULL;
    char* file_name = NULL;
    char res[128] ="";

    type = msg_get_header(m, "type");
    if (type == NULL)
    {
        snprintf(res, sizeof(res), "Response=Error\r\nMessage=Missing Type\r\n");
        buffer_append_string(b, res);
    }
    else
    {
        file_name = malloc(32);
        if (!strcasecmp(type, "recoverall"))
        {
            snprintf(file_name, 32, "/tmp/recoverall");
        }
        else if (!strcasecmp(type, "recoverboot"))
        {
            snprintf(file_name, 32, "/tmp/recoverboot");
        }
        else if (!strcasecmp(type, "recovercore"))
        {
            snprintf(file_name, 32, TEMP_PATH"/recovercore");
        }
        else if (!strcasecmp(type, "recoverbase"))
        {
            snprintf(file_name, 32, TEMP_PATH"/recoverbase");
        }
        else if (!strcasecmp(type, "recoverprogram"))
        {
            snprintf(file_name, 32, TEMP_PATH"/recoverprogram");
        }
        else if (!strcasecmp(type, "recoverguia"))
        {
            snprintf(file_name, 32, TEMP_PATH"/recoverguia");
        }
        else if (!strcasecmp(type, "recoverguib"))
        {
            snprintf(file_name, 32, TEMP_PATH"/recoverguib");
        }
        else if (!strcasecmp(type, "recoversupp"))
        {
            snprintf(file_name, 32, TEMP_PATH"/recoversupp");
        }
        else
        {
            snprintf(res, sizeof(res), "Response=Error\r\nMessage=Unknow Type\r\n");
            buffer_append_string(b, res);
        }
    }

    printf("genetate file name is %s>>>>>>>>>>>>>>>>>>>>>",file_name);
    return file_name;
}

static int handle_startrecover(buffer *b, const struct message *m)
{
        char res[80] = "";
        int result = 1;
        const char *type = NULL;
        const char *typenum = NULL;
        type = msg_get_header(m, "recovername");
        typenum = msg_get_header(m, "recovernum");
        if(type == NULL || typenum == NULL)
            return 0;
        printf("type typenum is %s-----%s------\r\n", type, typenum);
        snprintf(res, sizeof(res), "load_firmware %s %s", type, typenum);
        result = system(res);
        //printf("exec result is %d-----------\r\n",result);
        if(result != 0)
            snprintf(res, sizeof(res), "Response=Error\r\n");
        else
            snprintf(res, sizeof(res), "Response=Success\r\n");
	buffer_append_string(b, res);
	return 0;
}

static int handle_recoverresult(buffer *b)
{
    char res[80] = "";  
    char buf[80] = "";
    FILE *log_file;
    
    log_file = fopen ("/tmp/log", "r");
    
    if (log_file != NULL) {
        fread (buf, 127, 1, log_file);
        fclose (log_file);

        buffer_append_string (b, "Response=Success\r\n");
        snprintf(res, sizeof(res), "Message=%s\r\n", buf);
        buffer_append_string (b, res);
        printf("res lenght is %d", strlen(res));
        return 1;
    } else {
        buffer_append_string (b, "Response=Error\r\n");
        return -1;
    }
}

static int handle_recoverreset (buffer *b)
{
    int result = 1;

    result = system("swap_erase");
    if(result != 0)
        buffer_append_string(b, "Response=Error\r\n");
    else
        buffer_append_string(b, "Response=Success\r\n");

    return 0;
}

static int handle_recoverversion(buffer *b)
{
    char res[80] = "";
    const char *val = NULL;

#ifdef BUILD_ON_ARM
    val = nvram_my_get("89");
#else
    val = " ";
#endif

    buffer_append_string (b, "Response=Success\r\n");
    snprintf(res, sizeof(res), "version=%s\r\n", val);
    buffer_append_string (b, res);
    return -1;
}
#endif

#ifndef BUILD_RECOVER
static int handle_getgroup(server *srv, connection *con,
    buffer *b, const struct message *m)
{
    DBusMessage* message = NULL;
    DBusError error;
    DBusMessageIter iter;
    DBusBusType type;
    int reply_timeout = 5000;
    DBusMessage *reply = NULL;
    DBusConnection *conn = NULL;
    const char *gpID = NULL;
    char *temp = NULL;
    char *info = NULL;
    xmlDocPtr doc = NULL;
    xmlNode *root_element = NULL;
    xmlNode *cur_node = NULL;
    xmlNodePtr son_node = NULL;
    xmlChar *key = NULL;

    type = DBUS_BUS_SYSTEM;
    dbus_error_init (&error);
    conn = dbus_bus_get (type, &error);

    if( access( TMP_PHONEBOOKPATH, 0 ) )
    {
        mkdir(TMP_PHONEBOOKPATH, 0777);
    }

    if (conn == NULL)
    {
        printf ( "Failed to open connection to %s message bus: %s\n", (type == DBUS_BUS_SYSTEM) ? "system" : "session", error.message);
        dbus_error_free (&error);
        return -1;
    }
                                          
    message = dbus_message_new_method_call( dbus_dest, dbus_path, dbus_interface, "getGroup" );

    printf("handle_getgroup\n");
    if (message != NULL)
    {
        dbus_message_set_auto_start (message, TRUE);
        dbus_message_iter_init_append( message, &iter );

        gpID = msg_get_header(m, "groupID");

        if ( gpID == NULL )
        {
            gpID = "";
        }
      
        if ( !dbus_message_iter_append_basic( &iter, DBUS_TYPE_STRING, &gpID ) )
        {
            printf( "Out of Memory!\n" );
            exit( 1 );
        }
            
        dbus_error_init( &error );
        reply = dbus_connection_send_with_reply_and_block( conn, message, reply_timeout, &error );

        if ( dbus_error_is_set( &error ) )
        {
            fprintf(stderr, "Error %s: %s\n",
                error.name,
                error.message);
        }

        if ( reply )
        {
            print_message( reply );
            int current_type;
            char *res = NULL;
            dbus_message_iter_init( reply, &iter );

            while ( ( current_type = dbus_message_iter_get_arg_type( &iter ) ) != DBUS_TYPE_INVALID )
            {
                switch ( current_type )
                {
                    case DBUS_TYPE_STRING:
                        dbus_message_iter_get_basic(&iter, &res);
                        break;
                            
                    default:
                        break;
                }

                dbus_message_iter_next (&iter);
            }

            if ( res != NULL )
            {
                if (strcmp("/sdcard/phonebook/groups.xml", res) == 0) {
                    doc = xmlReadFile(res, NULL, 0);

                    if (doc == NULL)
                    {
                        temp = "{\"res\": \"error\", \"msg\": \"can't get groups information\"}";
                        temp = build_JSON_formate( srv, con, m, temp );
                        if ( temp != NULL )
                        {
                            buffer_append_string( b, temp );
                            free(temp);
                        }

                        dbus_message_unref( reply );
                        dbus_message_unref( message );
                        return -1;
                    }

                    /*Get the root element node */
                    root_element = xmlDocGetRootElement(doc);

                    for (cur_node = root_element->xmlChildrenNode; cur_node; cur_node = cur_node->next)
                    {
                        if (cur_node->type == XML_ELEMENT_NODE)
                        {
                            son_node = cur_node;

                            while (son_node != NULL)
                            {
                                if ((!xmlStrcmp(son_node->name, (const xmlChar *)"body")))
                                {
                                    key = xmlNodeListGetString(doc, son_node->xmlChildrenNode, 1);
                                    if (key != NULL)
                                    {
                                        info = (char*)malloc(1 + strlen(key));
                                        sprintf(info, "%s", key);
                                        temp = info;
                                        xmlFree(key);
                                        break;
                                    } 
                                    else 
                                    {
                                        temp = "{\"res\": \"error\", \"msg\": \"can't get groups information\"}";
                                    }
                                }
                            }
                        }
                    }

                    xmlFreeDoc(doc);
                }
                else 
                {
                    info = (char*)malloc((1 + strlen(res)) * sizeof(char));
                    sprintf(info, "%s", res);
                    temp = info;
                }
            }
            else
            {
                temp = "{\"res\": \"error\", \"msg\": \"can't get groups information\"}";
            }

            temp = build_JSON_formate( srv, con, m, temp );

            if(info != NULL)
            {
                free(info);
            }

            if ( temp != NULL )
            {
                buffer_append_string( b, temp );
                free(temp);
            }
            dbus_message_unref( reply );
        }

        dbus_message_unref( message );
    }

    return 0;
}
static int handle_getcontact(server *srv, connection *con, 
    buffer *b, const struct message *m)
{
    DBusMessage* message = NULL;
    DBusError error;
    DBusMessageIter iter;
    DBusBusType type;
    int reply_timeout = 10000;
    DBusMessage *reply = NULL;
    DBusConnection *conn = NULL;
    const char *ctID = NULL;
    const char *gpID = NULL;
    const char *ctName = NULL;
    char *temp = NULL;
    char *info = NULL;
    xmlDocPtr doc = NULL;
    xmlNode *root_element = NULL;
    xmlNode *cur_node = NULL;
    xmlNodePtr son_node = NULL;
    xmlChar *key = NULL;

    type = DBUS_BUS_SYSTEM;
    dbus_error_init (&error);
    conn = dbus_bus_get (type, &error);

    if( access( TMP_PHONEBOOKPATH, 0 ) )
    {
        mkdir(TMP_PHONEBOOKPATH, 0777);
    }

    if (conn == NULL)
    {
        printf ( "Failed to open connection to %s message bus: %s\n", (type == DBUS_BUS_SYSTEM) ? "system" : "session", error.message);
        dbus_error_free (&error);
        return -1;
    }
                                          
    message = dbus_message_new_method_call( dbus_dest, dbus_path, dbus_interface, "getContact" );

    printf("handle_getcontact\n");
    if (message != NULL)
    {
        dbus_message_set_auto_start (message, TRUE);
        dbus_message_iter_init_append( message, &iter );

        ctID = msg_get_header(m, "contactID");

        if ( ctID == NULL )
        {
            ctID = "";
        }

        gpID = msg_get_header(m, "groupID");

        if ( gpID == NULL )
        {
            gpID = "";
        }

        ctName = msg_get_header(m, "contactName");

        if ( ctName == NULL )
        {
            ctName = "";
        }
      
        if ( !dbus_message_iter_append_basic( &iter, DBUS_TYPE_STRING, &ctID ) )
        {
            printf( "Out of Memory!\n" );
            exit( 1 );
        }

        if ( !dbus_message_iter_append_basic( &iter, DBUS_TYPE_STRING, &gpID ) )
        {
            printf( "Out of Memory!\n" );
            exit( 1 );
        }

        if ( !dbus_message_iter_append_basic( &iter, DBUS_TYPE_STRING, &ctName ) )
        {
            printf( "Out of Memory!\n" );
            exit( 1 );
        }
            
        dbus_error_init( &error );
        reply = dbus_connection_send_with_reply_and_block( conn, message, reply_timeout, &error );

        if ( dbus_error_is_set( &error ) )
        {
            fprintf(stderr, "Error %s: %s\n",
                error.name,
                error.message);
        }

        if ( reply )
        {
            print_message( reply );
            int current_type;
            char *res = NULL;
            dbus_message_iter_init( reply, &iter );

            while ( ( current_type = dbus_message_iter_get_arg_type( &iter ) ) != DBUS_TYPE_INVALID )
            {
                switch ( current_type )
                {
                    case DBUS_TYPE_STRING:
                        dbus_message_iter_get_basic(&iter, &res);
                        break;
                
                    default:
                        break;
                }

                dbus_message_iter_next (&iter);
            }

            if ( res != NULL )
            {
                if (strcmp("/sdcard/phonebook/contacts.xml", res) == 0) {
                    doc = xmlReadFile(res, NULL, 0);

                    if (doc == NULL)
                    {
                        temp = "{\"res\": \"error\", \"msg\": \"can't get contacts information\"}";
                        temp = build_JSON_formate( srv, con, m, temp );
                        if ( temp != NULL )
                        {
                            buffer_append_string( b, temp );
                            free(temp);
                        }

                        dbus_message_unref( reply );
                        dbus_message_unref( message );
                        return -1;
                    }

                    /*Get the root element node */
                    root_element = xmlDocGetRootElement(doc);

                    for (cur_node = root_element->xmlChildrenNode; cur_node; cur_node = cur_node->next)
                    {
                        if (cur_node->type == XML_ELEMENT_NODE)
                        {
                            son_node = cur_node;

                            while (son_node != NULL)
                            {
                                if ((!xmlStrcmp(son_node->name, (const xmlChar *)"body")))
                                {
                                    key = xmlNodeListGetString(doc, son_node->xmlChildrenNode, 1);
                                    if (key != NULL)
                                    {
                                        info = (char*)malloc(1 + strlen(key));
                                        sprintf(info, "%s", key);
                                        temp = info;
                                        xmlFree(key);
                                        break;
                                    } 
                                    else 
                                    {
                                        temp = "{\"res\": \"error\", \"msg\": \"can't get contacts information\"}";
                                    }
                                }
                            }
                        }
                    }

                    xmlFreeDoc(doc);
                }
                else 
                {
                    info = (char*)malloc((1+ strlen(res)) * sizeof(char));
                    sprintf(info, "%s", res);
                    temp = info;
                }
            }
            else
            {
                temp = "{\"res\": \"error\", \"msg\": \"can't get contacts information\"}";
            }

            temp = build_JSON_formate( srv, con, m, temp );

            if(info != NULL)
            {
                free(info);
            }

            if ( temp != NULL )
            {
                buffer_append_string( b, temp );
                free(temp);
            }
            dbus_message_unref( reply );
        }

        dbus_message_unref( message );
    }

    return 0;
}

static int handle_getgroupcount(server *srv, connection *con, 
    buffer *b, const struct message *m)
{
    DBusMessage* message = NULL;
    DBusError error;
    DBusMessageIter iter;
    DBusBusType type;
    int reply_timeout = 3000;
    DBusMessage *reply = NULL;
    DBusConnection *conn = NULL;
    char *temp = NULL;
    char *info = NULL;

    type = DBUS_BUS_SYSTEM;
    dbus_error_init (&error);
    conn = dbus_bus_get (type, &error);

    if (conn == NULL)
    {
        printf ( "Failed to open connection to %s message bus: %s\n", (type == DBUS_BUS_SYSTEM) ? "system" : "session", error.message);
        dbus_error_free (&error);
        return -1;
    }
                                          
    message = dbus_message_new_method_call( dbus_dest, dbus_path, dbus_interface, "getGroupCount" );

    printf("handle_getgroupcount\n");
    if (message != NULL)
    {
        dbus_message_set_auto_start (message, TRUE);
            
        dbus_error_init( &error );
        reply = dbus_connection_send_with_reply_and_block( conn, message, reply_timeout, &error );

        if ( dbus_error_is_set( &error ) )
        {
            fprintf(stderr, "Error %s: %s\n",
                error.name,
                error.message);
        }

        if ( reply )
        {
            print_message( reply );
            int current_type;
            char *res = NULL;
            dbus_message_iter_init( reply, &iter );

            while ( ( current_type = dbus_message_iter_get_arg_type( &iter ) ) != DBUS_TYPE_INVALID )
            {
                switch ( current_type )
                {
                    case DBUS_TYPE_STRING:
                        dbus_message_iter_get_basic(&iter, &res);
                        break;
                            
                    default:
                        break;
                }

                dbus_message_iter_next (&iter);
            }

            if ( res != NULL )
            {
                info = (char*)malloc((1 + strlen(res)) * sizeof(char));
                sprintf(info, "%s", res);
                temp = info;
            }
            else
            {
                temp = "{\"res\": \"error\", \"msg\": \"can't get group count\"}";
            }

            temp = build_JSON_res( srv, con, m, temp );

            if(info != NULL)
            {
                free(info);
            }

            if ( temp != NULL )
            {
                buffer_append_string( b, temp );
                free(temp);
            }
            dbus_message_unref( reply );
        }

        dbus_message_unref( message );
    }

    return 0;
}

static int handle_getcontactcount(server *srv, connection *con, 
    buffer *b, const struct message *m)
{
    DBusMessage* message = NULL;
    DBusError error;
    DBusMessageIter iter;
    DBusBusType type;
    int reply_timeout = 3000;
    DBusMessage *reply = NULL;
    DBusConnection *conn = NULL;
    char *temp = NULL;
    char *info = NULL;

    type = DBUS_BUS_SYSTEM;
    dbus_error_init (&error);
    conn = dbus_bus_get (type, &error);

    if (conn == NULL)
    {
        printf ( "Failed to open connection to %s message bus: %s\n", (type == DBUS_BUS_SYSTEM) ? "system" : "session", error.message);
        dbus_error_free (&error);
        return -1;
    }
                                          
    message = dbus_message_new_method_call( dbus_dest, dbus_path, dbus_interface, "getContactCount" );

    printf("handle_getcontactcount\n");
    if (message != NULL)
    {
        dbus_message_set_auto_start (message, TRUE);
            
        dbus_error_init( &error );
        reply = dbus_connection_send_with_reply_and_block( conn, message, reply_timeout, &error );

        if ( dbus_error_is_set( &error ) )
        {
            fprintf(stderr, "Error %s: %s\n",
                error.name,
                error.message);
        }

        if ( reply )
        {
            print_message( reply );
            int current_type;
            char *res = NULL;
            dbus_message_iter_init( reply, &iter );

            while ( ( current_type = dbus_message_iter_get_arg_type( &iter ) ) != DBUS_TYPE_INVALID )
            {
                switch ( current_type )
                {
                    case DBUS_TYPE_STRING:
                        dbus_message_iter_get_basic(&iter, &res);
                        break;
                            
                    default:
                        break;
                }

                dbus_message_iter_next (&iter);
            }

            if ( res != NULL )
            {
                info = (char*)malloc((1 + strlen(res)) * sizeof(char));
                sprintf(info, "%s", res);
                temp = info;
            }
            else
            {
                temp = "{\"res\": \"error\", \"msg\": \"can't get contact count\"}";
            }

            temp = build_JSON_res( srv, con, m, temp );

            if(info != NULL)
            {
                free(info);
            }

            if ( temp != NULL )
            {
                buffer_append_string( b, temp );
                free(temp);
            }

            dbus_message_unref( reply );
        }

        dbus_message_unref( message );
    }

    return 0;
}

void urldecode(char *p)
{
    register int i=0;

    while(*(p+i))
    {
        if ((*p=*(p+i)) == '%')
        {
            *p=*(p+i+1) >= 'A' ? ((*(p+i+1) & 0XDF) - 'A') + 10 : (*(p+i+1) - '0');
            *p=(*p) * 16;
            *p+=*(p+i+2) >= 'A' ? ((*(p+i+2) & 0XDF) - 'A') + 10 : (*(p+i+2) - '0');
            i+=2;
        }
        else if (*(p+i)=='+')
        {
            *p=' ';
        }

        p++;
    }

    *p='\0';
}

static int handle_setgroup(server *srv, connection *con, 
    buffer *b, const struct message *m)
{
    DBusMessage* message = NULL;
    DBusError error;
    DBusMessageIter iter;
    DBusBusType type;
    int reply_timeout = 5000;
    DBusMessage *reply = NULL;
    DBusConnection *conn = NULL;
    const char *gpInfo = NULL;
    char *temp = NULL;
    char *info = NULL;

    type = DBUS_BUS_SYSTEM;
    dbus_error_init (&error);
    conn = dbus_bus_get (type, &error);

    if (conn == NULL)
    {
        printf ( "Failed to open connection to %s message bus: %s\n", (type == DBUS_BUS_SYSTEM) ? "system" : "session", error.message);
        dbus_error_free (&error);
        return -1;
    }
                                          
    message = dbus_message_new_method_call( dbus_dest, dbus_path, dbus_interface, "setGroup" );

    printf("handle_setgroup\n");
    if (message != NULL)
    {
        dbus_message_set_auto_start (message, TRUE);
        dbus_message_iter_init_append( message, &iter );

        gpInfo = msg_get_header(m, "groupInfo");

        if ( gpInfo == NULL )
        {
            gpInfo = "";
        }
        else
        {
            uri_decode( (char*)gpInfo );
        }
    
        if ( !dbus_message_iter_append_basic( &iter, DBUS_TYPE_STRING, &gpInfo ) )
        {
            printf( "Out of Memory!\n" );
            exit( 1 );
        }
       
        dbus_error_init( &error );
        reply = dbus_connection_send_with_reply_and_block( conn, message, reply_timeout, &error );

        if ( dbus_error_is_set( &error ) )
        {
            fprintf(stderr, "Error %s: %s\n",
                error.name,
                error.message);
        }

        if ( reply )
        {
            print_message( reply );
            int current_type;
            char *res = NULL;
            dbus_message_iter_init( reply, &iter );

            while ( ( current_type = dbus_message_iter_get_arg_type( &iter ) ) != DBUS_TYPE_INVALID )
            {
                switch ( current_type )
                {
                    case DBUS_TYPE_STRING:
                        dbus_message_iter_get_basic(&iter, &res);
                        break;
                            
                    default:
                        break;
                }

                dbus_message_iter_next (&iter);
            }

            if ( res != NULL )
            {
                info = (char*)malloc((1 + strlen(res)) * sizeof(char));
                sprintf(info, "%s", res);
                temp = info;
            }
            else
            {
                temp = "{\"res\": \"error\", \"msg\": \"can't set group\"}";
            }

            temp = build_JSON_res( srv, con, m, temp );

            if(info != NULL)
            {
                free(info);
            }

            if ( temp != NULL )
            {
                buffer_append_string( b, temp );
                free(temp);
            }
            dbus_message_unref( reply );
        }

        dbus_message_unref( message );
    }

    return 0;
}

static int handle_setcontact(server *srv, connection *con, 
    buffer *b, const struct message *m)
{
    DBusMessage* message = NULL;
    DBusError error;
    DBusMessageIter iter;
    DBusBusType type;
    int reply_timeout = 5000;
    DBusMessage *reply = NULL;
    DBusConnection *conn = NULL;
    const char *ctInfo = NULL;
    char *temp = NULL;
    char *info = NULL;

    type = DBUS_BUS_SYSTEM;
    dbus_error_init (&error);
    conn = dbus_bus_get (type, &error);

    if (conn == NULL)
    {
        printf ( "Failed to open connection to %s message bus: %s\n", (type == DBUS_BUS_SYSTEM) ? "system" : "session", error.message);
        dbus_error_free (&error);
        return -1;
    }
                                          
    message = dbus_message_new_method_call( dbus_dest, dbus_path, dbus_interface, "setContact" );

    printf("handle_setcontact\n");
    if (message != NULL)
    {
        dbus_message_set_auto_start (message, TRUE);
        dbus_message_iter_init_append( message, &iter );

        ctInfo = msg_get_header(m, "contactInfo");

        if ( ctInfo == NULL )
        {
            ctInfo = "";
        }
        else
        {
            uri_decode( (char*)ctInfo );
        }
      
        if ( !dbus_message_iter_append_basic( &iter, DBUS_TYPE_STRING, &ctInfo ) )
        {
            printf( "Out of Memory!\n" );
            exit( 1 );
        }
            
        dbus_error_init( &error );
        reply = dbus_connection_send_with_reply_and_block( conn, message, reply_timeout, &error );

        if ( dbus_error_is_set( &error ) )
        {
            fprintf(stderr, "Error %s: %s\n",
                error.name,
                error.message);
        }

        if ( reply )
        {
            print_message( reply );
            int current_type;
            char *res = NULL;
            dbus_message_iter_init( reply, &iter );

            while ( ( current_type = dbus_message_iter_get_arg_type( &iter ) ) != DBUS_TYPE_INVALID )
            {
                switch ( current_type )
                {
                    case DBUS_TYPE_STRING:
                        dbus_message_iter_get_basic(&iter, &res);
                        break;
                            
                    default:
                        break;
                }

                dbus_message_iter_next (&iter);
            }

            if ( res != NULL )
            {
                info = (char*)malloc((1 + strlen(res)) * sizeof(char));
                sprintf(info, "%s", res);
                temp = info;
            }
            else
            {
                temp = "{\"res\": \"error\", \"msg\": \"can't set contact\"}";
            }

            temp = build_JSON_res( srv, con, m, temp );

            if(info != NULL)
            {
                free(info);
            }

            if ( temp != NULL )
            {
                buffer_append_string( b, temp );
                free(temp);
            }
            dbus_message_unref( reply );
        }

        dbus_message_unref( message );
    }

    return 0;
}

static int handle_removecontact(server *srv, connection *con, 
    buffer *b, const struct message *m)
{
    DBusMessage* message = NULL;
    DBusError error;
    DBusMessageIter iter;
    DBusBusType type;
    int reply_timeout = 5000;
    DBusMessage *reply = NULL;
    DBusConnection *conn = NULL;
    const char *ctID = NULL;
    char *temp = NULL;
    char *info = NULL;

    type = DBUS_BUS_SYSTEM;
    dbus_error_init (&error);
    conn = dbus_bus_get (type, &error);

    if (conn == NULL)
    {
        printf ( "Failed to open connection to %s message bus: %s\n", (type == DBUS_BUS_SYSTEM) ? "system" : "session", error.message);
        dbus_error_free (&error);
        return -1;
    }
                                          
    message = dbus_message_new_method_call( dbus_dest, dbus_path, dbus_interface, "removeContact" );

    printf("handle_removecontact\n");
    if (message != NULL)
    {
        dbus_message_set_auto_start (message, TRUE);
        dbus_message_iter_init_append( message, &iter );

        ctID = msg_get_header(m, "contactID");

        if ( ctID == NULL )
        {
            ctID = "";
        }
      
        if ( !dbus_message_iter_append_basic( &iter, DBUS_TYPE_STRING, &ctID ) )
        {
            printf( "Out of Memory!\n" );
            exit( 1 );
        }
            
        dbus_error_init( &error );
        reply = dbus_connection_send_with_reply_and_block( conn, message, reply_timeout, &error );

        if ( dbus_error_is_set( &error ) )
        {
            fprintf(stderr, "Error %s: %s\n",
                error.name,
                error.message);
        }

        if ( reply )
        {
            print_message( reply );
            int current_type;
            char *res = NULL;
            dbus_message_iter_init( reply, &iter );

            while ( ( current_type = dbus_message_iter_get_arg_type( &iter ) ) != DBUS_TYPE_INVALID )
            {
                switch ( current_type )
                {
                    case DBUS_TYPE_STRING:
                        dbus_message_iter_get_basic(&iter, &res);
                        break;
                            
                    default:
                        break;
                }

                dbus_message_iter_next (&iter);
            }

            if ( res != NULL )
            {
                info = (char*)malloc((1 + strlen(res)) * sizeof(char));
                sprintf(info, "%s", res);
                temp = info;
            }
            else
            {
                temp = "{\"res\": \"error\", \"msg\": \"can't remove contact\"}";
            }

            temp = build_JSON_res( srv, con, m, temp );

            if(info != NULL)
            {
                free(info);
            }

            if ( temp != NULL )
            {
                buffer_append_string( b, temp );
                free(temp);
            }
            dbus_message_unref( reply );
        }

        dbus_message_unref( message );
    }

    return 0;
}

static int handle_cleargroup(server *srv, connection *con, 
    buffer *b, const struct message *m)
{
    DBusMessage* message = NULL;
    DBusError error;
    DBusMessageIter iter;
    DBusBusType type;
    int reply_timeout = 5000;
    DBusMessage *reply = NULL;
    DBusConnection *conn = NULL;
    const char *gpID = NULL;
    char *temp = NULL;
    char *info = NULL;

    type = DBUS_BUS_SYSTEM;
    dbus_error_init (&error);
    conn = dbus_bus_get (type, &error);

    if (conn == NULL)
    {
        printf ( "Failed to open connection to %s message bus: %s\n", (type == DBUS_BUS_SYSTEM) ? "system" : "session", error.message);
        dbus_error_free (&error);
        return -1;
    }
                                          
    message = dbus_message_new_method_call( dbus_dest, dbus_path, dbus_interface, "clearGroup" );

    printf("handle_cleargroup\n");
    if (message != NULL)
    {
        dbus_message_set_auto_start (message, TRUE);
        dbus_message_iter_init_append( message, &iter );

        gpID = msg_get_header(m, "groupID");

        if ( gpID == NULL )
        {
            gpID = "";
        }
      
        if ( !dbus_message_iter_append_basic( &iter, DBUS_TYPE_STRING, &gpID ) )
        {
            printf( "Out of Memory!\n" );
            exit( 1 );
        }
            
        dbus_error_init( &error );
        reply = dbus_connection_send_with_reply_and_block( conn, message, reply_timeout, &error );

        if ( dbus_error_is_set( &error ) )
        {
            fprintf(stderr, "Error %s: %s\n",
                error.name,
                error.message);
        }

        if ( reply )
        {
            print_message( reply );
            int current_type;
            char *res = NULL;
            dbus_message_iter_init( reply, &iter );

            while ( ( current_type = dbus_message_iter_get_arg_type( &iter ) ) != DBUS_TYPE_INVALID )
            {
                switch ( current_type )
                {
                    case DBUS_TYPE_STRING:
                        dbus_message_iter_get_basic(&iter, &res);
                        break;
                            
                    default:
                        break;
                }

                dbus_message_iter_next (&iter);
            }

            if ( res != NULL )
            {
                info = (char*)malloc((1 + strlen(res)) * sizeof(char));
                sprintf(info, "%s", res);
                temp = info;
            }
            else
            {
                temp = "{\"res\": \"error\", \"msg\": \"can't clear group\"}";
            }

            temp = build_JSON_res( srv, con, m, temp );

            if(info != NULL)
            {
                free(info);
            }

            if ( temp != NULL )
            {
                buffer_append_string( b, temp );
                free(temp);
            }
            dbus_message_unref( reply );
        }

        dbus_message_unref( message );
    }

    return 0;
}

static int handle_removegroup(server *srv, connection *con, 
    buffer *b, const struct message *m)
{
    DBusMessage* message = NULL;
    DBusError error;
    DBusMessageIter iter;
    DBusBusType type;
    int reply_timeout = 5000;
    DBusMessage *reply = NULL;
    DBusConnection *conn = NULL;
    const char *gpID = NULL;
    char *temp = NULL;
    char *info = NULL;

    type = DBUS_BUS_SYSTEM;
    dbus_error_init (&error);
    conn = dbus_bus_get (type, &error);

    if (conn == NULL)
    {
        printf ( "Failed to open connection to %s message bus: %s\n", (type == DBUS_BUS_SYSTEM) ? "system" : "session", error.message);
        dbus_error_free (&error);
        return -1;
    }
                                          
    message = dbus_message_new_method_call( dbus_dest, dbus_path, dbus_interface, "removeGroup" );

    printf("handle_removegroup\n");
    if (message != NULL)
    {
        dbus_message_set_auto_start (message, TRUE);
        dbus_message_iter_init_append( message, &iter );

        gpID = msg_get_header(m, "groupID");

        if ( gpID == NULL )
        {
            gpID = "";
        }
      
        if ( !dbus_message_iter_append_basic( &iter, DBUS_TYPE_STRING, &gpID ) )
        {
            printf( "Out of Memory!\n" );
            exit( 1 );
        }
            
        dbus_error_init( &error );
        reply = dbus_connection_send_with_reply_and_block( conn, message, reply_timeout, &error );

        if ( dbus_error_is_set( &error ) )
        {
            fprintf(stderr, "Error %s: %s\n",
                error.name,
                error.message);
        }

        if ( reply )
        {
            print_message( reply );
            int current_type;
            char *res = NULL;
            dbus_message_iter_init( reply, &iter );

            while ( ( current_type = dbus_message_iter_get_arg_type( &iter ) ) != DBUS_TYPE_INVALID )
            {
                switch ( current_type )
                {
                    case DBUS_TYPE_STRING:
                        dbus_message_iter_get_basic(&iter, &res);
                        break;
                            
                    default:
                        break;
                }

                dbus_message_iter_next (&iter);
            }

            if ( res != NULL )
            {
                info = (char*)malloc((1 + strlen(res)) * sizeof(char));
                sprintf(info, "%s", res);
                temp = info;
            }
            else
            {
                temp = "{\"res\": \"error\", \"msg\": \"can't remove group\"}";
            }

            temp = build_JSON_res( srv, con, m, temp );

            if(info != NULL)
            {
                free(info);
            }

            if ( temp != NULL )
            {
                buffer_append_string( b, temp );
                free(temp);
            }
            dbus_message_unref( reply );
        }

        dbus_message_unref( message );
    }

    return 0;
}

static int handle_movetodefault(server *srv, connection *con, 
    buffer *b, const struct message *m)
{
    DBusMessage* message = NULL;
    DBusError error;
    DBusMessageIter iter;
    DBusBusType type;
    int reply_timeout = 5000;
    DBusMessage *reply = NULL;
    DBusConnection *conn = NULL;
    const char *ctID = NULL;
    char *temp = NULL;
    char *info = NULL;

    type = DBUS_BUS_SYSTEM;
    dbus_error_init (&error);
    conn = dbus_bus_get (type, &error);

    if (conn == NULL)
    {
        printf ( "Failed to open connection to %s message bus: %s\n", (type == DBUS_BUS_SYSTEM) ? "system" : "session", error.message);
        dbus_error_free (&error);
        return -1;
    }
                                          
    message = dbus_message_new_method_call( dbus_dest, dbus_path, dbus_interface, "moveToDefault" );

    printf("handle_movetodefault\n");
    if (message != NULL)
    {
        dbus_message_set_auto_start (message, TRUE);
        dbus_message_iter_init_append( message, &iter );

        ctID = msg_get_header(m, "contactID");

        if ( ctID == NULL )
        {
            ctID = "";
        }
      
        if ( !dbus_message_iter_append_basic( &iter, DBUS_TYPE_STRING, &ctID ) )
        {
            printf( "Out of Memory!\n" );
            exit( 1 );
        }
            
        dbus_error_init( &error );
        reply = dbus_connection_send_with_reply_and_block( conn, message, reply_timeout, &error );

        if ( dbus_error_is_set( &error ) )
        {
            fprintf(stderr, "Error %s: %s\n",
                error.name,
                error.message);
        }

        if ( reply )
        {
            print_message( reply );
            int current_type;
            char *res = NULL;
            dbus_message_iter_init( reply, &iter );

            while ( ( current_type = dbus_message_iter_get_arg_type( &iter ) ) != DBUS_TYPE_INVALID )
            {
                switch ( current_type )
                {
                    case DBUS_TYPE_STRING:
                        dbus_message_iter_get_basic(&iter, &res);
                        break;
                            
                    default:
                        break;
                }

                dbus_message_iter_next (&iter);
            }

            if ( res != NULL )
            {
                info = (char*)malloc((1 + strlen(res)) * sizeof(char));
                sprintf(info, "%s", res);
                temp = info;
            }
            else
            {
                temp = "{\"res\": \"error\", \"msg\": \"can't move contact to default\"}";
            }

            temp = build_JSON_res( srv, con, m, temp );

            if(info != NULL)
            {
                free(info);
            }

            if ( temp != NULL )
            {
                buffer_append_string( b, temp );
                free(temp);
            }
            dbus_message_unref( reply );
        }

        dbus_message_unref( message );
    }

    return 0;
}

static int audio_conversion_new (char *infile, char *outfile, int step)
{
    char * cmd;

    cmd = malloc(128);
    memset(cmd, 0, sizeof(cmd));

    if (step == 0)
        sprintf(cmd, "/system/bin/sox %s -r 8000 -c 1 %s bass -3", infile, outfile);
    else
        sprintf(cmd, "/system/bin/sox %s %s", infile, outfile);
    system(cmd);

    free(cmd);

    return 0;
}

/* conver the audiofile to alaw and ulaw format ,move from 2200 by ahluo on 20140319 */
static int handle_converaudio (buffer *b, const struct message *m)
{
    /* file_ext: extension of the audio file
       acct: the acct number
       filepath: path store the audio file
       infile: the whole name of audio file
       outfile: the whole name of outfile, filepath+ulaw, filepath+alaw
       cmd: system call string
       res_al, res_ul: the return of calling the sox conversion interfaces
    */
    char *file_ext = NULL, *acct = NULL, *filepath = NULL, *infile = NULL,
         *infile_wav = NULL, *infile_temp = NULL, *outfile_al = NULL,
         *outfile_ul = NULL, *cmd = NULL;
    int res, res_al, res_ul;
    FILE *fp = NULL;

    file_ext = msg_get_header(m, "ext");
    acct  = msg_get_header(m, "acct");

    filepath = malloc(64);
    sprintf(filepath, TMP_AUDIOFILEPATH"%s", acct);

    /* change the name of audiofile("audiofile") to the one with extension,
       the sox funcions require */
    cmd = malloc(strlen(filepath)*2 + 32);
    memset(cmd, 0, sizeof(cmd));
    sprintf(cmd, "mv %s/audiofile %s/audiofile.%s", filepath, filepath, file_ext);
    system(cmd);

    infile = malloc(strlen(file_ext) + 64);
    memset(infile, 0, sizeof(infile));
    sprintf(infile, "%s/audiofile.%s", filepath, file_ext);

    /*if (!strcmp(file_ext, "mp3"))
    {
        infile_wav = malloc(strlen(file_ext) + 64);
        memset(infile_wav, 0, sizeof(infile_wav));
        sprintf(infile_wav, "%s/audiofile.wav", filepath);

        res = audio_conversion (infile, infile_wav);
        if(res == -1)
        {
            memset(cmd, 0, sizeof(cmd));
            sprintf(cmd, "rm %s/\*", filepath);
            system(cmd);
            free(cmd);
            free(infile);
            free(infile_wav);
            buffer_append_string(b,
                "Response=Error\r\n");
            printf("read audiofile failed\n");
            return -1;
        }
    }*/

    /*
    infile_temp = malloc(strlen(file_ext) + 64);
    memset(infile_temp, 0, sizeof(infile_temp));
    sprintf(infile_temp, "%s/audiofile_temp.wav", filepath);

    if (infile_wav != NULL)
        res = audio_conversion_rate (infile_wav, infile_temp);
    else
        res = audio_conversion_rate (infile, infile_temp);

    if(res == -1)
    {
        memset(cmd, 0, sizeof(cmd));
        sprintf(cmd, "rm %s/\", filepath);
        system(cmd);
        free(cmd);
        free(infile);
        free(infile_temp);
        if(infile_wav != NULL)
            free(infile_wav);
        buffer_append_string(b,
            "Response=Error\r\n");
        printf("read audiofile failed2\n");
        return -1;
    } */

    outfile_al = malloc(strlen(filepath) + 32);
    memset(outfile_al, 0, sizeof(outfile_al));
    sprintf(outfile_al, "%s/audiofile.al", filepath);
    /* call sox functions. conver the audiofile to alaw format */
    //res_al = audio_conversion(infile_temp, outfile);
    audio_conversion_new (infile, outfile_al, 0);

    fp = fopen (outfile_al, "rb");
    if(fp != NULL)
    {
        fclose(fp);
        /* cmd string : mv .../audiofile.al .../alaw */
        /*memset(cmd, 0, sizeof(cmd));
        sprintf(cmd, "mv %s/audiofile.al %s/alaw", filepath, filepath);
        system(cmd);
        res_al = 0;*/

        outfile_ul = malloc(strlen(filepath) + 32);
        memset(outfile_ul, 0, sizeof(outfile_ul));
        sprintf(outfile_ul, "%s/audiofile.ul", filepath);

        audio_conversion_new (outfile_al, outfile_ul, 1);
    }
    else
    {
        memset(cmd, 0, sizeof(cmd));
        sprintf(cmd, "rm %s/*", filepath);
        system(cmd);
        free(cmd);
        free(infile);
        free(outfile_al);
        buffer_append_string(b,
            "Response=Error\r\n");
        printf("read audiofile failed\n");
        return -1;
    }

    /*
    memset(infile, 0, sizeof(infile));
    sprintf(infile, "%s/audiofile.%s", filepath, file_ext);*/


    //memset(outfile, 0, sizeof(outfile));
    //sprintf(outfile, "%s/audiofile.ul", filepath);
    /* call sox functions. conver the audiofile to ulaw format */
    //res_ul = audio_conversion(infile_temp, outfile);
    //audio_conversion_new (infile, outfile);

    /*fp = fopen (outfile, "rb");
    if(fp != NULL)
    {
        fclose(fp);
        memset(cmd, 0, sizeof(cmd));
        sprintf(cmd, "mv %s/audiofile.ul %s/ulaw", filepath, filepath);
        system(cmd);
        res_ul = 0;
    } else
        res_ul = -1;*/

    memset(cmd, 0, sizeof(cmd));
    sprintf(cmd, "mv %s/audiofile.al %s/alaw", filepath, filepath);
    system(cmd);

    memset(cmd, 0, sizeof(cmd));
    sprintf(cmd, "mv %s/audiofile.ul %s/ulaw", filepath, filepath);
    system(cmd);

    /* delete the audiofile */
    memset(cmd, 0, sizeof(cmd));
    sprintf(cmd, "rm %s", infile);
    system(cmd);

    /*
    memset(cmd, 0, sizeof(cmd));
    sprintf(cmd, "rm %s", infile_temp);
    system(cmd);*/

    /*
    if(infile_wav != NULL)
    {
        memset(cmd, 0, sizeof(cmd));
        sprintf(cmd, "rm %s", infile_wav);
        system(cmd);
        free(infile_wav);
    }*/

    free(cmd);

    buffer_append_string(b,
        "Response=Success\r\n");

    free(filepath);
    free(infile);
    //free(infile_temp);
    free(outfile_al);
    free(outfile_ul);
    return 0;
}

static int handle_savephbkconf (buffer *b, const struct message *m,const char*fileconf)
{
    xmlDocPtr doc = NULL;
    xmlNode *root_element = NULL;
    xmlNode *cur_node = NULL;
    const char *temp = NULL;
    char val[256] = "";
    xmlNodePtr son_node = NULL;
    xmlNodePtr son2_node = NULL;
    char tempbuf[8] = "";
    int tempint;

    doc = xmlReadFile(fileconf, NULL, 0);

    if (doc == NULL)
    {
        printf("error: could not parse file %s\n", fileconf);
        buffer_append_string(b, "Response=Error\r\n"
                "Message=Configuration File Not Found\r\n");
        return -1;
    }

    /*Get the root element node */
    root_element = xmlDocGetRootElement(doc);

    for (cur_node = root_element->xmlChildrenNode; cur_node; cur_node = cur_node->next)
    {
        if (cur_node->type == XML_ELEMENT_NODE)
        {
            //if ((!xmlStrcmp(cur_node->name, BAD_CAST "popular")))
                son_node = cur_node;

                while (son_node != NULL)
                {
                    if ((!xmlStrcmp(son_node->name, (const xmlChar *)"Download")))
                    {
                        son2_node = son_node ->xmlChildrenNode;

                        while (son2_node != NULL)
                        {
                            if (!xmlStrcmp(son2_node->name, (const xmlChar *)"downloadMode"))
                            {
                                temp = msg_get_header(m, "mode");
                                if ( temp != NULL )
                                {
                                    memset(val, 0, sizeof(val));
                                    strncpy(val, temp, sizeof(val) - 1);
                                    uri_decode(val);
                                    xmlNodeSetEncodeContent(doc, son2_node, (xmlChar *)val);
                                }
                            }
                            else if (!xmlStrcmp(son2_node->name, (const xmlChar *)"url"))
                            {
                                temp = msg_get_header(m, "url");
                                if ( temp != NULL )
                                {
                                    memset(val, 0, sizeof(val));
                                    strncpy(val, temp, sizeof(val) - 1);
                                    uri_decode(val);
                                    xmlNodeSetEncodeContent(doc, son2_node, (xmlChar *)val);
                                }
                            }
                            else if (!xmlStrcmp(son2_node->name, (const xmlChar *)"replaceDup"))
                            {
                                temp = msg_get_header(m, "redup");
                                if ( temp != NULL )
                                {
                                    memset(val, 0, sizeof(val));
                                    strncpy(val, temp, sizeof(val) - 1);
                                    uri_decode(val);
                                    xmlNodeSetEncodeContent(doc, son2_node, (xmlChar *)val);
                                }
                            }
                            else if (!xmlStrcmp(son2_node->name, (const xmlChar *)"clearOld"))
                            {
                                temp = msg_get_header(m, "clearold");
                                if ( temp != NULL )
                                {
                                    memset(val, 0, sizeof(val));
                                    strncpy(val, temp, sizeof(val) - 1);
                                    uri_decode(val);
                                    xmlNodeSetEncodeContent(doc, son2_node, (xmlChar *)val);
                                }
                            }else if (!xmlStrcmp(son2_node->name, (const xmlChar *)"interval"))
                            {
                                temp = msg_get_header(m, "interval");
                                if ( temp != NULL )
                                {
                                    memset(val, 0, sizeof(val));
                                    strncpy(val, temp, sizeof(val) - 1);
                                    uri_decode(val);
                                    tempint = atoi(val);
                                    if (tempint < 0)
                                    {
                                        tempint = 0;
                                    }
                                    else if (tempint > 720)
                                    {
                                        tempint = 720;
                                    }
                                    sprintf( tempbuf, "%d", tempint );
                                    xmlNodeSetEncodeContent(doc, son2_node, (xmlChar *)tempbuf);
                                }
                            }
                            else if (!xmlStrcmp(son2_node->name, (const xmlChar *)"fileType"))
                            {
                                temp = msg_get_header(m, "fileType");
                                if ( temp != NULL )
                                {
                                    memset(val, 0, sizeof(val));
                                    strncpy(val, temp, sizeof(val) - 1);
                                    uri_decode(val);
                                    xmlNodeSetEncodeContent(doc, son2_node, (xmlChar *)val);
                                }
                            }
                            else if (!xmlStrcmp(son2_node->name, (const xmlChar *)"encoding"))
                            {
                                temp = msg_get_header(m, "encode");
                                if ( temp != NULL )
                                {
                                    memset(val, 0, sizeof(val));
                                    strncpy(val, temp, sizeof(val) - 1);
                                    uri_decode(val);
                                    xmlNodeSetEncodeContent(doc, son2_node, (xmlChar *)val);
                                }
                            }
                            son2_node = son2_node->next;
                        }
                    }
                    son_node = son_node->next;
                }
        }
    }

    xmlSaveFormatFileEnc(fileconf, doc, "UTF-8", 1);
    xmlFreeDoc(doc);
    xmlCleanupParser();
    xmlMemoryDump();
    sync();

    return 1;
}

static int handle_setPhonebookAddr(server *srv, connection *con, 
    buffer *b, const struct message *m)
{
    char *temp = NULL;

    if(handle_savephbkconf(b,m,CONF_PHBKDOWNLOAD) == -1)
    {
        temp = "{\"res\": \"error\", \"msg\": \"save phonebook configure failed\"}";
        temp = build_JSON_res( srv, con, m, temp );

        if ( temp != NULL )
        {
            buffer_append_string( b, temp );
            free(temp);
        }

        return -1;
    }
    else 
    {
        dbus_send_lighttpd( SIGNAL_LIGHTTPD_PHBKDOWNLOADSAVE);
    }

    temp = "{\"res\": \"success\", \"msg\": \"save phonebook configure\"}";
    temp = build_JSON_res( srv, con, m, temp );

    if ( temp != NULL )
    {
        buffer_append_string( b, temp );
        free(temp);
    }
   
    return 1;
}

static int handle_importPhonebook(server *srv, connection *con, 
    buffer *b, const struct message *m)
{
    char *temp = NULL;

    if(handle_savephbkconf(b,m,CONF_PHBKDOWNLOAD) == -1)
    {
        temp = "{\"res\": \"error\", \"msg\": \"save phonebook configure failed\"}";
        temp = build_JSON_res( srv, con, m, temp );

        if ( temp != NULL )
        {
            buffer_append_string( b, temp );
            free(temp);
        }

        return -1;
    }
    else 
    {
        dbus_send_lighttpd( SIGNAL_LIGHTTPD_PHBKDOWN);
    }
   
    temp = "{\"res\": \"success\", \"msg\": \"download phonebook\"}";
    temp = build_JSON_res( srv, con, m, temp );

    if ( temp != NULL )
    {
        buffer_append_string( b, temp );
        free(temp);
    }

    return 1;
}

static int handle_upgrade(buffer *b, const struct message *m)
{
    if(0 == handle_put(b, m))
    {
#ifdef BUILD_ON_ARM
        system("/sbin/provision");
#endif
    }

    return 0;
}
static int handle_vpnenable(buffer *b)
{
    char res[64] = "";
    const char *val = NULL;

    buffer_append_string(b, "Response=Success\r\n");

#ifdef BUILD_ON_ARM
        val = nvram_my_get("7050");
#else
        val = "Unknow";
#endif
    snprintf(res, sizeof(res),  "7050=%s\r\n", val);
    buffer_append_string(b, res);

    return 0;
}

static int handle_launchservice(server *srv, connection *con, 
    buffer *b, const struct message *m)
{
    DBusMessage* message = NULL;
    DBusError error;
    DBusMessageIter iter;
    DBusBusType type;
    int reply_timeout = 5000;
    DBusMessage *reply = NULL;
    DBusConnection *conn = NULL;
    const char *name = NULL;
    const char *arg = NULL;
    char *temp = NULL;
    char *info = NULL;

    type = DBUS_BUS_SYSTEM;
    dbus_error_init (&error);
    conn = dbus_bus_get (type, &error);

    if (conn == NULL)
    {
        printf ( "Failed to open connection to %s message bus: %s\n", (type == DBUS_BUS_SYSTEM) ? "system" : "session", error.message);
        dbus_error_free (&error);
        return -1;
    }
                                          
    message = dbus_message_new_method_call( dbus_dest, dbus_path, dbus_interface, "launchService" );

    printf("handle_launchservice\n");
    if (message != NULL)
    {
        dbus_message_set_auto_start (message, TRUE);
        dbus_message_iter_init_append( message, &iter );

        name = msg_get_header(m, "name");

        if ( name == NULL )
        {
            name = "";
        }

        arg = msg_get_header(m, "arg");

        if ( arg == NULL )
        {
            arg = "";
        }
        else
        {
            uri_decode( (char*)arg );
        }
      
        if ( !dbus_message_iter_append_basic( &iter, DBUS_TYPE_STRING, &name ) )
        {
            printf( "Out of Memory!\n" );
            exit( 1 );
        }

        if ( !dbus_message_iter_append_basic( &iter, DBUS_TYPE_STRING, &arg ) )
        {
            printf( "Out of Memory!\n" );
            exit( 1 );
        }
            
        dbus_error_init( &error );
        reply = dbus_connection_send_with_reply_and_block( conn, message, reply_timeout, &error );

        if ( dbus_error_is_set( &error ) )
        {
            fprintf(stderr, "Error %s: %s\n",
                error.name,
                error.message);
        }

        if ( reply )
        {
            print_message( reply );
            int current_type;
            char *res = NULL;
            dbus_message_iter_init( reply, &iter );

            while ( ( current_type = dbus_message_iter_get_arg_type( &iter ) ) != DBUS_TYPE_INVALID )
            {
                switch ( current_type )
                {
                    case DBUS_TYPE_STRING:
                        dbus_message_iter_get_basic(&iter, &res);
                        break;
                            
                    default:
                        break;
                }

                dbus_message_iter_next (&iter);
            }

            if ( res != NULL )
            {
                info = (char*)malloc((1 + strlen(res)) * sizeof(char));
                sprintf(info, "%s", res);
                temp = info;
            }
            else
            {
                temp = "{\"res\": \"error\", \"msg\": \"open application failed\"}";
            }

            temp = build_JSON_res( srv, con, m, temp );

            if(info != NULL)
            {
                free(info);
            }

            if ( temp != NULL )
            {
                buffer_append_string( b, temp );
                free(temp);
            }
            dbus_message_unref( reply );
        }

        dbus_message_unref( message );
    }

    return 0;
}

static int handle_closeservice(server *srv, connection *con, 
    buffer *b, const struct message *m)
{
    DBusMessage* message = NULL;
    DBusError error;
    DBusMessageIter iter;
    DBusBusType type;
    int reply_timeout = 5000;
    DBusMessage *reply = NULL;
    DBusConnection *conn = NULL;
    const char *name = NULL;
    char *temp = NULL;
    char *info = NULL;

    type = DBUS_BUS_SYSTEM;
    dbus_error_init (&error);
    conn = dbus_bus_get (type, &error);

    if (conn == NULL)
    {
        printf ( "Failed to open connection to %s message bus: %s\n", (type == DBUS_BUS_SYSTEM) ? "system" : "session", error.message);
        dbus_error_free (&error);
        return -1;
    }
                                          
    message = dbus_message_new_method_call( dbus_dest, dbus_path, dbus_interface, "closeService" );

    printf("handle_closeservice\n");
    if (message != NULL)
    {
        dbus_message_set_auto_start (message, TRUE);
        dbus_message_iter_init_append( message, &iter );

        name = msg_get_header(m, "name");

        if ( name == NULL )
        {
            name = "";
        }
      
        if ( !dbus_message_iter_append_basic( &iter, DBUS_TYPE_STRING, &name ) )
        {
            printf( "Out of Memory!\n" );
            exit( 1 );
        }
            
        dbus_error_init( &error );
        reply = dbus_connection_send_with_reply_and_block( conn, message, reply_timeout, &error );

        if ( dbus_error_is_set( &error ) )
        {
            fprintf(stderr, "Error %s: %s\n",
                error.name,
                error.message);
        }

        if ( reply )
        {
            print_message( reply );
            int current_type;
            char *res = NULL;
            dbus_message_iter_init( reply, &iter );

            while ( ( current_type = dbus_message_iter_get_arg_type( &iter ) ) != DBUS_TYPE_INVALID )
            {
                switch ( current_type )
                {
                    case DBUS_TYPE_STRING:
                        dbus_message_iter_get_basic(&iter, &res);
                        break;
                            
                    default:
                        break;
                }

                dbus_message_iter_next (&iter);
            }

            if ( res != NULL )
            {
                info = (char*)malloc((1 + strlen(res)) * sizeof(char));
                sprintf(info, "%s", res);
                temp = info;
            }
            else
            {
                temp = "{\"res\": \"error\", \"msg\": \"close application failed\"}";
            }

            temp = build_JSON_res( srv, con, m, temp );

            if(info != NULL)
            {
                free(info);
            }

            if ( temp != NULL )
            {
                buffer_append_string( b, temp );
                free(temp);
            }
            dbus_message_unref( reply );
        }

        dbus_message_unref( message );
    }

    return 0;
}

static int handle_closecurservice(server *srv, connection *con, 
    buffer *b, const struct message *m)
{
    DBusMessage* message = NULL;
    DBusError error;
    DBusMessageIter iter;
    DBusBusType type;
    int reply_timeout = 3000;
    DBusMessage *reply = NULL;
    DBusConnection *conn = NULL;
    char *temp = NULL;
    char *info = NULL;

    type = DBUS_BUS_SYSTEM;
    dbus_error_init (&error);
    conn = dbus_bus_get (type, &error);

    if (conn == NULL)
    {
        printf ( "Failed to open connection to %s message bus: %s\n", (type == DBUS_BUS_SYSTEM) ? "system" : "session", error.message);
        dbus_error_free (&error);
        return -1;
    }
                                          
    message = dbus_message_new_method_call( dbus_dest, dbus_path, dbus_interface, "closeCurService" );

    printf("handle_closecurservice\n");
    if (message != NULL)
    {
        dbus_message_set_auto_start (message, TRUE);
            
        dbus_error_init( &error );
        reply = dbus_connection_send_with_reply_and_block( conn, message, reply_timeout, &error );

        if ( dbus_error_is_set( &error ) )
        {
            fprintf(stderr, "Error %s: %s\n",
                error.name,
                error.message);
        }

        if ( reply )
        {
            print_message( reply );
            int current_type;
            char *res = NULL;
            dbus_message_iter_init( reply, &iter );

            while ( ( current_type = dbus_message_iter_get_arg_type( &iter ) ) != DBUS_TYPE_INVALID )
            {
                switch ( current_type )
                {
                    case DBUS_TYPE_STRING:
                        dbus_message_iter_get_basic(&iter, &res);
                        break;
                            
                    default:
                        break;
                }

                dbus_message_iter_next (&iter);
            }

            if ( res != NULL )
            {
                info = (char*)malloc((1 + strlen(res)) * sizeof(char));
                sprintf(info, "%s", res);
                temp = info;
            }
            else
            {
                temp = "{\"res\": \"error\", \"msg\": \"close application failed\"}";
            }

            temp = build_JSON_res( srv, con, m, temp );

            if(info != NULL)
            {
                free(info);
            }

            if ( temp != NULL )
            {
                buffer_append_string( b, temp );
                free(temp);
            }
            dbus_message_unref( reply );
        }

        dbus_message_unref( message );
    }

    return 0;
}

static int handle_grabwindow(server *srv, connection *con, 
    buffer *b, const struct message *m)
{
    DBusMessage* message = NULL;
    DBusError error;
    DBusMessageIter iter;
    DBusBusType type;
    int reply_timeout = 5000;
    DBusMessage *reply = NULL;
    DBusConnection *conn = NULL;
    const char *path = NULL;
    char *temp = NULL;
    char *info = NULL;

    type = DBUS_BUS_SYSTEM;
    dbus_error_init (&error);
    conn = dbus_bus_get (type, &error);

    if (conn == NULL)
    {
        printf ( "Failed to open connection to %s message bus: %s\n", (type == DBUS_BUS_SYSTEM) ? "system" : "session", error.message);
        dbus_error_free (&error);
        return -1;
    }
                                          
    message = dbus_message_new_method_call( dbus_dest, dbus_path, dbus_interface, "grabWindow" );

    printf("handle_grabwindow\n");
    if (message != NULL)
    {
        dbus_message_set_auto_start (message, TRUE);
        dbus_message_iter_init_append( message, &iter );

        path = msg_get_header(m, "path");

        if ( path == NULL )
        {
            path = "";
        }
      
        uri_decode((char*)path);

        if ( !dbus_message_iter_append_basic( &iter, DBUS_TYPE_STRING, &path ) )
        {
            printf( "Out of Memory!\n" );
            exit( 1 );
        }
            
        dbus_error_init( &error );
        reply = dbus_connection_send_with_reply_and_block( conn, message, reply_timeout, &error );

        if ( dbus_error_is_set( &error ) )
        {
            fprintf(stderr, "Error %s: %s\n",
                error.name,
                error.message);
        }

        if ( reply )
        {
            print_message( reply );
            int current_type;
            char *res = NULL;
            dbus_message_iter_init( reply, &iter );

            while ( ( current_type = dbus_message_iter_get_arg_type( &iter ) ) != DBUS_TYPE_INVALID )
            {
                switch ( current_type )
                {
                    case DBUS_TYPE_STRING:
                        dbus_message_iter_get_basic(&iter, &res);
                        break;
                            
                    default:
                        break;
                }

                dbus_message_iter_next (&iter);
            }

            if ( res != NULL )
            {
                info = (char*)malloc((1 + strlen(res)) * sizeof(char));
                sprintf(info, "%s", res);
                temp = info;
            }
            else
            {
                temp = "{\"res\": \"error\", \"msg\": \"save grab failed\"}";
            }

            temp = build_JSON_res( srv, con, m, temp );

            if(info != NULL)
            {
                free(info);
            }

            if ( temp != NULL )
            {
                buffer_append_string( b, temp );
                free(temp);
            }
            dbus_message_unref( reply );
        }

        dbus_message_unref( message );
    }

    return 0;
}

static int handle_swipeScreen(server *srv, connection *con,
    buffer *b, const struct message *m)  {
    int start_x;
    int start_y;
    int end_x;
    int end_y;
    const char *tmp = NULL;
    char *temp = NULL;
    tmp = msg_get_header(m, "start_x");
         if ( tmp != NULL )
        {
            start_x = atoi(tmp);
        }
        else
        {
            start_x = -1;
        }

        tmp = msg_get_header(m, "start_y");

        if ( tmp != NULL )
        {
            start_y = atoi(tmp);
        }
        else
        {
            start_y = -1;
        }
         tmp = msg_get_header(m, "end_x");
        if ( tmp != NULL )
       {
           end_x = atoi(tmp);
       }
       else
       {
           end_x = -1;
       }

       tmp = msg_get_header(m, "end_y");

       if ( tmp != NULL )
       {
           end_y = atoi(tmp);
       }
       else
       {
           end_y = -1;
       }

     FILE *sys_file;
     char buf[128] = "";
     sys_file = fopen ("/proc/gxvboard/dev_info/dev_alias", "r");
     int  max_width = 480;
     int  max_height =272;
     if (sys_file != NULL) {
           fread (buf, 127, 1, sys_file);
           fclose (sys_file);
           printf(" product name %s",buf);
           if(strcmp(buf,"GXV3275") == 0){
             max_width=1024;
             max_height=600;
            }
     }
     printf(" screen max_width %d max_height %d",max_width,max_height);
     if(start_x <0 || start_x >max_width || start_y < 0 || start_y >max_height
     || end_x <0 || end_x >max_width || end_y < 0 || end_y >max_height){
       temp = "{\"res\": \"error\", \"msg\": \"the point out of screen\"}";
    }else{
        char command [50] ={0};
        sprintf(command,"input touchscreen swipe %d %d %d %d",start_x,start_y,end_x,end_y);
        printf("%s command1",command);
        int successflag = system(command);
        printf("input touchscreen result flag %d",successflag);
        if(successflag == -1 || successflag == 127){
            temp = "{\"res\": \"error\", \"msg\": \"the point out of screen\"}";
        }else {
            temp = "{\"res\": \"success\"}";
        }
    }

     temp = build_JSON_res( srv, con, m, temp );
      if (temp != NULL )
      {
          buffer_append_string( b, temp );
          free(temp);
      }
   return 0;
}

static int handle_touchscreen(server *srv, connection *con,
    buffer *b, const struct message *m)  {
    int point_x;
    int point_y;
    int msec = 0;
    const char *tmp = NULL;
    char *temp = NULL;
    tmp = msg_get_header(m, "px");
         if ( tmp != NULL )
        {
            point_x = atoi(tmp);
        }
        else
        {
            point_x = -1;
        }

        tmp = msg_get_header(m, "py");

        if ( tmp != NULL )
        {
            point_y = atoi(tmp);
        }
        else
        {
            point_y = -1;
        }

        tmp = msg_get_header(m, "msec");

        if ( tmp != NULL )
        {
            msec = atoi(tmp);
        }
        else
        {
            msec = 0;
        }
     FILE *sys_file;
    char buf[128] = "";
    sys_file = fopen ("/proc/gxvboard/dev_info/dev_alias", "r");
    int  max_width = 480;
    int  max_height =272;
    if (sys_file != NULL) {
        fread (buf, 127, 1, sys_file);
        fclose (sys_file);
        printf(" product name %s",buf);
        if(strcmp(buf,"GXV3275") == 0){
          max_width=1024;
          max_height=600;
        }
    }
    printf(" screen max_width %d max_height %d",max_width,max_height);
    if(point_x <0 || point_x >max_width || point_y < 0 || point_y >max_height){
        temp = "{\"res\": \"error\", \"msg\": \"the point out of screen\"}";
    }else{
        char command [50] ={0};
        sprintf(command,"input touchscreen tap %d %d %d",point_x,point_y,msec);
        printf("%s command",command);
        int successflag = system(command);
        printf("input touchscreen tap reslut %d",successflag);
        if(successflag == -1 || successflag == 127){
            temp = "{\"res\": \"error\", \"msg\": \"the point out of screen\"}";
        }else {
            temp = "{\"res\": \"success\"}";
        }
    }
     temp = build_JSON_res( srv, con, m, temp );

      if ( temp != NULL )
      {
          buffer_append_string( b, temp );
          free(temp);
      }
   return 0;
}

// old touchscreen method (under gmiversion 8)
/*static int handle_touchscreen(server *srv, connection *con,
    buffer *b, const struct message *m)
{


    DBusMessage* message = NULL;
    DBusError error;
    DBusMessageIter iter;
    DBusBusType type;
    int reply_timeout = 5000;
    DBusMessage *reply = NULL;
    DBusConnection *conn = NULL;
    int point_x;
    int point_y;
    int msec = 0;
    const char *tmp = NULL;
    char *temp = NULL;
    char *info = NULL;

    type = DBUS_BUS_SYSTEM;
    dbus_error_init (&error);
    conn = dbus_bus_get (type, &error);

    if (conn == NULL)
    {
        printf ( "Failed to open connection to %s message bus: %s\n", (type == DBUS_BUS_SYSTEM) ? "system" : "session", error.message);
        dbus_error_free (&error);
        return -1;
    }

    message = dbus_message_new_method_call( dbus_dest, dbus_path, dbus_interface, "touchScreen" );

    printf("handle_touchscreen\n");
    if (message != NULL)
    {
        dbus_message_set_auto_start (message, TRUE);
        dbus_message_iter_init_append( message, &iter );

        tmp = msg_get_header(m, "px");

        if ( tmp != NULL )
        {
            point_x = atoi(tmp);
        }
        else
        {
            point_x = -1;
        }

        tmp = msg_get_header(m, "py");

        if ( tmp != NULL )
        {
            point_y = atoi(tmp);
        }
        else
        {
            point_y = -1;
        }

        tmp = msg_get_header(m, "msec");

        if ( tmp != NULL )
        {
            msec = atoi(tmp);
        }
        else
        {
            msec = 0;
        }

        if ( !dbus_message_iter_append_basic( &iter, DBUS_TYPE_INT32, &point_x) )
        {
            printf( "Out of Memory!\n" );
            exit( 1 );
        }

        if ( !dbus_message_iter_append_basic( &iter, DBUS_TYPE_INT32, &point_y) )
        {
            printf( "Out of Memory!\n" );
            exit( 1 );
        }

        if ( !dbus_message_iter_append_basic( &iter, DBUS_TYPE_INT32, &msec) )
        {
            printf( "Out of Memory!\n" );
            exit( 1 );
        }

        dbus_error_init( &error );
        reply = dbus_connection_send_with_reply_and_block( conn, message, reply_timeout, &error );

        if ( dbus_error_is_set( &error ) )
        {
            fprintf(stderr, "Error %s: %s\n",
                error.name,
                error.message);
        }

        if ( reply )
        {
            print_message( reply );
            int current_type;
            char *res = NULL;
            dbus_message_iter_init( reply, &iter );

            while ( ( current_type = dbus_message_iter_get_arg_type( &iter ) ) != DBUS_TYPE_INVALID )
            {
                switch ( current_type )
                {
                    case DBUS_TYPE_STRING:
                        dbus_message_iter_get_basic(&iter, &res);
                        break;

                    default:
                        break;
                }

                dbus_message_iter_next (&iter);
            }

            if ( res != NULL )
            {
                info = (char*)malloc((1 + strlen(res)) * sizeof(char));
                sprintf(info, "%s", res);
                temp = info;
            }
            else
            {
                temp = "{\"res\": \"error\", \"msg\": \"touch screen failed\"}";
            }

            temp = build_JSON_res( srv, con, m, temp );

            if(info != NULL)
            {
                free(info);
            }

            if ( temp != NULL )
            {
                buffer_append_string( b, temp );
                free(temp);
            }
            dbus_message_unref( reply );
        }

        dbus_message_unref( message );
    }

    return 0;
}*/

static int handle_getmessage(server *srv, connection *con, 
    buffer *b, const struct message *m)
{
    DBusMessage* message = NULL;
    DBusError error;
    DBusMessageIter iter;
    DBusBusType type;
    int reply_timeout = 5000;
    DBusMessage *reply = NULL;
    DBusConnection *conn = NULL;
    const char* tmp = NULL;
    int flag = -1;
    char *temp = NULL;
    char *info = NULL;

    type = DBUS_BUS_SYSTEM;
    dbus_error_init (&error);
    conn = dbus_bus_get (type, &error);

    if (conn == NULL)
    {
        printf ( "Failed to open connection to %s message bus: %s\n", (type == DBUS_BUS_SYSTEM) ? "system" : "session", error.message);
        dbus_error_free (&error);
        return -1;
    }
                                          
    message = dbus_message_new_method_call( dbus_dest, dbus_path, dbus_interface, "getMessage" );

    printf("handle_getmessage\n");
    if (message != NULL)
    {
        dbus_message_set_auto_start (message, TRUE);
        dbus_message_iter_init_append( message, &iter );

        tmp = msg_get_header(m, "id");

        if ( tmp != NULL)
        {
            flag = atoi(tmp);
        }

        if ( !dbus_message_iter_append_basic( &iter, DBUS_TYPE_INT32, &flag) )
        {
            printf( "Out of Memory!\n" );
            exit( 1 );
        }
            
        dbus_error_init( &error );
        reply = dbus_connection_send_with_reply_and_block( conn, message, reply_timeout, &error );

        if ( dbus_error_is_set( &error ) )
        {
            fprintf(stderr, "Error %s: %s\n",
                error.name,
                error.message);
        }

        if ( reply )
        {
            print_message( reply );
            int current_type;
            char *res = NULL;
            dbus_message_iter_init( reply, &iter );

            while ( ( current_type = dbus_message_iter_get_arg_type( &iter ) ) != DBUS_TYPE_INVALID )
            {
                switch ( current_type )
                {
                    case DBUS_TYPE_STRING:
                        dbus_message_iter_get_basic(&iter, &res);
                        break;
                            
                    default:
                        break;
                }

                dbus_message_iter_next (&iter);
            }

            if ( res != NULL )
            {
                info = (char*)malloc((1 + strlen(res)) * sizeof(char));
                sprintf(info, "%s", res);
                temp = info;
            }
            else
            {
                temp = "{\"res\": \"error\", \"msg\": \"get message failed\"}";
            }

            temp = build_JSON_formate( srv, con, m, temp );

            if(info != NULL)
            {
                free(info);
            }

            if ( temp != NULL )
            {
                buffer_append_string( b, temp );
                free(temp);
            }
            dbus_message_unref( reply );
        }

        dbus_message_unref( message );
    }

    return 0;
}

static int handle_setnewmessage(server *srv, connection *con, 
    buffer *b, const struct message *m)
{
    DBusMessage* message = NULL;
    DBusError error;
    DBusMessageIter iter;
    DBusBusType type;
    int reply_timeout = 5000;
    DBusMessage *reply = NULL;
    DBusConnection *conn = NULL;
    const char* tmp = NULL;
    const char* num = NULL;
    const char* account = NULL;
    const char* text = NULL;
    int send = 0;
    char *temp = NULL;
    char *info = NULL;

    type = DBUS_BUS_SYSTEM;
    dbus_error_init (&error);
    conn = dbus_bus_get (type, &error);

    if (conn == NULL)
    {
        printf ( "Failed to open connection to %s message bus: %s\n", (type == DBUS_BUS_SYSTEM) ? "system" : "session", error.message);
        dbus_error_free (&error);
        return -1;
    }
                                          
    message = dbus_message_new_method_call( dbus_dest, dbus_path, dbus_interface, "setNewMessage" );

    printf("handle_setnewmessage\n");
    if (message != NULL)
    {
        dbus_message_set_auto_start (message, TRUE);
        dbus_message_iter_init_append( message, &iter );

        num = msg_get_header(m, "number");

        if ( num == NULL )
        {
            num = "";
        }
      
        account = msg_get_header(m, "account");

        if ( account == NULL )
        {
            account = "";
        }

        text = msg_get_header(m, "content");

        if ( text == NULL )
        {
            text = "";
        }
        else
        {
            uri_decode( (char*)text );
        }

        tmp = msg_get_header(m, "flag");

        if ( tmp != NULL)
        {
            if(!strcasecmp(tmp, "1"))
            {
                send = 1;
            }
            else
            {
                send = 0;
            }
        }

        if ( !dbus_message_iter_append_basic( &iter, DBUS_TYPE_STRING, &num) )
        {
            printf( "Out of Memory!\n" );
            exit( 1 );
        }

        if ( !dbus_message_iter_append_basic( &iter, DBUS_TYPE_STRING, &account) )
        {
            printf( "Out of Memory!\n" );
            exit( 1 );
        }

        if ( !dbus_message_iter_append_basic( &iter, DBUS_TYPE_STRING, &text) )
        {
            printf( "Out of Memory!\n" );
            exit( 1 );
        }

        if ( !dbus_message_iter_append_basic( &iter, DBUS_TYPE_INT32, &send) )
        {
            printf( "Out of Memory!\n" );
            exit( 1 );
        }
            
        dbus_error_init( &error );
        reply = dbus_connection_send_with_reply_and_block( conn, message, reply_timeout, &error );

        if ( dbus_error_is_set( &error ) )
        {
            fprintf(stderr, "Error %s: %s\n",
                error.name,
                error.message);
        }

        if ( reply )
        {
            print_message( reply );
            int current_type;
            char *res = NULL;
            dbus_message_iter_init( reply, &iter );

            while ( ( current_type = dbus_message_iter_get_arg_type( &iter ) ) != DBUS_TYPE_INVALID )
            {
                switch ( current_type )
                {
                    case DBUS_TYPE_STRING:
                        dbus_message_iter_get_basic(&iter, &res);
                        break;
                            
                    default:
                        break;
                }

                dbus_message_iter_next (&iter);
            }

            if ( res != NULL )
            {
                info = (char*)malloc((1 + strlen(res)) * sizeof(char));
                sprintf(info, "%s", res);
                temp = info;
            }
            else
            {
                temp = "{\"res\": \"error\", \"msg\": \"set new message failed\"}";
            }

            temp = build_JSON_res( srv, con, m, temp );

            if(info != NULL)
            {
                free(info);
            }

            if ( temp != NULL )
            {
                buffer_append_string( b, temp );
                free(temp);
            }
            dbus_message_unref( reply );
        }

        dbus_message_unref( message );
    }

    return 0;
}

static int handle_senddraftmessage(server *srv, connection *con, 
    buffer *b, const struct message *m)
{
    DBusMessage* message = NULL;
    DBusError error;
    DBusMessageIter iter;
    DBusBusType type;
    int reply_timeout = 5000;
    DBusMessage *reply = NULL;
    DBusConnection *conn = NULL;
    const char* id = NULL;
    char *temp = NULL;
    char *info = NULL;

    type = DBUS_BUS_SYSTEM;
    dbus_error_init (&error);
    conn = dbus_bus_get (type, &error);

    if (conn == NULL)
    {
        printf ( "Failed to open connection to %s message bus: %s\n", (type == DBUS_BUS_SYSTEM) ? "system" : "session", error.message);
        dbus_error_free (&error);
        return -1;
    }
                                          
    message = dbus_message_new_method_call( dbus_dest, dbus_path, dbus_interface, "sendDraftMessage" );

    printf("handle_senddraftmessage\n");
    if (message != NULL)
    {
        dbus_message_set_auto_start (message, TRUE);
        dbus_message_iter_init_append( message, &iter );

        id = msg_get_header(m, "messageID");

        if ( id == NULL)
        {
            id = "";
        }

        if ( !dbus_message_iter_append_basic( &iter, DBUS_TYPE_STRING, &id) )
        {
            printf( "Out of Memory!\n" );
            exit( 1 );
        }
            
        dbus_error_init( &error );
        reply = dbus_connection_send_with_reply_and_block( conn, message, reply_timeout, &error );

        if ( dbus_error_is_set( &error ) )
        {
            fprintf(stderr, "Error %s: %s\n",
                error.name,
                error.message);
        }

        if ( reply )
        {
            print_message( reply );
            int current_type;
            char *res = NULL;
            dbus_message_iter_init( reply, &iter );

            while ( ( current_type = dbus_message_iter_get_arg_type( &iter ) ) != DBUS_TYPE_INVALID )
            {
                switch ( current_type )
                {
                    case DBUS_TYPE_STRING:
                        dbus_message_iter_get_basic(&iter, &res);
                        break;
                            
                    default:
                        break;
                }

                dbus_message_iter_next (&iter);
            }

            if ( res != NULL )
            {
                info = (char*)malloc((1 + strlen(res)) * sizeof(char));
                sprintf(info, "%s", res);
                temp = info;
            }
            else
            {
                temp = "{\"res\": \"error\", \"msg\": \"send message failed\"}";
            }

            temp = build_JSON_res( srv, con, m, temp );

            if(info != NULL)
            {
                free(info);
            }

            if ( temp != NULL )
            {
                buffer_append_string( b, temp );
                free(temp);
            }
            dbus_message_unref( reply );
        }

        dbus_message_unref( message );
    }

    return 0;
}

static int handle_removemessage(server *srv, connection *con, 
    buffer *b, const struct message *m)
{
    DBusMessage* message = NULL;
    DBusError error;
    DBusMessageIter iter;
    DBusBusType type;
    int reply_timeout = 5000;
    DBusMessage *reply = NULL;
    DBusConnection *conn = NULL;
    const char* tmp = NULL;
    const char* id = NULL;
    int flag = 0;
    char *temp = NULL;
    char *info = NULL;

    type = DBUS_BUS_SYSTEM;
    dbus_error_init (&error);
    conn = dbus_bus_get (type, &error);

    if (conn == NULL)
    {
        printf ( "Failed to open connection to %s message bus: %s\n", (type == DBUS_BUS_SYSTEM) ? "system" : "session", error.message);
        dbus_error_free (&error);
        return -1;
    }
                                          
    message = dbus_message_new_method_call( dbus_dest, dbus_path, dbus_interface, "removeMessage" );

    printf("handle_removemessage\n");
    if (message != NULL)
    {
        dbus_message_set_auto_start (message, TRUE);
        dbus_message_iter_init_append( message, &iter );

        id = msg_get_header(m, "ID");

        if ( id == NULL )
        {
            id = "";
        }

        tmp = msg_get_header(m, "flag");

        if ( tmp != NULL)
        {
            if(!strcasecmp(tmp, "1"))
            {
                flag = 1;
            }
            else
            {
                flag = 0;
            }
        }

        if ( !dbus_message_iter_append_basic( &iter, DBUS_TYPE_STRING, &id) )
        {
            printf( "Out of Memory!\n" );
            exit( 1 );
        }

        if ( !dbus_message_iter_append_basic( &iter, DBUS_TYPE_INT32, &flag) )
        {
            printf( "Out of Memory!\n" );
            exit( 1 );
        }
            
        dbus_error_init( &error );
        reply = dbus_connection_send_with_reply_and_block( conn, message, reply_timeout, &error );

        if ( dbus_error_is_set( &error ) )
        {
            fprintf(stderr, "Error %s: %s\n",
                error.name,
                error.message);
        }

        if ( reply )
        {
            print_message( reply );
            int current_type;
            char *res = NULL;
            dbus_message_iter_init( reply, &iter );

            while ( ( current_type = dbus_message_iter_get_arg_type( &iter ) ) != DBUS_TYPE_INVALID )
            {
                switch ( current_type )
                {
                    case DBUS_TYPE_STRING:
                        dbus_message_iter_get_basic(&iter, &res);
                        break;
                            
                    default:
                        break;
                }

                dbus_message_iter_next (&iter);
            }

            if ( res != NULL )
            {
                info = (char*)malloc((1 + strlen(res)) * sizeof(char));
                sprintf(info, "%s", res);
                temp = info;
            }
            else
            {
                temp = "{\"res\": \"error\", \"msg\": \"remove message failed\"}";
            }

            temp = build_JSON_res( srv, con, m, temp );

            if(info != NULL)
            {
                free(info);
            }

            if ( temp != NULL )
            {
                buffer_append_string( b, temp );
                free(temp);
            }
            dbus_message_unref( reply );
        }

        dbus_message_unref( message );
    }

    return 0;
}

static int handle_savemessage(buffer *b, const struct message *m)
{
    const char *path = NULL;
    char *json = NULL;
    char *result = NULL;
    int len = 0;
    int reply_timeout = 10000;
    DBusMessage *message = NULL;
    DBusMessage *reply = NULL;
    DBusBusType type;
    DBusError error;
    DBusConnection *conn = NULL;
    DBusMessageIter iter;
    const char *resType = NULL;
    const char *jsonCallback = NULL;
    char *temp = NULL;

    resType = msg_get_header(m, "format");
    if (resType != NULL && !strcasecmp(resType, "json")) {
        jsonCallback = msg_get_header(m, "jsoncallback");
    }

    if( access( TMP_MESSAGEPATH, 0 ) )
    {
        mkdir(TMP_MESSAGEPATH, 0777);
    }

    path = malloc(strlen(TMP_MESSAGEPATH) + strlen("/message.xml") + 4);
    sprintf(path, "%s/%s", TMP_MESSAGEPATH, "message.xml");

    message = dbus_message_new_method_call(dbus_dest, dbus_path, dbus_interface, "saveMessage");
    printf("handle_savemessage");

    type = DBUS_BUS_SYSTEM;
    dbus_error_init(&error);
    conn = dbus_bus_get(type, &error);
    if (conn == NULL) {
        printf("Failed to open connection to %s message bus: %s\n", (type == DBUS_BUS_SYSTEM) ? "system" : "session", error.message);
        dbus_error_free(&error);
        if (message != NULL) {
            dbus_message_unref(message);
        }
        free(path);

        return -1;
    }

    if (message != NULL) {
        dbus_message_set_auto_start(message, TRUE);
        dbus_message_iter_init_append(message, &iter);

        len = 8 + strlen(path) + strlen(", \"path\": \"\"");
        json = malloc(len * sizeof(char));
        if (json != NULL) {
            snprintf(json, len-1, "{\"path\": \"%s\"}", path);

            if (!dbus_message_iter_append_basic(&iter, DBUS_TYPE_STRING, &json)) {
                printf("Out of Memory!\n");
                free(path);
                free(json);
                exit(1);
            }

            reply = dbus_connection_send_with_reply_and_block(conn, message, reply_timeout, &error);
            if (dbus_error_is_set(&error)) {
                fprintf(stderr, "Error %s: %s\n", error.name, error.message);
            }

            free(json);

            if (reply) {
                print_message(reply);
                int current_type;
                dbus_message_iter_init(reply, &iter);
                
                while((current_type = dbus_message_iter_get_arg_type(&iter)) != DBUS_TYPE_INVALID) {
                    switch(current_type) {
                        case DBUS_TYPE_STRING:
                            dbus_message_iter_get_basic(&iter, &result);
                            break;
                        default:
                            break;
                    }

                    dbus_message_iter_next(&iter);
                }

                if (result != NULL) {
                    if (jsonCallback != NULL) {
                        temp = malloc((strlen(jsonCallback) + strlen(result) + 8) * sizeof(char));
                        if (temp != NULL) {
                            sprintf(temp, "%s(%s)", jsonCallback, result);
                            buffer_append_string(b, temp);
                            free(temp);
                        }
                    } else {
                        buffer_append_string(b, result);
                    }
                }

                dbus_message_unref(reply);
            }
        }

        dbus_message_unref(message);
    }

    free(path);

    return 1;
}

static int handle_getlastcall(server *srv, connection *con, 
    buffer *b, const struct message *m)
{
    DBusMessage* message = NULL;
    DBusError error;
    DBusMessageIter iter;
    DBusBusType type;
    int reply_timeout = 5000;
    DBusMessage *reply = NULL;
    DBusConnection *conn = NULL;
    const char* tmp = NULL;
    int flag = 0;
    char *temp = NULL;
    char *info = NULL;

    type = DBUS_BUS_SYSTEM;
    dbus_error_init (&error);
    conn = dbus_bus_get (type, &error);

    if (conn == NULL)
    {
        printf ( "Failed to open connection to %s message bus: %s\n", (type == DBUS_BUS_SYSTEM) ? "system" : "session", error.message);
        dbus_error_free (&error);
        return -1;
    }
                                          
    message = dbus_message_new_method_call( dbus_dest, dbus_path, dbus_interface, "getLastCall" );

    printf("handle_getlastcall\n");
    if (message != NULL)
    {
        dbus_message_set_auto_start (message, TRUE);
        dbus_message_iter_init_append( message, &iter );

        tmp = msg_get_header(m, "type");

        if ( tmp != NULL)
        {
            flag = atoi(tmp);
        }

        if ( !dbus_message_iter_append_basic( &iter, DBUS_TYPE_INT32, &flag) )
        {
            printf( "Out of Memory!\n" );
            exit( 1 );
        }
            
        dbus_error_init( &error );
        reply = dbus_connection_send_with_reply_and_block( conn, message, reply_timeout, &error );

        if ( dbus_error_is_set( &error ) )
        {
            fprintf(stderr, "Error %s: %s\n",
                error.name,
                error.message);
        }

        if ( reply )
        {
            print_message( reply );
            int current_type;
            char *res = NULL;
            dbus_message_iter_init( reply, &iter );

            while ( ( current_type = dbus_message_iter_get_arg_type( &iter ) ) != DBUS_TYPE_INVALID )
            {
                switch ( current_type )
                {
                    case DBUS_TYPE_STRING:
                        dbus_message_iter_get_basic(&iter, &res);
                        break;
                            
                    default:
                        break;
                }

                dbus_message_iter_next (&iter);
            }

            if ( res != NULL )
            {
                info = (char*)malloc((1 + strlen(res)) * sizeof(char));
                sprintf(info, "%s", res);
                temp = info;
            }
            else
            {
                temp = "{\"res\": \"error\", \"msg\": \"get last call failed\"}";
            }

            temp = build_JSON_res( srv, con, m, temp );

            if(info != NULL)
            {
                free(info);
            }

            if ( temp != NULL )
            {
                buffer_append_string( b, temp );
                free(temp);
            }
            dbus_message_unref( reply );
        }

        dbus_message_unref( message );
    }

    return 0;
}

static int handle_removecall(server *srv, connection *con, 
    buffer *b, const struct message *m)
{
    DBusMessage* message = NULL;
    DBusError error;
    DBusMessageIter iter;
    DBusBusType type;
    int reply_timeout = 5000;
    DBusMessage *reply = NULL;
    DBusConnection *conn = NULL;
    const char* tmp = NULL;
    const char* id = NULL;
    int flag = 0;
    char *temp = NULL;
    char *info = NULL;

    type = DBUS_BUS_SYSTEM;
    dbus_error_init (&error);
    conn = dbus_bus_get (type, &error);

    if (conn == NULL)
    {
        printf ( "Failed to open connection to %s message bus: %s\n", (type == DBUS_BUS_SYSTEM) ? "system" : "session", error.message);
        dbus_error_free (&error);
        return -1;
    }
                                          
    message = dbus_message_new_method_call( dbus_dest, dbus_path, dbus_interface, "removeCall" );

    printf("handle_removecall\n");
    if (message != NULL)
    {
        dbus_message_set_auto_start (message, TRUE);
        dbus_message_iter_init_append( message, &iter );

        id = msg_get_header(m, "ID");

        if ( id == NULL )
        {
            id = "";
        }

        tmp = msg_get_header(m, "flag");

        if ( tmp != NULL)
        {
            if(!strcasecmp(tmp, "1"))
            {
                flag = 1;
            }
            else
            {
                flag = 0;
            }
        }

        if ( !dbus_message_iter_append_basic( &iter, DBUS_TYPE_STRING, &id) )
        {
            printf( "Out of Memory!\n" );
            exit( 1 );
        }

        if ( !dbus_message_iter_append_basic( &iter, DBUS_TYPE_INT32, &flag) )
        {
            printf( "Out of Memory!\n" );
            exit( 1 );
        }
            
        dbus_error_init( &error );
        reply = dbus_connection_send_with_reply_and_block( conn, message, reply_timeout, &error );

        if ( dbus_error_is_set( &error ) )
        {
            fprintf(stderr, "Error %s: %s\n",
                error.name,
                error.message);
        }

        if ( reply )
        {
            print_message( reply );
            int current_type;
            char *res = NULL;
            dbus_message_iter_init( reply, &iter );

            while ( ( current_type = dbus_message_iter_get_arg_type( &iter ) ) != DBUS_TYPE_INVALID )
            {
                switch ( current_type )
                {
                    case DBUS_TYPE_STRING:
                        dbus_message_iter_get_basic(&iter, &res);
                        break;
                            
                    default:
                        break;
                }

                dbus_message_iter_next (&iter);
            }

            if ( res != NULL )
            {
                info = (char*)malloc((1 + strlen(res)) * sizeof(char));
                sprintf(info, "%s", res);
                temp = info;
            }
            else
            {
                temp = "{\"res\": \"error\", \"msg\": \"remove call failed\"}";
            }

            temp = build_JSON_res( srv, con, m, temp );

            if(info != NULL)
            {
                free(info);
            }

            if ( temp != NULL )
            {
                buffer_append_string( b, temp );
                free(temp);
            }
            dbus_message_unref( reply );
        }

        dbus_message_unref( message );
    }

    return 0;
}

static int handle_savecallhistory(buffer *b, const struct message *m)
{
    const char *path = NULL;
    char *json = NULL;
    char *result = NULL;
    int len = 0;
    int reply_timeout = 10000;
    DBusMessage *message = NULL;
    DBusMessage *reply = NULL;
    DBusBusType type;
    DBusError error;
    DBusConnection *conn = NULL;
    DBusMessageIter iter;
    const char *resType = NULL;
    const char *jsonCallback = NULL;
    char *temp = NULL;

    resType = msg_get_header(m, "format");
    if (resType != NULL && !strcasecmp(resType, "json")) {
        jsonCallback = msg_get_header(m, "jsoncallback");
    }

    if( access( TMP_CALLHISTORYPATH, 0 ) )
    {
        mkdir(TMP_CALLHISTORYPATH, 0777);
    }

    path = malloc(strlen(TMP_CALLHISTORYPATH) + strlen("/callhistory.xml") + 4);
    sprintf(path, "%s/%s", TMP_CALLHISTORYPATH, "callhistory.xml");

    message = dbus_message_new_method_call(dbus_dest, dbus_path, dbus_interface, "saveCallhistory");
    printf("handle_savemessage");

    type = DBUS_BUS_SYSTEM;
    dbus_error_init(&error);
    conn = dbus_bus_get(type, &error);
    if (conn == NULL) {
        printf("Failed to open connection to %s message bus: %s\n", (type == DBUS_BUS_SYSTEM) ? "system" : "session", error.message);
        dbus_error_free(&error);
        if (message != NULL) {
            dbus_message_unref(message);
        }
        free(path);

        return -1;
    }

    if (message != NULL) {
        dbus_message_set_auto_start(message, TRUE);
        dbus_message_iter_init_append(message, &iter);

        len = 8 + strlen(path) + strlen(", \"path\": \"\"");
        json = malloc(len * sizeof(char));
        if (json != NULL) {
            snprintf(json, len-1, "{\"path\": \"%s\"}", path);

            if (!dbus_message_iter_append_basic(&iter, DBUS_TYPE_STRING, &json)) {
                printf("Out of Memory!\n");
                free(path);
                free(json);
                exit(1);
            }

            reply = dbus_connection_send_with_reply_and_block(conn, message, reply_timeout, &error);
            if (dbus_error_is_set(&error)) {
                fprintf(stderr, "Error %s: %s\n", error.name, error.message);
            }

            free(json);

            if (reply) {
                print_message(reply);
                int current_type;
                dbus_message_iter_init(reply, &iter);
                
                while((current_type = dbus_message_iter_get_arg_type(&iter)) != DBUS_TYPE_INVALID) {
                    switch(current_type) {
                        case DBUS_TYPE_STRING:
                            dbus_message_iter_get_basic(&iter, &result);
                            break;
                        default:
                            break;
                    }

                    dbus_message_iter_next(&iter);
                }

                if (result != NULL) {
                    if (jsonCallback != NULL) {
                        temp = malloc((strlen(jsonCallback) + strlen(result) + 8) * sizeof(char));
                        if (temp != NULL) {
                            sprintf(temp, "%s(%s)", jsonCallback, result);
                            buffer_append_string(b, temp);
                            free(temp);
                        }
                    } else {
                        buffer_append_string(b, result);
                    }
                }

                dbus_message_unref(reply);
            }
        }

        dbus_message_unref(message);
    }

    free(path);

    return 1;
}

#endif

static int handle_setheadsettype (buffer *b, const struct message *m)
{
	char *temp = NULL;
	int val;

	temp = msg_get_header(m, "val");
	val = atoi(temp);

	if (val == 0)
		system("echo 'headset' > /sys/class/switch/ehs/ehs_type");
	else
		if (val == 1)
			system("echo 'plantronics' > /sys/class/switch/ehs/ehs_type");
		else
			system("echo 'jabra' > /sys/class/switch/ehs/ehs_type");

	buffer_append_string(b, "Response=Success\r\n");

	return 0;
}

static int process_upload(server *srv, connection *con, buffer *b, const struct message *m)
{
    printf("process_upload---------\r\n");
    //FILE *file_fd = NULL;
    int file_fd;
    char *file_name = NULL;
    char temp[32] = "";
    char * start = NULL;
    size_t length = 0;
    char *end = NULL;
    int strip_header = 0;
    char *chunk_start = NULL;
    char *chunk_end = NULL;
    int boundary_length = 29;
    char *boundary_ptr = NULL;
    const char *resType = NULL;
    char *tmp = NULL;
    const char * jsonCallback = NULL;
    size_t whlength = 0;

	if (con->request.content_length) 
	{
		chunkqueue *cq = con->request_content_queue;
                chunk *c;
        
		assert(chunkqueue_length(cq) == (off_t)con->request.content_length);
#ifndef BUILD_RECOVER
                file_name = generate_file_name(b, m);
#else
                file_name = generate_file_name_recover(b, m);
#endif

                //buffer_append_string(b, file_name);
        if (file_name == NULL)
        {
            return -1;
        }

        printf("file name is -----%s-----------\n", file_name);

        //file_fd = fopen(file_name, "w+");
        if( strcasecmp(file_name, FIFO_PATH) == 0 )
        {
            file_fd = open( file_name, O_WRONLY );
        }else
        {
            if( !access(file_name, 0) )
            {
                printf("file ---EXIST\n");
                unlink(file_name);
            }
            file_fd = open( file_name, O_WRONLY | O_CREAT, S_IRWXU);
        }
        if ( file_fd < 0 )
        {
            free(file_name);
            printf("open failed \n");
            return -1;
        }

        boundary_ptr = strstr(con->request.http_content_type, "boundary=");
        if (boundary_ptr != NULL)
        {
            boundary_length = strlen(boundary_ptr);
        }

        /* there is content to send */
		for (c = cq->first; c; c = cq->first) {
            int r = 0;
                    strip_header++;
			/* copy all chunks */
			switch(c->type) {
			case FILE_CHUNK:
                            printf("file chunk -----------------\n");
				if (c->file.mmap.start == MAP_FAILED) {
					if (-1 == c->file.fd &&  /* open the file if not already open */
					    -1 == (c->file.fd = open(c->file.name->ptr, O_RDONLY))) {
						log_error_write(srv, __FILE__, __LINE__, "ss", "open failed: ", strerror(errno));
                        free(file_name);
                        snprintf(temp,sizeof(temp),"open O_RDONLY failed\r\n");
                        buffer_append_string(b,temp);
                                                close(file_fd);
						return -1;
					}

					c->file.mmap.length = c->file.length;

					if (MAP_FAILED == (c->file.mmap.start = mmap(0,  c->file.mmap.length, PROT_READ, MAP_SHARED, c->file.fd, 0))) {
						log_error_write(srv, __FILE__, __LINE__, "ssbd", "mmap failed: ",
								strerror(errno), c->file.name,  c->file.fd);
                        free(file_name);
                        snprintf(temp,sizeof(temp),"open PROT_READ failed\r\n");
                        buffer_append_string(b,temp);
                                                close(file_fd);
						return -1;
					}

					close(c->file.fd);
					c->file.fd = -1;

					/* chunk_reset() or chunk_free() will cleanup for us */
				}

                            if (chunk_start != NULL)
                            {
                                free(chunk_start);
                                chunk_start = NULL;
                            }

                            chunk_start = malloc(c->file.mmap.length + 1);
                            memset(chunk_start, 0, c->file.mmap.length + 1);
                            memcpy(chunk_start, c->file.mmap.start, c->file.mmap.length);
                            chunk_end = chunk_start + c->file.mmap.length;

                            /*if ((!strcasecmp(file_name, TEMP_PATH"/ringtone.mp3")))
                            {
#ifndef BUILD_RECOVER
                                if ((start = strstr(chunk_start + c->offset, "filename=\"")) != NULL)
                                {
                                    char *tempval = NULL;
                                    close(file_fd);
                                    free(file_name);
                                    end = strstr(start, "\"\r\n");
                                    start += strlen("filename=");
                                    tempval = start;
                                    if ((start = strrchr(start, '\\')) == NULL)
                                    {
                                        start = strrchr(tempval, '\/');
                                    }
                                    
                                    if ((start > end) || start == NULL)
                                    {
                                        start = tempval;
                                    }
                                    start++;
                                    length = strstr(start, "\"") - start;
                                    tempval = strndup( (const char* ) start, length );
                                    file_name = malloc( strlen(RINGTONE_PATH) + strlen(tempval) + 2 );
                                    sprintf(file_name, "%s/%s", RINGTONE_PATH, tempval);
                                    printf("resctuct file name to %s==============\n", file_name);
                                    //file_fd = fopen(file_name, "w+");
                                    file_fd = open(file_name, O_WRONLY);
                                    free(tempval);
                                    if ( file_fd == -1 )
                                    {
                                        printf("open failed \n");
                                        free(file_name);
                                        if (chunk_start != NULL)
                                        {
                                            free(chunk_start);
                                            chunk_start = NULL;
                                        }
                                        return -1;
                                    }
                                }
#endif
                            }
*/
                            char *cont = NULL;
                            start = NULL;
                            start = strstr(chunk_start + c->offset, "--");
                            cont = strstr(chunk_start + c->offset, "Content-Type:");
                            if ((start != NULL) && (cont != NULL) && strip_header == 1)
                                //&& ((start = strstr(start, "\r\n\r\n")) != NULL)
                                //&& ((cont = strstr(c->file.mmap.start + c->offset, "Content-Type:")) != NULL))
                            {
                                start = strstr(cont, "\r\n\r\n");
                                if (start != NULL)
                                {
                                    start += strlen("\r\n\r\n");
                                    
                                    printf("trip header %d\n", strip_header);
                                    c->offset += start - chunk_start;
                                }
                                else
                                {
                                    start = chunk_start + c->offset;
                                }
                            }
                            else
                            {
                                start = chunk_start + c->offset;
                            }
                            
                            //end = strstr(c->file.mmap.start + c->file.length - 54, "\r\n--------------------");
                            if (1)
                            {
                                end = strstr(chunk_start + c->file.length - boundary_length + 1, "--");
                                if (end == NULL)
                                {
                                    end = chunk_start + c->file.length;
                                }
                                else
                                {
                                    char * dectet = NULL;
                                    dectet = end -1;
                                    //end += strlen("\r\n");

                                	while (((*dectet == '\r') && (*(dectet + 2) =='-')) 
                                        || ((*dectet == '\n') && (*(dectet + 1) =='-'))
                                        || (*dectet == '-') )
                                   {
                                        end--;
                                        dectet--;
                                   } 
                                }
                            }

                            length = end - start;

                                //if ((r = write(file_fd, c->file.mmap.start + c->offset, c->file.length - c->offset)) < 0) {
				printf("try write length %d~~~~~~~~~\n", length);

				if ((r = write(file_fd, start, length)) <= 0) {
                                //if ((r = fwrite(start, 1, length, file_fd)) <= 0) {
					switch(errno) {
					case ENOSPC:
						printf("error: %s", strerror(errno));
						con->http_status = 507;
                                            if (chunk_start != NULL)
                                            {
                                                free(chunk_start);
                                                chunk_start = NULL;
                                            }
						break;
					default:
						printf("error: %s", strerror(errno));
						//con->http_status = 403;
                                            if (chunk_start != NULL)
                                            {
                                                free(chunk_start);
                                                chunk_start = NULL;
                                            }
						break;
					}
                                }else
                                {
                                    whlength += r;
                                }

                                printf("write failed, %d\n", r);
                            printf("write Done-------------\n" );
                            if (chunk_start != NULL)
                            {
                                free(chunk_start);
                                chunk_start = NULL;
                            }
				break;
                        case MEM_CHUNK:
                            printf("MEM_CHUNK chunk -----------------\n");
                            /*if ((!strcasecmp(file_name, TEMP_PATH"/ringtone.mp3")))
                            {
#ifndef BUILD_RECOVER
                                if ((start = strstr(c->mem->ptr + c->offset, "filename=\"")) != NULL)
                                {
                                    char * tempval = NULL;
                                    close(file_fd);
                                    free(file_name);
                                    end = strstr(start, "\"\r\n");
                                    start += strlen("filename=");
                                    tempval = start;
                                    if ((start = strrchr(start, '\\')) == NULL)
                                    {
                                        start = strrchr(tempval, '\/');
                                    }
                                    if ((start > end) || start == NULL)
                                    {
                                        start = tempval;
                                    }
                                    start++;
                                    length = strstr(start, "\"") - start;
                                    tempval = strndup( start, length );
                                    file_name = malloc( strlen(RINGTONE_PATH) + strlen(tempval) + 2 );
                                    sprintf(file_name, "%s/%s", RINGTONE_PATH, tempval);
                                    printf("resctuct file name to %s----------\n", file_name);
                                    //file_fd = fopen(file_name, "w+");
                                    file_fd = open(file_name, O_WRONLY);
                                    free(tempval);
                                }
#endif
                            }
                            */
                            if ((strip_header == 1) && ((start = strstr(c->mem->ptr + c->offset, "\r\n\r\n")) != NULL) 
                                 && (strstr(c->mem->ptr + c->offset, "Content-Type:") != NULL))

                            {
                                start += strlen("\r\n\r\n");
                            }
                            else
                            {
                                start = c->mem->ptr + c->offset;
                            }
                            //end = strstr(c->mem->ptr + c->mem->used - 55, "\r\n--------------------");
                            if (1)
                            {
                                end = strstr(c->mem->ptr + c->mem->used - boundary_length, "--");
                                if (end == NULL)
                                {
                                    end = c->mem->ptr + c->mem->used - 1;
                                }
                                else
                                {
                                    char * dectet = NULL;
                                    dectet = end -1;
                                    //end += strlen("\r\n");

                                	while (((*dectet == '\r') && (*(dectet + 2) =='-')) 
                                        || ((*dectet == '\n') && (*(dectet + 1) =='-'))
                                        || (*dectet == '-') )
                                   {
                                        end--;
                                        dectet--;
                                   } 
                                }
                            }
                            length = end - start;
                            printf("try write mem length %d~~~~~~~~~\n", length);

                            r = c->mem->used - c->offset - 1;
                            printf("start is %d/%d\n", strlen(start), length);
                                //if ((r = write(file_fd, c->mem->ptr + c->offset, c->mem->used - c->offset - 1)) < 0) {
                                //if ((fwrite(start, 1, length, file_fd)) <= 0) {
                                if ((write(file_fd, start, length)) <= 0) {
				//if ((write(file_fd, start, length)) <= 0) {
                                        switch(errno) {
					case ENOSPC:
						printf("error: %s", strerror(errno));
						con->http_status = 507;

						break;
					default:
						printf("error: %s", strerror(errno));
						//con->http_status = 403;
						break;
					}
                                }else
                                {
                                    whlength += r;
                                }
                                printf("write mem Done-------------\n" );
				break;
			case UNUSED_CHUNK:
				break;
			}

			if (r > 0) {
				c->offset += r;
				cq->bytes_out += r;
			} else {
				break;
			}
			chunkqueue_remove_finished_chunks(cq);
		}

            close(file_fd);
	}
        
    resType = msg_get_header(m, "format");

    if((resType != NULL) && !strcasecmp(resType, "json"))
    {
        jsonCallback = msg_get_header( m, "jsoncallback" );    

        if(jsonCallback != NULL)
        {
            tmp = malloc((strlen(jsonCallback) + 64) * sizeof(char));

            if(tmp != NULL)
            {
                sprintf(tmp, "%s(%s)", jsonCallback, "{\"res\" : \"success\", \"msg\" : \"upload done\"}");
                buffer_append_string(b, tmp);
                free(tmp);
            }
        }
        else
        {
            buffer_append_string(b, "{\"res\" : \"success\", \"msg\" : \"upload done\"}");
        }

        if(file_name != NULL){
            free(file_name);
        }
    }
    else
    {
        buffer_append_string(b, "Response=Success\r\nMessage=Upload Done\r\n");

        if(file_name != NULL){
            if( !strcasecmp(file_name, FIFO_PATH) == 0 )
            {
                unsigned int size;
                FILE* fp = fopen( file_name, "rb" );
                fseek( fp, 0L, SEEK_END );
                size=ftell(fp);
                close(fp);
                //buffer_append_string(b, "filename !=null\r\n");

                tmp = malloc(32);
                memset(tmp, 0, sizeof(tmp));
                sprintf(tmp, "Size=%d", size);
                buffer_append_string(b, tmp);
                free(tmp);
            }
            free(file_name);
        }
    }

        printf("~~~~~~~~~~~~~~~~~upload done~~hah~~~~%d~~~~~\n", whlength);
    return 0;
}

#ifndef BUILD_RECOVER

int isReadable(int sd,int * error,int timeOut)
{ 
    // milliseconds
    fd_set socketReadSet;
    FD_ZERO(&socketReadSet);
    FD_SET(sd,&socketReadSet);
    struct timeval tv;
    
    if (timeOut)
    {
        tv.tv_sec  = timeOut / 1000;
        tv.tv_usec = (timeOut % 1000) * 1000;
    }
    else
    {
        tv.tv_sec  = 0;
        tv.tv_usec = 0;
    } // if

    
    if (select(sd+1,&socketReadSet,0,0,&tv) == -1) 
    {
        *error = 1;
        return 0;
    } // if
    *error = 0;
    
    return FD_ISSET(sd,&socketReadSet) != 0;
} /* isReadable */

#endif

static int process_message(server *srv, connection *con, buffer *b, const struct message *m)
{
    char action[80] = "";
    char res[256] = "";
    char *temp = NULL;
    const char *resType = NULL;

    memset(action, 0, sizeof(action));
    temp = msg_get_header(m, "Action");

    if ( temp == NULL )
    {
        resType = msg_get_header(m, "format");
        if ( (resType != NULL) && !strcasecmp( resType, "json" ) )
        {
             response_header_overwrite(srv, con, CONST_STR_LEN("Content-Type"), 
                CONST_STR_LEN("application/x-javascript; charset=utf-8"));
        
            const char * jsonCallback = msg_get_header( m, "jsoncallback" );

            if ( jsonCallback != NULL )
            {
                temp = malloc( 128 + strlen( jsonCallback ) );
                snprintf( temp, 128 + strlen( jsonCallback ),
                    "%s(%s)", jsonCallback, "{\"res\": \"error\", \"msg\" : \"command not found\"}" );
            }
            else
            {
                temp = malloc( 128 );
                snprintf( temp, 128, "%s", "{\"res\": \"error\", \"msg\" : \"command not found\"}" );
            }
            
            buffer_append_string( b, temp );
            free(temp);
        }
        else
        {
            sprintf(res, "Response=Error\r\nMessage=Command Not Found\r\n");
        }
        buffer_append_string(b, res);
        return -1;
    }
    
    strncpy(action, temp, sizeof(action) - 1);

    if (!strcasecmp(action, "login")) {
        if (authenticate(m)) {
            resType = msg_get_header(m, "format");
            if ( (resType != NULL) && !strcasecmp( resType, "json" ) )
            {
                 response_header_overwrite(srv, con, CONST_STR_LEN("Content-Type"), 
                    CONST_STR_LEN("application/x-javascript; charset=utf-8"));
            
                const char * jsonCallback = msg_get_header( m, "jsoncallback" );

                if ( jsonCallback != NULL )
                {
                    temp = malloc( 128 + strlen( jsonCallback ) );
                    snprintf( temp, 128 + strlen( jsonCallback ),
                        "%s(%s)", jsonCallback, "{\"res\": \"error\", \"msg\" : \"authentication failed\"}" );
                }
                else
                {
                    temp = malloc( 128 );
                    snprintf( temp, 128, "%s", "{\"res\": \"error\", \"msg\" : \"authentication failed\"}" );
                }
                
                buffer_append_string( b, temp );
                free(temp);
            }
            else
            {
                buffer_append_string(b,
                    "Response=Error\r\n"
                    "Message=Authentication failed\r\n");
            }
            return -1;
        } else {
            authenticate_success_response(srv, con, b, m );
        }
    } else if (!strcasecmp(action, "product")) {
        handle_product( srv, con, b, m );
    } else if (!strcasecmp(action, "productinfo")) {
        handle_productinfo( srv, con, b, m );
#ifndef BUILD_RECOVER
    } else if( !strcasecmp(action, "coloreExist")) {
        handle_coloreExist(b);
    } else if (!strcasecmp(action, "vendor")) {
        handle_vendor( srv, con, b, m );
#else
    } else if (!strcasecmp(action, "recoverversion")) {
            handle_recoverversion(b);
#endif
    } else if (valid_connection(con)) {
#ifndef BUILD_RECOVER
        if (protected_command_find(command_protect, action))
        {
            sprintf(res, "Response=Error\r\nMessage=Command Not Found\r\n");
            buffer_append_string(b, res);
            return -1;
        }
#endif

        if (!strcasecmp(action, "get")) {
            handle_get(b, m);
        } else if (!strcasecmp(action, "getnetwork")) {
            handle_getnetwork(b);
        } else if (!strcasecmp(action, "putnetwork")) {
            handle_putnetwork(b, m);
        } else if (!strcasecmp(action, "hardware")) {
            handle_hardware( srv, con, b, m );
        } else if (!strcasecmp(action, "reboot")) {
            handle_reboot(b);
        } else if (!strcasecmp(action, "ping")) {
            sprintf(res, "Response=Pong\r\n");
            buffer_append_string(b, res);
        } 
#ifdef BUILD_RECOVER
        else if (!strcasecmp(action, "startrecover")) {
            handle_startrecover(b,m);
        } else if (!strcasecmp(action, "recoverresult")) {
            handle_recoverresult(b);
        } else if (!strcasecmp(action, "recoverreset")) {
            handle_recoverreset(b);
        }
#else
        else if (!strcasecmp(action, "put")) {
            handle_put(b, m);
        }else if (!strcasecmp(action, "applypvalue")) {
            handle_applypvalue(b);
        }else if (!strcasecmp(action, "applypvaluersps")) {
            handle_applyresponse(b);
        }else if (!strcasecmp(action, "needapply")) {
            handle_checkneedapplyp(b);
        }else if (!strcasecmp(action, "getcallfunc")) {
            handle_getcallfunc(b);
        }else if (!strcasecmp(action, "putcallfunc")) {
            handle_putcallfunc(b, m);
        } else if (!strcasecmp(action, "vpnenable")) {
            handle_vpnenable(b);
        }else if (!strcasecmp(action, "phonebookaddr")){
            handle_setPhonebookAddr(srv, con, b, m);
        }else if (!strcasecmp(action, "downloadphonebook")){
            handle_importPhonebook(srv, con, b, m);
        }else if (!strcasecmp(action, "upgrade")){
            handle_upgrade(b, m);
        }else if (!strcasecmp(action, "phoneStatus")) {
            handle_getPhoneStatus(b, m);
        }else if (!strcasecmp(action, "gmiVersion")) {
            handle_getGmiVersion(srv, con, b, m);
        }else if (!strcasecmp(action, "launchservice")){
            handle_launchservice(srv, con, b, m);
        }else if (!strcasecmp(action, "closeservice")){
            handle_closeservice(srv, con, b, m);
        }else if (!strcasecmp(action, "closecurservice")){
            handle_closecurservice(srv, con, b, m);
        }else if (!strcasecmp(action, "grabwindow")){
            handle_grabwindow(srv, con, b, m);
        }else if (!strcasecmp(action, "touchscreen")){
            handle_touchscreen(srv, con, b, m);
        }else if(!strcasecmp(action, "swipescreen")){
            handle_swipeScreen(srv, con, b, m);
        }else if (!strcasecmp(action, "getmessage")){
            handle_getmessage(srv, con, b, m);
        }else if (!strcasecmp(action, "setnewmessage")){
            handle_setnewmessage(srv, con, b, m);
        }else if (!strcasecmp(action, "senddraftmessage")){
            handle_senddraftmessage(srv, con, b, m);
        }else if (!strcasecmp(action, "removemessage")){
            handle_removemessage(srv, con, b, m);
        }else if (!strcasecmp(action, "savemessage")){
            handle_savemessage(b, m);
        }else if (!strcasecmp(action, "getlastcall")){
            handle_getlastcall(srv, con, b, m);
        }else if (!strcasecmp(action, "removecall")){
            handle_removecall(srv, con, b, m);
        }else if (!strcasecmp(action, "savecallhistory")){
            handle_savecallhistory(b, m);
        }else if (!strcasecmp(action, "proxyupdated")) {
            dbus_send_proxyupdated();
        } else if (!strcasecmp(action, "factset")) {
            handle_factset(b,m);
        } else if (!strcasecmp(action, "backupcfg")) {
            handle_backupcfg(b);
        } else if (!strcasecmp(action, "restorecfg")) {
            handle_restorecfg(b);
        } else if (!strcasecmp(action, "logoff")) {
            handle_logoff(b);
        } else if (!strcasecmp(action, "status")) {
            handle_status(srv,con,b, m);
        } else if (!strcasecmp(action, "accountStatus")) {
            handle_status(srv,con,b, m);
        } else if (!strcasecmp(action, "fxoexist")) {
            handle_fxoexist(b);
        } else if (!strcasecmp(action, "sqlitesetting")) {
            handle_sqlitesetting(b, m);
        } else if( !strcasecmp(action, "getcolore")) {
            handle_getcolore(b);
        } else if( !strcasecmp(action, "putcolore")) {
            handle_putcolore(b, m);
        } else if( !strcasecmp(action, "changepwd")) {
            handle_changepwd(b, m);
        } else if (!strcasecmp(action, "chgcolorepwdrsps")) {
            handle_chgcolorepwdrsps(b);
        } else if (!strcasecmp(action, "fxostatus")) {
            handle_fxostatus(b);
        } else if (!strcasecmp(action, "uptime")) {
            handle_uptime( srv, con, b, m );
        } else if (!strcasecmp(action, "androidver")) {
            handle_androidverion( b );
        } else if (!strcasecmp(action, "network")) {
            handle_network(srv, con, b, m);
        } else if (!strcasecmp(action, "pn")) {
            handle_pn( srv, con, b, m );
        } else if (!strcasecmp(action, "sn")) {
            handle_sn( srv, con, b, m );
        } else if (!strcasecmp(action, "initupstatus")) {
            handle_initupstatus(b);
        } else if (!strcasecmp(action, "provisioninit")) {
            handle_provisioninit(b);
        } else if (!strcasecmp(action, "upgradenow")) {
            handle_upgradenow(b);
        } else if (!strcasecmp(action, "getcountry")) {
            handle_getcountry(b);
        }else if (!strcasecmp(action, "setsyslogd")) {
            handle_setsyslogd(b);
        } else if (!strcasecmp(action, "getlanguages")) {
            handle_getlanguages(b);
        } else if (!strcasecmp(action, "execcmd")) {
            handle_exec_command(b, m);
        } else if (!strcasecmp(action, "clearlogcat")) {
            handle_clearlogcat(b);
        } else if (!strcasecmp(action, "getlogcat")) {
            handle_getlogcat(b, m);
        } else if (!strcasecmp(action, "savephbk")) {
            handle_savephbk(b, m);
        } else if (!strcasecmp(action, "getphbkparam")) {
            handle_getparams(b, CONF_PHBKDOWNLOAD);
        } else if (!strcasecmp(action, "putportphbk")) {
            handle_putportphbk(b, m);
        } else if (!strcasecmp(action, "putdownphbk")) {
            handle_putdownphbk(b, m);
        } else if (!strcasecmp(action, "portphbkresponse")) {
            handle_portphbkresponse(b, m);
        } else if (!strcasecmp(action, "phbkresponse")) {
            handle_phbkresponse(b, m);
        } else if (!strcasecmp(action, "putlanguage")) {
            handle_putlanguage(b, m);
        } else if (!strcasecmp(action, "capture")) {
            handle_capture(b, m);
        } else if (!strcasecmp(action, "cfupdated")) {
            handle_cfupdated(b);
        } else if (!strcasecmp(action, "saveconf")) {
            handle_saveconf(b);
        } else if (!strcasecmp(action, "gettimezone")) {
            handle_gettimezone(b);
        } else if (!strcasecmp(action, "savetimeset")) {
            handle_savetimeset(b, m);
        } else if (!strcasecmp(action, "autoanswer")) {
            handle_autoanswer(b, m);
        } else if (!strcasecmp(action, "vbupdated")) {
            handle_vbupdated(b, m);
        } else if (!strcasecmp(action, "callforward")) {
            handle_callforward(b, m);
        } else if (!strcasecmp(action, "endcall")) {
            handle_endcall(srv, con, b, m);
        } else if (!strcasecmp(action, "lineStatus")) {
            handle_getLineStatus(srv, con, b, m);
        } else if (!strcasecmp(action, "originatecall")) {
            handle_originatecall(srv, con, b, m);
        } else if (!strcasecmp(action, "getpageitems")) {   //getpageitems
            handle_getPageItems(b);
        } else if (!strcasecmp(action, "tonelist")) {
            handle_tonelist(b);
		} else if (!strcasecmp(action, "tonelist1")) {
			handle_tonelist1(b);
        }else if (!strcasecmp(action, "gettonename")) {
            handle_gettonename(b, m);
        } else if (!strcasecmp(action, "deletetone")) {
            handle_deltone(b, m);
        } else if (!strcasecmp(action, "sysconfig")) {
            //handle_sysconfig(b, m);
        } else if (!strcasecmp(action, "getapldacct")) {
	    	handle_getapldacct(b, m);
        } else if (!strcasecmp(action, "getblf")) {
            handle_getblf(b, m);
        } else if (!strcasecmp(action, "getmpkinfo")) {
            handle_getmpkinfo(b, m);
        } else if (!strcasecmp(action, "getmpkexist")) {
            handle_getmpkexist(b, m);
        } else if (!strcasecmp(action, "putblf")) {
            handle_putblf(b, m);
        } else if (!strcasecmp(action, "putblfext")) {
            handle_putblfext(b, m);
        } else if (!strcasecmp(action, "putmpkorder")) {
            handle_putmpkorder(b, m);
        } else if (!strcasecmp(action, "gethwservers")) {
            handle_gethwservers(b);
        } else if (!strcasecmp(action, "puthwservers")) {
            handle_puthwservers(b, m);
        } else if (!strcasecmp(action, "putmpk")) {
            handle_putmpk(b, m);
        /*} else if (!strcasecmp(action, "putblfimage")) {
            handle_putblfimage(b, m);*/
        } else if (!strcasecmp(action, "putmpkext")) {
			handle_putmpkext(b, m);
		} else if (!strcasecmp(action, "getgroup")) {
            handle_getgroup(srv, con, b, m);
        } else if (!strcasecmp(action, "getcontact")) {
            handle_getcontact(srv, con, b, m);
        } else if (!strcasecmp(action, "getgroupcount")) {
            handle_getgroupcount(srv, con, b, m);
        } else if (!strcasecmp(action, "getcontactcount")) {
            handle_getcontactcount(srv, con, b, m);
        } else if (!strcasecmp(action, "setgroup")) {
            handle_setgroup(srv, con, b, m);
        } else if (!strcasecmp(action, "setcontact")) {
            handle_setcontact(srv, con, b, m);
        } else if (!strcasecmp(action, "removecontact")) {
            handle_removecontact(srv, con, b, m);
        } else if (!strcasecmp(action, "cleargroup")) {
            handle_cleargroup(srv, con, b, m);
        } else if (!strcasecmp(action, "removegroup")) {
            handle_removegroup(srv, con, b, m);
        } else if (!strcasecmp(action, "movetodefault")) {
            handle_movetodefault(srv, con, b, m);
        } else if (!strcasecmp(action, "setheadset")) {
			handle_setheadsettype(b, m);
        } else if (!strcasecmp(action, "converaudio")) {
            handle_converaudio(b, m);
        }
#endif
        else {
            resType = msg_get_header(m, "format");
            if ( (resType != NULL) && !strcasecmp( resType, "json" ) )
            {
                temp = "{\"res\": \"error\", \"msg\": \"command not found\"}";
                temp = build_JSON_res( srv, con, m, temp );
                buffer_append_string( b, temp );
                free(temp);
            }
            else
            {
                sprintf(res, "Response=Error\r\nMessage=Command Not Found\r\n");
                buffer_append_string(b, res);
            }
            return -1;
        }

    	return 0;
    } else {
            resType = msg_get_header(m, "format");
            if ( (resType != NULL) && !strcasecmp( resType, "json" ) )
            {
                temp = "{\"res\": \"error\", \"msg\": \"authentication required\"}";
                temp = build_JSON_res( srv, con, m, temp );
                buffer_append_string( b, temp );
                free(temp);
            }
            else
            {
        	buffer_append_string(b,
        		"Response=Error\r\n"
        		"Message=Authentication Required\r\n");
            }
    	return -1;
    }

    return -1;
}

static connection *connections_get_new_connection(server *srv) {
	connections *conns = srv->conns;
	size_t i;

	if (conns->size == 0) {
		conns->size = 128;
		conns->ptr = NULL;
		conns->ptr = malloc(sizeof(*conns->ptr) * conns->size);
		for (i = 0; i < conns->size; i++) {
			conns->ptr[i] = connection_init(srv);
		}
	} else if (conns->size == conns->used) {
		conns->size += 128;
		conns->ptr = realloc(conns->ptr, sizeof(*conns->ptr) * conns->size);

		for (i = conns->used; i < conns->size; i++) {
			conns->ptr[i] = connection_init(srv);
		}
	}

	connection_reset(srv, conns->ptr[conns->used]);
#if 0
	fprintf(stderr, "%s.%d: add: ", __FILE__, __LINE__);
	for (i = 0; i < conns->used + 1; i++) {
		fprintf(stderr, "%d ", conns->ptr[i]->fd);
	}
	fprintf(stderr, "\n");
#endif

	conns->ptr[conns->used]->ndx = conns->used;
	return conns->ptr[conns->used++];
}

static int connection_del(server *srv, connection *con) {
	size_t i;
	connections *conns = srv->conns;
	connection *temp;

	if (con == NULL) return -1;

	if (-1 == con->ndx) return -1;

	i = con->ndx;

	/* not last element */

	if (i != conns->used - 1) {
		temp = conns->ptr[i];
		conns->ptr[i] = conns->ptr[conns->used - 1];
		conns->ptr[conns->used - 1] = temp;

		conns->ptr[i]->ndx = i;
		conns->ptr[conns->used - 1]->ndx = -1;
	}

	conns->used--;

	con->ndx = -1;
#if 0
	fprintf(stderr, "%s.%d: del: (%d)", __FILE__, __LINE__, conns->used);
	for (i = 0; i < conns->used; i++) {
		fprintf(stderr, "%d ", conns->ptr[i]->fd);
	}
	fprintf(stderr, "\n");
#endif
	return 0;
}

int connection_close(server *srv, connection *con) {
#ifdef USE_OPENSSL
	server_socket *srv_sock = con->srv_socket;
#endif

#ifdef USE_OPENSSL
	if (srv_sock->is_ssl) {
		if (con->ssl) SSL_free(con->ssl);
		con->ssl = NULL;
	}
#endif

	fdevent_event_del(srv->ev, &(con->fde_ndx), con->fd);
	fdevent_unregister(srv->ev, con->fd);
#ifdef __WIN32
	if (closesocket(con->fd)) {
		log_error_write(srv, __FILE__, __LINE__, "sds",
				"(warning) close:", con->fd, strerror(errno));
	}
#else
	if (close(con->fd)) {
		log_error_write(srv, __FILE__, __LINE__, "sds",
				"(warning) close:", con->fd, strerror(errno));
	}
#endif

	srv->cur_fds--;
#if 0
	log_error_write(srv, __FILE__, __LINE__, "sd",
			"closed()", con->fd);
#endif

	connection_del(srv, con);
	connection_set_state(srv, con, CON_STATE_CONNECT);

	return 0;
}

#if 0
static void dump_packet(const unsigned char *data, size_t len) {
	size_t i, j;

	if (len == 0) return;

	for (i = 0; i < len; i++) {
		if (i % 16 == 0) fprintf(stderr, "  ");

		fprintf(stderr, "%02x ", data[i]);

		if ((i + 1) % 16 == 0) {
			fprintf(stderr, "  ");
			for (j = 0; j <= i % 16; j++) {
				unsigned char c;

				if (i-15+j >= len) break;

				c = data[i-15+j];

				fprintf(stderr, "%c", c > 32 && c < 128 ? c : '.');
			}

			fprintf(stderr, "\n");
		}
	}

	if (len % 16 != 0) {
		for (j = i % 16; j < 16; j++) {
			fprintf(stderr, "   ");
		}

		fprintf(stderr, "  ");
		for (j = i & ~0xf; j < len; j++) {
			unsigned char c;

			c = data[j];
			fprintf(stderr, "%c", c > 32 && c < 128 ? c : '.');
		}
		fprintf(stderr, "\n");
	}
}
#endif

static int connection_handle_read_ssl(server *srv, connection *con) {
#ifdef USE_OPENSSL
	int r, ssl_err, len;
	buffer *b = NULL;

	if (!con->conf.is_ssl) return -1;

	/* don't resize the buffer if we were in SSL_ERROR_WANT_* */

	do {
		if (!con->ssl_error_want_reuse_buffer) {
			b = buffer_init();
			buffer_prepare_copy(b, SSL_pending(con->ssl) + (16 * 1024)); /* the pending bytes + 16kb */

			/* overwrite everything with 0 */
			memset(b->ptr, 0, b->size);
		} else {
			b = con->ssl_error_want_reuse_buffer;
		}

		len = SSL_read(con->ssl, b->ptr, b->size - 1);
		con->ssl_error_want_reuse_buffer = NULL; /* reuse it only once */

		if (len > 0) {
			b->used = len;
			b->ptr[b->used++] = '\0';

		       	/* we move the buffer to the chunk-queue, no need to free it */

			chunkqueue_append_buffer_weak(con->read_queue, b);
			con->bytes_read += len;
			b = NULL;
		}
	} while (len > 0);


	if (len < 0) {
		switch ((r = SSL_get_error(con->ssl, len))) {
		case SSL_ERROR_WANT_READ:
		case SSL_ERROR_WANT_WRITE:
			con->is_readable = 0;
			con->ssl_error_want_reuse_buffer = b;

			b = NULL;

			/* we have to steal the buffer from the queue-queue */
			return 0;
		case SSL_ERROR_SYSCALL:
			/**
			 * man SSL_get_error()
			 *
			 * SSL_ERROR_SYSCALL
			 *   Some I/O error occurred.  The OpenSSL error queue may contain more
			 *   information on the error.  If the error queue is empty (i.e.
			 *   ERR_get_error() returns 0), ret can be used to find out more about
			 *   the error: If ret == 0, an EOF was observed that violates the
			 *   protocol.  If ret == -1, the underlying BIO reported an I/O error
			 *   (for socket I/O on Unix systems, consult errno for details).
			 *
			 */
			while((ssl_err = ERR_get_error())) {
				/* get all errors from the error-queue */
				log_error_write(srv, __FILE__, __LINE__, "sds", "SSL:",
						r, ERR_error_string(ssl_err, NULL));
			}

			switch(errno) {
			default:
				log_error_write(srv, __FILE__, __LINE__, "sddds", "SSL:",
						len, r, errno,
						strerror(errno));
				break;
			}

			break;
		case SSL_ERROR_ZERO_RETURN:
			/* clean shutdown on the remote side */

			if (r == 0) {
				/* FIXME: later */
			}

			/* fall thourgh */
		default:
			while((ssl_err = ERR_get_error())) {
				/* get all errors from the error-queue */
				log_error_write(srv, __FILE__, __LINE__, "sds", "SSL:",
						r, ERR_error_string(ssl_err, NULL));
			}
			break;
		}

		connection_set_state(srv, con, CON_STATE_ERROR);

		buffer_free(b);

		return -1;
	} else if (len == 0) {
		con->is_readable = 0;
		/* the other end close the connection -> KEEP-ALIVE */

		/* pipelining */
		buffer_free(b);

		return -2;
	}

	return 0;
#else
	return -1;
#endif
}

static int connection_handle_read(server *srv, connection *con) {
	int len;
	buffer *b;
	int toread;

	if (con->conf.is_ssl) {
		return connection_handle_read_ssl(srv, con);
	}

#if defined(__WIN32)
	b = chunkqueue_get_append_buffer(con->read_queue);
	buffer_prepare_copy(b, 4 * 1024);
	len = recv(con->fd, b->ptr, b->size - 1, 0);
#else
	if (ioctl(con->fd, FIONREAD, &toread)) {
		log_error_write(srv, __FILE__, __LINE__, "sd",
				"unexpected end-of-file:",
				con->fd);
		return -1;
	}
	b = chunkqueue_get_append_buffer(con->read_queue);
	buffer_prepare_copy(b, toread + 1);

	len = read(con->fd, b->ptr, b->size - 1);
#endif

	if (len < 0) {
		con->is_readable = 0;

		if (errno == EAGAIN) return 0;
		if (errno == EINTR) {
			/* we have been interrupted before we could read */
			con->is_readable = 1;
			return 0;
		}

		if (errno != ECONNRESET) {
			/* expected for keep-alive */
			log_error_write(srv, __FILE__, __LINE__, "ssd", "connection closed - read failed: ", strerror(errno), errno);
		}

		connection_set_state(srv, con, CON_STATE_ERROR);

		return -1;
	} else if (len == 0) {
		con->is_readable = 0;
		/* the other end close the connection -> KEEP-ALIVE */

		/* pipelining */

		return -2;
	} else if ((size_t)len < b->size - 1) {
		/* we got less then expected, wait for the next fd-event */

		con->is_readable = 0;
	}

	b->used = len;
	b->ptr[b->used++] = '\0';

	con->bytes_read += len;
#if 0
	dump_packet(b->ptr, len);
#endif

	return 0;
}

static int connection_handle_write_prepare(server *srv, connection *con) {
        int i;
        struct message m;
        
	if (con->mode == DIRECT) {
		/* static files */
		switch(con->request.http_method) {
		case HTTP_METHOD_GET:
		case HTTP_METHOD_POST:
		case HTTP_METHOD_HEAD:
		case HTTP_METHOD_PUT:
		case HTTP_METHOD_MKCOL:
		case HTTP_METHOD_DELETE:
		case HTTP_METHOD_COPY:
		case HTTP_METHOD_MOVE:
		case HTTP_METHOD_PROPFIND:
		case HTTP_METHOD_PROPPATCH:
		case HTTP_METHOD_LOCK:
		case HTTP_METHOD_UNLOCK:
			break;
		case HTTP_METHOD_OPTIONS:
			/*
			 * 400 is coming from the request-parser BEFORE uri.path is set
			 * 403 is from the response handler when noone else catched it
			 *
			 * */
			if ((!con->http_status || con->http_status == 200) && con->uri.path->used &&
			    con->uri.path->ptr[0] != '*') {
				response_header_insert(srv, con, CONST_STR_LEN("Allow"), CONST_STR_LEN("OPTIONS, GET, HEAD, POST"));

				con->response.transfer_encoding &= ~HTTP_TRANSFER_ENCODING_CHUNKED;
				con->parsed_response &= ~HTTP_CONTENT_LENGTH;

				con->http_status = 200;
				con->file_finished = 1;

				chunkqueue_reset(con->write_queue);
			}
			break;
		default:
			switch(con->http_status) {
			case 400: /* bad request */
			case 414: /* overload request header */
			case 505: /* unknown protocol */
			case 207: /* this was webdav */
				break;
			default:
				con->http_status = 501;
				break;
			}
			break;
		}
	}

	if (con->http_status == 0) {
		con->http_status = 403;
	}

	switch(con->http_status) {
	case 404:
		if (!strcasecmp(con->physical.rel_path->ptr, "/manager")) {
			con->http_status = 200;
			if (con->mode != DIRECT) break;

			con->file_finished = 0;

			//struct message m = { 0 };
			m.hdrcount = 0;
                    for (i = 0; i < MAX_MANHEADERS; i++)
                    {
                        m.headers[0] = NULL;
                    }
                    
			//printf("before judeg query\n");
			if (con->uri.query->ptr != NULL) {
				m.headers[m.hdrcount++] = strtok(con->uri.query->ptr, "&");
				//printf("con->uri.query->ptr is %s\n", con->uri.query->ptr);
				while (m.hdrcount < (MAX_MANHEADERS - 1) &&
					(m.headers[m.hdrcount] = strtok(NULL, "&"))) {
					//printf("con->uri.query->ptr is %s\n", con->uri.query->ptr);
					m.hdrcount++;
				}
			}

			buffer_reset(con->physical.path);

			if (!con->file_finished) {
				buffer *b;

				con->file_finished = 1;
				b = chunkqueue_get_append_buffer(con->write_queue);

				response_header_overwrite(srv, con, CONST_STR_LEN("Content-Type"), CONST_STR_LEN("text/plain"));
				response_header_overwrite(srv, con, CONST_STR_LEN("Cache-Control"), CONST_STR_LEN("no-cache"));
				response_header_overwrite(srv, con, CONST_STR_LEN("Pragma"), CONST_STR_LEN("no-cache"));
				process_message(srv, con, b, &m);
			}
			/* fall through */
			break;
		}
		else if (!strcasecmp(con->physical.rel_path->ptr, "/upload")) {
			printf("in upload--------------------\n");
			con->http_status = 200;
			if (con->mode != DIRECT) break;

			con->file_finished = 0;

			m.hdrcount = 0;
			for (i = 0; i < MAX_MANHEADERS; i++)
			{
			    m.headers[0] = NULL;
			}

			//printf("before judeg query\n");
			if (con->uri.query->ptr != NULL) {
				m.headers[m.hdrcount++] = strtok(con->uri.query->ptr, "&");
				//printf("con->uri.query->ptr is %s\n", con->uri.query->ptr);
				while (m.hdrcount < (MAX_MANHEADERS - 1) &&
					(m.headers[m.hdrcount] = strtok(NULL, "&"))) {
					//printf("con->uri.query->ptr is %s\n", con->uri.query->ptr);
					m.hdrcount++;
				}
			}

			buffer_reset(con->physical.path);

			if (!con->file_finished) {
                            buffer *b;

				con->file_finished = 1;
				b = chunkqueue_get_append_buffer(con->write_queue);
                            response_header_overwrite(srv, con, CONST_STR_LEN("Content-Type"), CONST_STR_LEN("text/plain"));
				response_header_overwrite(srv, con, CONST_STR_LEN("Cache-Control"), CONST_STR_LEN("no-cache"));
				response_header_overwrite(srv, con, CONST_STR_LEN("Pragma"), CONST_STR_LEN("no-cache"));
                                response_header_overwrite(srv, con, CONST_STR_LEN("Access-Control-Allow-Origin"), CONST_STR_LEN("*"));
				process_upload(srv, con, b, &m);
			}
			/* fall through */
			break;
		}

	case 400: /* class: header + custom body */
	case 401:
	case 403:
	case 408:
	case 409:
	case 411:
	case 416:
	case 423:
	case 500:
	case 501:
	case 503:
	case 505:
		if (con->mode != DIRECT) break;

		con->file_finished = 0;

		buffer_reset(con->physical.path);

		/* try to send static errorfile */
		if (!buffer_is_empty(con->conf.errorfile_prefix)) {
			stat_cache_entry *sce = NULL;

			buffer_copy_string_buffer(con->physical.path, con->conf.errorfile_prefix);
			buffer_append_string(con->physical.path, get_http_status_body_name(con->http_status));

			if (HANDLER_ERROR != stat_cache_get_entry(srv, con, con->physical.path, &sce)) {
				con->file_finished = 1;

				http_chunk_append_file(srv, con, con->physical.path, 0, sce->st.st_size);
				response_header_overwrite(srv, con, CONST_STR_LEN("Content-Type"), CONST_BUF_LEN(sce->content_type));
			}
		}

		if (!con->file_finished) {
			buffer *b;

			buffer_reset(con->physical.path);

			con->file_finished = 1;
			b = chunkqueue_get_append_buffer(con->write_queue);

			/* build default error-page */
			buffer_copy_string(b,
					   "<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>\n"
					   "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\"\n"
					   "         \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n"
					   "<html xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"en\" lang=\"en\">\n"
					   " <head>\n"
					   "  <title>");
			buffer_append_long(b, con->http_status);
			buffer_append_string(b, " - ");
			buffer_append_string(b, get_http_status_name(con->http_status));

			buffer_append_string(b,
					     "</title>\n"
					     " </head>\n"
					     " <body>\n"
					     "  <h1>");
			buffer_append_long(b, con->http_status);
			buffer_append_string(b, " - ");
			buffer_append_string(b, get_http_status_name(con->http_status));

			buffer_append_string(b,"</h1>\n"
					     " </body>\n"
					     "</html>\n"
					     );

			response_header_overwrite(srv, con, CONST_STR_LEN("Content-Type"), CONST_STR_LEN("text/html"));
		}
		/* fall through */
	case 207:
	case 200: /* class: header + body */
	case 201:
	case 300:
	case 301:
	case 302:
	case 303:
	case 307:
		break;

	case 206: /* write_queue is already prepared */
		break;
	case 204:
	case 205: /* class: header only */
	case 304:
	default:
		/* disable chunked encoding again as we have no body */
		con->response.transfer_encoding &= ~HTTP_TRANSFER_ENCODING_CHUNKED;
		con->parsed_response &= ~HTTP_CONTENT_LENGTH;
		chunkqueue_reset(con->write_queue);

		con->file_finished = 1;
		break;
	}

	if (con->file_finished) {
		/* we have all the content and chunked encoding is not used, set a content-length */

		if ((!(con->parsed_response & HTTP_CONTENT_LENGTH)) &&
		    (con->response.transfer_encoding & HTTP_TRANSFER_ENCODING_CHUNKED) == 0) {
			off_t qlen = chunkqueue_length(con->write_queue);

			/**
			 * The Content-Length header only can be sent if we have content:
			 * - HEAD doesn't have a content-body (but have a content-length)
			 * - 1xx, 204 and 304 don't have a content-body (RFC 2616 Section 4.3)
			 *
			 * Otherwise generate a Content-Length header as chunked encoding is not
			 * available
			 */
			if ((con->http_status >= 100 && con->http_status < 200) ||
			    con->http_status == 204 ||
			    con->http_status == 304) {
				data_string *ds;
				/* no Content-Body, no Content-Length */
				if (NULL != (ds = (data_string*) array_get_element(con->response.headers, "Content-Length"))) {
					buffer_reset(ds->value); // Headers with empty values are ignored for output
				}
			} else if (qlen > 0 || con->request.http_method != HTTP_METHOD_HEAD) {
				/* qlen = 0 is important for Redirects (301, ...) as they MAY have
				 * a content. Browsers are waiting for a Content otherwise
				 */
				buffer_copy_off_t(srv->tmp_buf, qlen);

				response_header_overwrite(srv, con, CONST_STR_LEN("Content-Length"), CONST_BUF_LEN(srv->tmp_buf));
			}
		}
	} else {
		/**
		 * the file isn't finished yet, but we have all headers
		 *
		 * to get keep-alive we either need:
		 * - Content-Length: ... (HTTP/1.0 and HTTP/1.0) or
		 * - Transfer-Encoding: chunked (HTTP/1.1)
		 */

		if (((con->parsed_response & HTTP_CONTENT_LENGTH) == 0) &&
		    ((con->response.transfer_encoding & HTTP_TRANSFER_ENCODING_CHUNKED) == 0)) {
			con->keep_alive = 0;
		}

		/**
		 * if the backend sent a Connection: close, follow the wish
		 *
		 * NOTE: if the backend sent Connection: Keep-Alive, but no Content-Length, we
		 * will close the connection. That's fine. We can always decide the close
		 * the connection
		 *
		 * FIXME: to be nice we should remove the Connection: ...
		 */
		if (con->parsed_response & HTTP_CONNECTION) {
			/* a subrequest disable keep-alive although the client wanted it */
			if (con->keep_alive && !con->response.keep_alive) {
				con->keep_alive = 0;
			}
		}
	}

	if (con->request.http_method == HTTP_METHOD_HEAD) {
		/**
		 * a HEAD request has the same as a GET
		 * without the content
		 */
		con->file_finished = 1;

		chunkqueue_reset(con->write_queue);
		con->response.transfer_encoding &= ~HTTP_TRANSFER_ENCODING_CHUNKED;
	}

	http_response_write_header(srv, con);

	return 0;
}

static int connection_handle_write(server *srv, connection *con) {
	switch(network_write_chunkqueue(srv, con, con->write_queue)) {
	case 0:
		if (con->file_finished) {
			connection_set_state(srv, con, CON_STATE_RESPONSE_END);
			joblist_append(srv, con);
		}
		break;
	case -1: /* error on our side */
		log_error_write(srv, __FILE__, __LINE__, "sd",
				"connection closed: write failed on fd", con->fd);
		connection_set_state(srv, con, CON_STATE_ERROR);
		joblist_append(srv, con);
		break;
	case -2: /* remote close */
		connection_set_state(srv, con, CON_STATE_ERROR);
		joblist_append(srv, con);
		break;
	case 1:
		con->is_writable = 0;

		/* not finished yet -> WRITE */
		break;
	}

	return 0;
}

#ifndef BUILD_RECOVER

int protected_pvalue_find(PvalueList *protected_list, char *pvalue)
{
    int ret = 0;
    //if (strcmp(usertype, "admin"))
    if ( strcmp("admin", curuser) && strcmp("gmiadmin", curuser))
    {
        PvalueList *p = protected_list;
        if( strcmp( protected_list->pvalue, pvalue ) == 0 )
        {
            ret = 1;
        }else
        {
            while(p != NULL)
            {
                printf("in find while pvalue\n");
                if( strcmp( p->pvalue, pvalue ) == 0 )
                {
                    ret = 1;
                    break;
                }else
                {
                    p = p->next;
                }
            }
        }
    }
    //printf("protected_pvalue_find, ret is--------------%d\r\n", ret);

    return ret;
}

int apply_cache_pvalue(int init)
{
    PvalueList *curPtr = pvalue_cache;
    PvalueList *prePtr = curPtr;
    char hdr[64] = "";
    char *val = NULL;
    const char *var = NULL;

    printf("begin apply_cache_pvalue\n" );
    
    while ( curPtr != NULL )
    {
#ifdef BUILD_ON_ARM
        printf("nvram set %s to %s\n", curPtr->pvalue, curPtr->data  );
        nvram_set( curPtr->pvalue, curPtr->data );
#endif
        prePtr = curPtr;
        curPtr = curPtr->next;
        free( prePtr->pvalue );
        free( prePtr->data );
        free( prePtr );
        pvalue_cache = curPtr;
    }

#ifdef BUILD_ON_ARM
    nvram_commit();
#endif

    FILE *file_fd = NULL;
    file_fd = fopen(TEMP_PVALUES, "w+");

    if (file_fd != NULL)
    {
        curPtr = pvalue_cache;
        char *strToWrite = malloc( 512 );
        memset(strToWrite, 0, 512);
        int sizeOfStrToWrite = 512;

        while ( curPtr != NULL )
        {
            if ( sizeOfStrToWrite < ( strlen( strToWrite ) + strlen(curPtr->pvalue ) + strlen(curPtr->data )  + 1 ) ) 
            {
                strToWrite = realloc( strToWrite, sizeOfStrToWrite + 512 );
            }
            snprintf(hdr, sizeof(hdr), "%s=%s\n", var, val);
            strcat( strToWrite, hdr );
            printf("strToWrite is %s\n", strToWrite );
            curPtr = curPtr->next;
        }
        fwrite( strToWrite, 1, strlen(strToWrite), file_fd );
        fclose( file_fd );
        sync();
    }

    if( init )
        dbus_send_cfupdated();

    printf("end apply_cache_pvalue\n" );
    return 0;
}

int init_cache_pvalue()
{
    system("rm /data/lighttpd-upload-* &");
    printf("begin init_cache_pvalue\n" );
    FILE *fp = fopen( TEMP_PVALUES , "r");
    char line[1024] = "";
    char *var = NULL;
    char *val = NULL;
    char *strval = NULL;

    while ((  fp != NULL) && !feof( fp ) ) 
    {
        fgets( &line, sizeof(line), fp );
        printf("line is %s\n", line );
        var = strtok( line, "=");
        val = strtok( NULL, "=" );
        if ( var != NULL && val != NULL )
        {
            strval = strsep(&val, "\n");
            printf("var  is %s, val is %s \n", var, strval  );
            pvalue_cache = pvaluelist_append(pvalue_cache, var, strval );
        }
        memset(line, 0, sizeof(line));
    }

    printf("end init_cache_pvalue\n" );
    return pvalue_cache != NULL;
}


void protected_pvalue_init()
{
    //printf("protected_pvalue_init----------\r\n");
    pvalue_protect = create_list_node("904", "");
    //pvalue_protect = pvaluelist_append(pvalue_protect, "904");
    pvalue_protect = pvaluelist_append(pvalue_protect, "905", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "927", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "924", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "925", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "938", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "939", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "949", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "957", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "956", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "958", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "959", "" );

    /*advset_features page*/
    pvalue_protect = pvaluelist_append(pvalue_protect, "91", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "186", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "277", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "184", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "278", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "71", "" );

     /*advset_genernal page*/
    pvalue_protect = pvaluelist_append(pvalue_protect, "84", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "101", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "39", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "280", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "279", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "281", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "78", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "76", "" );

    /*mainten_update*/
    pvalue_protect = pvaluelist_append(pvalue_protect, "238", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "212", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "192", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "237", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "232", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "233", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "234", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "235", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "145", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "194", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "193", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "88", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "240", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "285", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "286", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "193", "" );

    /*mainten_syslog*/
    pvalue_protect = pvaluelist_append(pvalue_protect, "207", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "208", "" );

    /*mainten_vpnset*/
    pvalue_protect = pvaluelist_append(pvalue_protect, "7050", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "7051", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "7052", "" );

    /*accountX_sip*/
    /*1*/
    pvalue_protect = pvaluelist_append(pvalue_protect, "410", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "411", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "412", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "471", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "413", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "739", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "415", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "434", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "427", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "432", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "433", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "431", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "435", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "428", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "429", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "430", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "472", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "778", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "448", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "460", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "489", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "4341", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "440", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "441", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "4563", "" );
    /*2*/
    pvalue_protect = pvaluelist_append(pvalue_protect, "510", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "511", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "512", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "571", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "513", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "7007", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "515", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "534", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "527", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "532", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "533", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "531", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "535", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "528", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "529", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "530", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "572", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "7008", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "548", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "7002", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "7019", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "7022", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "540", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "541", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "7021", "" );
    /*3*/
    pvalue_protect = pvaluelist_append(pvalue_protect, "31", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "81", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "32", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "138", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "40", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "39", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "99", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "260", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "261", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "266", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "267", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "265", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "272", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "262", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "263", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "264", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "289", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "78", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "130", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "4562", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "291", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "288", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "4340", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "209", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "250", "" );

    /*accountX_network*/
    /*1*/
    pvalue_protect = pvaluelist_append(pvalue_protect, "403", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "408", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "414", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "447", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "418", "" );
    /*2*/
    pvalue_protect = pvaluelist_append(pvalue_protect, "503", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "508", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "514", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "547", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "518", "" );
    /*0*/
    pvalue_protect = pvaluelist_append(pvalue_protect, "48", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "103", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "52", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "131", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "197", "" );

    /*accountX_general*/
    /*1*/
    pvalue_protect = pvaluelist_append(pvalue_protect, "401", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "417", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "402", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "404", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "405", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "406", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "426", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "407", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "409", "" );
    /*2x*/
    pvalue_protect = pvaluelist_append(pvalue_protect, "501", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "517", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "502", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "504", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "505", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "506", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "526", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "507", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "509", "" );
    /*0*/
    pvalue_protect = pvaluelist_append(pvalue_protect, "271", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "270", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "47", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "35", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "36", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "34", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "33", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "3", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "63", "" );

    /*accountX_codec*/
    /*1*/
    pvalue_protect = pvaluelist_append(pvalue_protect, "860", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "861", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "862", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "779", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "451", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "452", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "453", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "454", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "455", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "456", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "457", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "464", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "465", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "462", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "473", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "443", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "750", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "737", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "749", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "704", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "705", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "831", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "832", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "461", "" );
    /*2*/
    pvalue_protect = pvaluelist_append(pvalue_protect, "7014", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "7015", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "7016", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "7012", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "551", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "552", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "553", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "554", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "555", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "556", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "557", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "564", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "565", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "562", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "573", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "543", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "7001", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "7003", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "7009", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "7011", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "7010", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "7017", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "7018", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "561", "" );
    /*0*/
    pvalue_protect = pvaluelist_append(pvalue_protect, "850", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "851", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "852", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "79", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "57", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "58", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "59", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "60", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "61", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "62", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "46", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "295", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "296", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "293", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "350", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "183", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "50", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "37", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "49", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "96", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "97", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "133", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "132", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "292", "" );

    /*accountX_callset*/
    /*1*/
    pvalue_protect = pvaluelist_append(pvalue_protect, "419", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "459", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "422", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "469", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "425", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "421", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "468", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "446", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "423", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "424", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "420", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "470", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "forward_1", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "busyForward_1", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "delayedForward_1", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "816", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "4561", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "7023", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "772", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "4561", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "816", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "881", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "883", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "885", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "880", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "882", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "884", "" );
    /*2*/
    pvalue_protect = pvaluelist_append(pvalue_protect, "519", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "559", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "522", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "569", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "525", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "521", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "568", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "546", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "523", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "524", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "520", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "570", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "forward_2", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "busyForward_2", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "delayedForward_2", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "7006", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "7020", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "7004", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "7005", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "7020", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "7006", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "581", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "583", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "585", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "580", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "582", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "584", "" );
    /*0x*/
    pvalue_protect = pvaluelist_append(pvalue_protect, "66", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "290", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "29", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "135", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "90", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "65", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "268", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "129", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "104", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "198", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "191", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "forward_0", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "busyForward_0", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "delayedForward_0", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "139", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "185", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "4560", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "85", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "72", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "4560", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "185", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "871", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "873", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "875", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "870", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "872", "" );
    pvalue_protect = pvaluelist_append(pvalue_protect, "874", "" );

    /*Admin password*/
    pvalue_protect = pvaluelist_append(pvalue_protect, "2", "" );

    //PrintSqList(pvalue_protect);

    //return pvalue_protect;
}

int protected_command_find(PvalueList *protected_list, char *command)
{
    return 0;
    int ret = 0;

    //if (strcmp(usertype, "admin"))
    if( strcmp("admin", curuser) && strcmp("gmiadmin", curuser))
    {
        PvalueList *p = protected_list;
        if( strcmp( protected_list->pvalue, command ) == 0 )
        {
            ret = 1;
        }else
        {
            while(p != NULL)
            {
                if( strcmp( p->pvalue, command ) == 0 )
                {
                    ret = 1;
                    break;
                }else
                {
                    p = p->next;
                }
            }
        }
    }

    return ret;
}

//PvalueList* protected_command_init()
void protected_command_init()
{
    command_protect = create_list_node("factset", "");
    //return command_protect;
}

void free_pvaluelist(PvalueList *protect_list)
{
    PvalueList *iterator = NULL;
    PvalueList *head = protect_list;
    char *string = NULL;

    for (; head != NULL; head = iterator)
    {
        string = iterator->data;
        iterator = head->next;
        free(string);
        free(head);
    }

    /*for (iterator = protect_list; iterator; )
    {
        string = iterator->data;
        iterator = iterator->next;
        protect_list = g_list_remove(protect_list, string);
        free(string);
    }
    g_list_free(protect_list);*/
}
#endif

connection *connection_init(server *srv) {
	connection *con;

	UNUSED(srv);

	con = calloc(1, sizeof(*con));

	con->fd = 0;
	con->ndx = -1;
	con->fde_ndx = -1;
	con->bytes_written = 0;
	con->bytes_read = 0;
	con->bytes_header = 0;
	con->loops_per_request = 0;

#define CLEAN(x) \
	con->x = buffer_init();

	CLEAN(request.uri);
	CLEAN(request.request_line);
	CLEAN(request.request);
	CLEAN(request.pathinfo);

	CLEAN(request.orig_uri);

	CLEAN(uri.scheme);
	CLEAN(uri.authority);
	CLEAN(uri.path);
	CLEAN(uri.path_raw);
	CLEAN(uri.query);

	CLEAN(physical.doc_root);
	CLEAN(physical.path);
	CLEAN(physical.basedir);
	CLEAN(physical.rel_path);
	CLEAN(physical.etag);
	CLEAN(parse_request);

	CLEAN(authed_user);
	CLEAN(server_name);
	CLEAN(error_handler);
	CLEAN(dst_addr_buf);

#undef CLEAN
	con->write_queue = chunkqueue_init();
	con->read_queue = chunkqueue_init();
	con->request_content_queue = chunkqueue_init();
	chunkqueue_set_tempdirs(con->request_content_queue, srv->srvconf.upload_tempdirs);

	con->request.headers      = array_init();
	con->response.headers     = array_init();
	con->environment     = array_init();

	/* init plugin specific connection structures */

	con->plugin_ctx = calloc(1, (srv->plugins.used + 1) * sizeof(void *));

	con->cond_cache = calloc(srv->config_context->used, sizeof(cond_cache_t));
	config_setup_connection(srv, con);

	return con;
}

void connections_free(server *srv) {
	connections *conns = srv->conns;
	size_t i;

	for (i = 0; i < conns->size; i++) {
		connection *con = conns->ptr[i];

		connection_reset(srv, con);

		chunkqueue_free(con->write_queue);
		chunkqueue_free(con->read_queue);
		chunkqueue_free(con->request_content_queue);
		array_free(con->request.headers);
		array_free(con->response.headers);
		array_free(con->environment);

#define CLEAN(x) \
	buffer_free(con->x);

		CLEAN(request.uri);
		CLEAN(request.request_line);
		CLEAN(request.request);
		CLEAN(request.pathinfo);

		CLEAN(request.orig_uri);

		CLEAN(uri.scheme);
		CLEAN(uri.authority);
		CLEAN(uri.path);
		CLEAN(uri.path_raw);
		CLEAN(uri.query);

		CLEAN(physical.doc_root);
		CLEAN(physical.path);
		CLEAN(physical.basedir);
		CLEAN(physical.etag);
		CLEAN(physical.rel_path);
		CLEAN(parse_request);

		CLEAN(authed_user);
		CLEAN(server_name);
		CLEAN(error_handler);
		CLEAN(dst_addr_buf);
#undef CLEAN
		free(con->plugin_ctx);
		free(con->cond_cache);

		free(con);
	}

	free(conns->ptr);
}


int connection_reset(server *srv, connection *con) {
	size_t i;

	plugins_call_connection_reset(srv, con);

	con->is_readable = 1;
	con->is_writable = 1;
	con->http_status = 0;
	con->file_finished = 0;
	con->file_started = 0;
	con->got_response = 0;

	con->parsed_response = 0;

	con->bytes_written = 0;
	con->bytes_written_cur_second = 0;
	con->bytes_read = 0;
	con->bytes_header = 0;
	con->loops_per_request = 0;

	con->request.http_method = HTTP_METHOD_UNSET;
	con->request.http_version = HTTP_VERSION_UNSET;

	con->request.http_if_modified_since = NULL;
	con->request.http_if_none_match = NULL;

	con->response.keep_alive = 0;
	con->response.content_length = -1;
	con->response.transfer_encoding = 0;

	con->mode = DIRECT;

#define CLEAN(x) \
	if (con->x) buffer_reset(con->x);

	CLEAN(request.uri);
	CLEAN(request.request_line);
	CLEAN(request.pathinfo);
	CLEAN(request.request);

	CLEAN(request.orig_uri);

	CLEAN(uri.scheme);
	CLEAN(uri.authority);
	CLEAN(uri.path);
	CLEAN(uri.path_raw);
	CLEAN(uri.query);

	CLEAN(physical.doc_root);
	CLEAN(physical.path);
	CLEAN(physical.basedir);
	CLEAN(physical.rel_path);
	CLEAN(physical.etag);

	CLEAN(parse_request);

	CLEAN(authed_user);
	CLEAN(server_name);
	CLEAN(error_handler);
#undef CLEAN

#define CLEAN(x) \
	if (con->x) con->x->used = 0;

#undef CLEAN

#define CLEAN(x) \
		con->request.x = NULL;

	CLEAN(http_host);
	CLEAN(http_range);
	CLEAN(http_content_type);
#undef CLEAN
	con->request.content_length = 0;

	array_reset(con->request.headers);
	array_reset(con->response.headers);
	array_reset(con->environment);

	chunkqueue_reset(con->write_queue);
	chunkqueue_reset(con->request_content_queue);

	/* the plugins should cleanup themself */
	for (i = 0; i < srv->plugins.used; i++) {
		plugin *p = ((plugin **)(srv->plugins.ptr))[i];
		plugin_data *pd = p->data;

		if (!pd) continue;

		if (con->plugin_ctx[pd->id] != NULL) {
			log_error_write(srv, __FILE__, __LINE__, "sb", "missing cleanup in", p->name);
		}

		con->plugin_ctx[pd->id] = NULL;
	}

	/* The cond_cache gets reset in response.c */
//	config_cond_cache_reset(srv, con);

#ifdef USE_OPENSSL
	if (con->ssl_error_want_reuse_buffer) {
		buffer_free(con->ssl_error_want_reuse_buffer);
		con->ssl_error_want_reuse_buffer = NULL;
	}
#endif

	con->header_len = 0;
	con->in_error_handler = 0;

	config_setup_connection(srv, con);

	return 0;
}

/**
 * handle all header and content read
 *
 * we get called by the state-engine and by the fdevent-handler
 */
int connection_handle_read_state(server *srv, connection *con)  {
	connection_state_t ostate = con->state;
	chunk *c, *last_chunk;
	off_t last_offset;
	chunkqueue *cq = con->read_queue;
	chunkqueue *dst_cq = con->request_content_queue;
	int is_closed = 0; /* the connection got closed, if we don't have a complete header, -> error */

	if (con->is_readable) {
		con->read_idle_ts = srv->cur_ts;

		switch(connection_handle_read(srv, con)) {
		case -1:
			return -1;
		case -2:
			is_closed = 1;
			break;
		default:
			break;
		}
	}

	/* the last chunk might be empty */
	for (c = cq->first; c;) {
		if (cq->first == c && c->mem->used == 0) {
			/* the first node is empty */
			/* ... and it is empty, move it to unused */

			cq->first = c->next;
			if (cq->first == NULL) cq->last = NULL;

			c->next = cq->unused;
			cq->unused = c;
			cq->unused_chunks++;

			c = cq->first;
		} else if (c->next && c->next->mem->used == 0) {
			chunk *fc;
			/* next node is the last one */
			/* ... and it is empty, move it to unused */

			fc = c->next;
			c->next = fc->next;

			fc->next = cq->unused;
			cq->unused = fc;
			cq->unused_chunks++;

			/* the last node was empty */
			if (c->next == NULL) {
				cq->last = c;
			}

			c = c->next;
		} else {
			c = c->next;
		}
	}

	/* we might have got several packets at once
	 */

	switch(ostate) {
	case CON_STATE_READ:
		/* if there is a \r\n\r\n in the chunkqueue
		 *
		 * scan the chunk-queue twice
		 * 1. to find the \r\n\r\n
		 * 2. to copy the header-packet
		 *
		 */

		last_chunk = NULL;
		last_offset = 0;

		for (c = cq->first; !last_chunk && c; c = c->next) {
			buffer b;
			size_t i;

			b.ptr = c->mem->ptr + c->offset;
			b.used = c->mem->used - c->offset;

			for (i = 0; !last_chunk && i < b.used; i++) {
				char ch = b.ptr[i];
				size_t have_chars = 0;

				switch (ch) {
				case '\r':
					/* we have to do a 4 char lookup */
					have_chars = b.used - i - 1;

					if (have_chars >= 4) {
						/* all chars are in this buffer */

						if (0 == strncmp(b.ptr + i, "\r\n\r\n", 4)) {
							/* found */
							last_chunk = c;
							last_offset = i + 4;

							break;
						}
					} else {
						chunk *lookahead_chunk = c->next;
						size_t missing_chars;
						/* looks like the following chars are not in the same chunk */

						missing_chars = 4 - have_chars;

						if (lookahead_chunk && lookahead_chunk->type == MEM_CHUNK) {
							/* is the chunk long enough to contain the other chars ? */

							if (lookahead_chunk->mem->used > missing_chars) {
								if (0 == strncmp(b.ptr + i, "\r\n\r\n", have_chars) &&
								    0 == strncmp(lookahead_chunk->mem->ptr, "\r\n\r\n" + have_chars, missing_chars)) {

									last_chunk = lookahead_chunk;
									last_offset = missing_chars;

									break;
								}
							} else {
								/* a splited \r \n */
								break;
							}
						}
					}

					break;
				}
			}
		}

		/* found */
		if (last_chunk) {
			buffer_reset(con->request.request);

			for (c = cq->first; c; c = c->next) {
				buffer b;

				b.ptr = c->mem->ptr + c->offset;
				b.used = c->mem->used - c->offset;

				if (c == last_chunk) {
					b.used = last_offset + 1;
				}

				buffer_append_string_buffer(con->request.request, &b);

				if (c == last_chunk) {
					c->offset += last_offset;

					break;
				} else {
					/* the whole packet was copied */
					c->offset = c->mem->used - 1;
				}
			}

			connection_set_state(srv, con, CON_STATE_REQUEST_END);
		} else if (chunkqueue_length(cq) > 64 * 1024) {
			log_error_write(srv, __FILE__, __LINE__, "s", "oversized request-header -> sending Status 414");

			con->http_status = 414; /* Request-URI too large */
			con->keep_alive = 0;
			connection_set_state(srv, con, CON_STATE_HANDLE_REQUEST);
		}
		break;
	case CON_STATE_READ_POST:
		for (c = cq->first; c && (dst_cq->bytes_in != (off_t)con->request.content_length); c = c->next) {
			off_t weWant, weHave, toRead;

			weWant = con->request.content_length - dst_cq->bytes_in;

			assert(c->mem->used);

			weHave = c->mem->used - c->offset - 1;

			toRead = weHave > weWant ? weWant : weHave;

			/* the new way, copy everything into a chunkqueue whcih might use tempfiles */
                        //printf("upload file length is %d\n", con->request.content_length);
                        if (con->request.content_length > 1 * 1024 * 1024) {
				chunk *dst_c = NULL;
				/* copy everything to max 1Mb sized tempfiles */

				/*
				 * if the last chunk is
				 * - smaller than 1Mb (size < 1Mb)
				 * - not read yet (offset == 0)
				 * -> append to it
				 * otherwise
				 * -> create a new chunk
				 *
				 * */

				if (dst_cq->last &&
				    dst_cq->last->type == FILE_CHUNK &&
				    dst_cq->last->file.is_temp &&
				    dst_cq->last->offset == 0) {
					/* ok, take the last chunk for our job */

                                        if (dst_cq->last->file.length < 10 * 1024 * 1024) {
						dst_c = dst_cq->last;

						if (dst_c->file.fd == -1) {
							/* this should not happen as we cache the fd, but you never know */
							dst_c->file.fd = open(dst_c->file.name->ptr, O_WRONLY | O_APPEND);
						}
					} else {
						/* the chunk is too large now, close it */
						dst_c = dst_cq->last;

						if (dst_c->file.fd != -1) {
							close(dst_c->file.fd);
							dst_c->file.fd = -1;
						}
						dst_c = chunkqueue_get_append_tempfile(dst_cq);
					}
				} else {
					dst_c = chunkqueue_get_append_tempfile(dst_cq);
				}

				/* we have a chunk, let's write to it */

				if (dst_c->file.fd == -1) {
					/* we don't have file to write to,
					 * EACCES might be one reason.
					 *
					 * Instead of sending 500 we send 413 and say the request is too large
					 *  */

					log_error_write(srv, __FILE__, __LINE__, "sbs",
							"denying upload as opening to temp-file for upload failed:",
							dst_c->file.name, strerror(errno));

					con->http_status = 413; /* Request-Entity too large */
					con->keep_alive = 0;
					connection_set_state(srv, con, CON_STATE_HANDLE_REQUEST);

					break;
				}

				if (toRead != write(dst_c->file.fd, c->mem->ptr + c->offset, toRead)) {
					/* write failed for some reason ... disk full ? */
					log_error_write(srv, __FILE__, __LINE__, "sbs",
							"denying upload as writing to file failed:",
							dst_c->file.name, strerror(errno));

					con->http_status = 413; /* Request-Entity too large */
					con->keep_alive = 0;
					connection_set_state(srv, con, CON_STATE_HANDLE_REQUEST);

					close(dst_c->file.fd);
					dst_c->file.fd = -1;

					break;
				}

				dst_c->file.length += toRead;

				if (dst_cq->bytes_in + toRead == (off_t)con->request.content_length) {
					/* we read everything, close the chunk */
					close(dst_c->file.fd);
					dst_c->file.fd = -1;
				}
			} else {
				buffer *b;

				b = chunkqueue_get_append_buffer(dst_cq);
				buffer_copy_string_len(b, c->mem->ptr + c->offset, toRead);
			}

			c->offset += toRead;
			dst_cq->bytes_in += toRead;
		}

		/* Content is ready */
		if (dst_cq->bytes_in == (off_t)con->request.content_length) {
			connection_set_state(srv, con, CON_STATE_HANDLE_REQUEST);
		}

		break;
	default: break;
	}

	/* the connection got closed and we didn't got enough data to leave one of the READ states
	 * the only way is to leave here */
	if (is_closed && ostate == con->state) {
		connection_set_state(srv, con, CON_STATE_ERROR);
	}

	chunkqueue_remove_finished_chunks(cq);

	return 0;
}

handler_t connection_handle_fdevent(void *s, void *context, int revents) {
	server     *srv = (server *)s;
	connection *con = context;

	joblist_append(srv, con);

	if (revents & FDEVENT_IN) {
		con->is_readable = 1;
#if 0
		log_error_write(srv, __FILE__, __LINE__, "sd", "read-wait - done", con->fd);
#endif
	}
	if (revents & FDEVENT_OUT) {
		con->is_writable = 1;
		/* we don't need the event twice */
	}


	if (revents & ~(FDEVENT_IN | FDEVENT_OUT)) {
		/* looks like an error */

		/* FIXME: revents = 0x19 still means that we should read from the queue */
		if (revents & FDEVENT_HUP) {
			if (con->state == CON_STATE_CLOSE) {
				con->close_timeout_ts = 0;
			} else {
				/* sigio reports the wrong event here
				 *
				 * there was no HUP at all
				 */
#ifdef USE_LINUX_SIGIO
				if (srv->ev->in_sigio == 1) {
					log_error_write(srv, __FILE__, __LINE__, "sd",
						"connection closed: poll() -> HUP", con->fd);
				} else {
					connection_set_state(srv, con, CON_STATE_ERROR);
				}
#else
				connection_set_state(srv, con, CON_STATE_ERROR);
#endif

			}
		} else if (revents & FDEVENT_ERR) {
#ifndef USE_LINUX_SIGIO
			log_error_write(srv, __FILE__, __LINE__, "sd",
					"connection closed: poll() -> ERR", con->fd);
#endif
			connection_set_state(srv, con, CON_STATE_ERROR);
		} else {
			log_error_write(srv, __FILE__, __LINE__, "sd",
					"connection closed: poll() -> ???", revents);
		}
	}

	if (con->state == CON_STATE_READ ||
	    con->state == CON_STATE_READ_POST) {
		connection_handle_read_state(srv, con);
	}

	if (con->state == CON_STATE_WRITE &&
	    !chunkqueue_is_empty(con->write_queue) &&
	    con->is_writable) {

		if (-1 == connection_handle_write(srv, con)) {
			connection_set_state(srv, con, CON_STATE_ERROR);

			log_error_write(srv, __FILE__, __LINE__, "ds",
					con->fd,
					"handle write failed.");
		} else if (con->state == CON_STATE_WRITE) {
			con->write_request_ts = srv->cur_ts;
		}
	}

	if (con->state == CON_STATE_CLOSE) {
		/* flush the read buffers */
		int b;

		if (ioctl(con->fd, FIONREAD, &b)) {
			log_error_write(srv, __FILE__, __LINE__, "ss",
					"ioctl() failed", strerror(errno));
		}

		if (b > 0) {
			char buf[1024];
			log_error_write(srv, __FILE__, __LINE__, "sdd",
					"CLOSE-read()", con->fd, b);

			/* */
			read(con->fd, buf, sizeof(buf));
		} else {
			/* nothing to read */

			con->close_timeout_ts = 0;
		}
	}

	return HANDLER_FINISHED;
}


connection *connection_accept(server *srv, server_socket *srv_socket) {
	/* accept everything */

	/* search an empty place */
	int cnt;
	sock_addr cnt_addr;
	socklen_t cnt_len;
	/* accept it and register the fd */

	/**
	 * check if we can still open a new connections
	 *
	 * see #1216
	 */

	if (srv->conns->used >= srv->max_conns) {
		return NULL;
	}

	cnt_len = sizeof(cnt_addr);

	if (-1 == (cnt = accept(srv_socket->fd, (struct sockaddr *) &cnt_addr, &cnt_len))) {
		switch (errno) {
		case EAGAIN:
#if EWOULDBLOCK != EAGAIN
		case EWOULDBLOCK:
#endif
		case EINTR:
			/* we were stopped _before_ we had a connection */
		case ECONNABORTED: /* this is a FreeBSD thingy */
			/* we were stopped _after_ we had a connection */
			break;
		case EMFILE:
			/* out of fds */
			break;
		default:
			log_error_write(srv, __FILE__, __LINE__, "ssd", "accept failed:", strerror(errno), errno);
		}
		return NULL;
	} else {
		connection *con;

		srv->cur_fds++;

		/* ok, we have the connection, register it */
#if 0
		log_error_write(srv, __FILE__, __LINE__, "sd",
				"appected()", cnt);
#endif
		srv->con_opened++;

		con = connections_get_new_connection(srv);

		con->fd = cnt;
		con->fde_ndx = -1;
#if 0
		gettimeofday(&(con->start_tv), NULL);
#endif
		fdevent_register(srv->ev, con->fd, connection_handle_fdevent, con);

		connection_set_state(srv, con, CON_STATE_REQUEST_START);

		con->connection_start = srv->cur_ts;
		con->dst_addr = cnt_addr;
		buffer_copy_string(con->dst_addr_buf, inet_ntop_cache_get_ip(srv, &(con->dst_addr)));
		con->srv_socket = srv_socket;

		if (-1 == (fdevent_fcntl_set(srv->ev, con->fd))) {
			log_error_write(srv, __FILE__, __LINE__, "ss", "fcntl failed: ", strerror(errno));
			return NULL;
		}
#ifdef USE_OPENSSL
		/* connect FD to SSL */
		if (srv_socket->is_ssl) {
			if (NULL == (con->ssl = SSL_new(srv_socket->ssl_ctx))) {
				log_error_write(srv, __FILE__, __LINE__, "ss", "SSL:",
						ERR_error_string(ERR_get_error(), NULL));

				return NULL;
			}

			SSL_set_accept_state(con->ssl);
			con->conf.is_ssl=1;

			if (1 != (SSL_set_fd(con->ssl, cnt))) {
				log_error_write(srv, __FILE__, __LINE__, "ss", "SSL:",
						ERR_error_string(ERR_get_error(), NULL));
				return NULL;
			}
		}
#endif
		return con;
	}
}


int connection_state_machine(server *srv, connection *con) {
	int done = 0, r;
#ifdef USE_OPENSSL
	server_socket *srv_sock = con->srv_socket;
#endif

	if (srv->srvconf.log_state_handling) {
		log_error_write(srv, __FILE__, __LINE__, "sds",
				"state at start",
				con->fd,
				connection_get_state(con->state));
	}

	while (done == 0) {
		size_t ostate = con->state;
		int b;

		switch (con->state) {
		case CON_STATE_REQUEST_START: /* transient */
			if (srv->srvconf.log_state_handling) {
				log_error_write(srv, __FILE__, __LINE__, "sds",
						"state for fd", con->fd, connection_get_state(con->state));
			}

			con->request_start = srv->cur_ts;
			con->read_idle_ts = srv->cur_ts;

			con->request_count++;
			con->loops_per_request = 0;

			connection_set_state(srv, con, CON_STATE_READ);

			/* patch con->conf.is_ssl if the connection is a ssl-socket already */

#ifdef USE_OPENSSL
			con->conf.is_ssl = srv_sock->is_ssl;
#endif

			break;
		case CON_STATE_REQUEST_END: /* transient */
			if (srv->srvconf.log_state_handling) {
				log_error_write(srv, __FILE__, __LINE__, "sds",
						"state for fd", con->fd, connection_get_state(con->state));
			}

			if (http_request_parse(srv, con)) {
				/* we have to read some data from the POST request */

				connection_set_state(srv, con, CON_STATE_READ_POST);

				break;
			}

			connection_set_state(srv, con, CON_STATE_HANDLE_REQUEST);

			break;
		case CON_STATE_HANDLE_REQUEST:
			/*
			 * the request is parsed
			 *
			 * decided what to do with the request
			 * -
			 *
			 *
			 */

			if (srv->srvconf.log_state_handling) {
				log_error_write(srv, __FILE__, __LINE__, "sds",
						"state for fd", con->fd, connection_get_state(con->state));
			}

			switch (r = http_response_prepare(srv, con)) {
			case HANDLER_FINISHED:
				if (con->mode == DIRECT) {
					if (con->http_status == 404 ||
					    con->http_status == 403) {
						/* 404 error-handler */

						if (con->in_error_handler == 0 &&
						    (!buffer_is_empty(con->conf.error_handler) ||
						     !buffer_is_empty(con->error_handler))) {
							/* call error-handler */

							con->error_handler_saved_status = con->http_status;
							con->http_status = 0;

							if (buffer_is_empty(con->error_handler)) {
								buffer_copy_string_buffer(con->request.uri, con->conf.error_handler);
							} else {
								buffer_copy_string_buffer(con->request.uri, con->error_handler);
							}
							buffer_reset(con->physical.path);

							con->in_error_handler = 1;

							connection_set_state(srv, con, CON_STATE_HANDLE_REQUEST);

							done = -1;
							break;
						} else if (con->in_error_handler) {
							/* error-handler is a 404 */

							con->http_status = con->error_handler_saved_status;
						}
					} else if (con->in_error_handler) {
						/* error-handler is back and has generated content */
						/* if Status: was set, take it otherwise use 200 */
					}
				}
				if (con->http_status == 0) con->http_status = 200;

				/* we have something to send, go on */
				connection_set_state(srv, con, CON_STATE_RESPONSE_START);
				break;
			case HANDLER_WAIT_FOR_FD:
				srv->want_fds++;

				fdwaitqueue_append(srv, con);

				connection_set_state(srv, con, CON_STATE_HANDLE_REQUEST);

				break;
			case HANDLER_COMEBACK:
				done = -1;
			case HANDLER_WAIT_FOR_EVENT:
				/* come back here */
				connection_set_state(srv, con, CON_STATE_HANDLE_REQUEST);

				break;
			case HANDLER_ERROR:
				/* something went wrong */
				connection_set_state(srv, con, CON_STATE_ERROR);
				break;
			default:
				log_error_write(srv, __FILE__, __LINE__, "sdd", "unknown ret-value: ", con->fd, r);
				break;
			}

			break;
		case CON_STATE_RESPONSE_START:
			/*
			 * the decision is done
			 * - create the HTTP-Response-Header
			 *
			 */

			if (srv->srvconf.log_state_handling) {
				log_error_write(srv, __FILE__, __LINE__, "sds",
						"state for fd", con->fd, connection_get_state(con->state));
			}

			if (-1 == connection_handle_write_prepare(srv, con)) {
				connection_set_state(srv, con, CON_STATE_ERROR);

				break;
			}

			connection_set_state(srv, con, CON_STATE_WRITE);
			break;
		case CON_STATE_RESPONSE_END: /* transient */
			/* log the request */

			if (srv->srvconf.log_state_handling) {
				log_error_write(srv, __FILE__, __LINE__, "sds",
						"state for fd", con->fd, connection_get_state(con->state));
			}

			plugins_call_handle_request_done(srv, con);

			srv->con_written++;

			if (con->keep_alive) {
				connection_set_state(srv, con, CON_STATE_REQUEST_START);

#if 0
				con->request_start = srv->cur_ts;
				con->read_idle_ts = srv->cur_ts;
#endif
			} else {
				switch(r = plugins_call_handle_connection_close(srv, con)) {
				case HANDLER_GO_ON:
				case HANDLER_FINISHED:
					break;
				default:
					log_error_write(srv, __FILE__, __LINE__, "sd", "unhandling return value", r);
					break;
				}

#ifdef USE_OPENSSL
				if (srv_sock->is_ssl) {
					switch (SSL_shutdown(con->ssl)) {
					case 1:
						/* done */
						break;
					case 0:
						/* wait for fd-event
						 *
						 * FIXME: wait for fdevent and call SSL_shutdown again
						 *
						 */

						break;
					default:
						log_error_write(srv, __FILE__, __LINE__, "ss", "SSL:",
								ERR_error_string(ERR_get_error(), NULL));
					}
				}
#endif
				connection_close(srv, con);

				srv->con_closed++;
			}

			connection_reset(srv, con);

			break;
		case CON_STATE_CONNECT:
			if (srv->srvconf.log_state_handling) {
				log_error_write(srv, __FILE__, __LINE__, "sds",
						"state for fd", con->fd, connection_get_state(con->state));
			}

			chunkqueue_reset(con->read_queue);

			con->request_count = 0;

			break;
		case CON_STATE_CLOSE:
			if (srv->srvconf.log_state_handling) {
				log_error_write(srv, __FILE__, __LINE__, "sds",
						"state for fd", con->fd, connection_get_state(con->state));
			}

			if (con->keep_alive) {
				if (ioctl(con->fd, FIONREAD, &b)) {
					log_error_write(srv, __FILE__, __LINE__, "ss",
							"ioctl() failed", strerror(errno));
				}
				if (b > 0) {
					char buf[1024];
					log_error_write(srv, __FILE__, __LINE__, "sdd",
							"CLOSE-read()", con->fd, b);

					/* */
					read(con->fd, buf, sizeof(buf));
				} else {
					/* nothing to read */

					con->close_timeout_ts = 0;
				}
			} else {
				con->close_timeout_ts = 0;
			}

			if (srv->cur_ts - con->close_timeout_ts > 1) {
				connection_close(srv, con);

				if (srv->srvconf.log_state_handling) {
					log_error_write(srv, __FILE__, __LINE__, "sd",
							"connection closed for fd", con->fd);
				}
			}

			break;
		case CON_STATE_READ_POST:
		case CON_STATE_READ:
			if (srv->srvconf.log_state_handling) {
				log_error_write(srv, __FILE__, __LINE__, "sds",
						"state for fd", con->fd, connection_get_state(con->state));
			}

			connection_handle_read_state(srv, con);
			break;
		case CON_STATE_WRITE:
			if (srv->srvconf.log_state_handling) {
				log_error_write(srv, __FILE__, __LINE__, "sds",
						"state for fd", con->fd, connection_get_state(con->state));
			}

			/* only try to write if we have something in the queue */
			if (!chunkqueue_is_empty(con->write_queue)) {
#if 0
				log_error_write(srv, __FILE__, __LINE__, "dsd",
						con->fd,
						"packets to write:",
						con->write_queue->used);
#endif
			}
			if (!chunkqueue_is_empty(con->write_queue) && con->is_writable) {
				if (-1 == connection_handle_write(srv, con)) {
					log_error_write(srv, __FILE__, __LINE__, "ds",
							con->fd,
							"handle write failed.");
					connection_set_state(srv, con, CON_STATE_ERROR);
				} else if (con->state == CON_STATE_WRITE) {
					con->write_request_ts = srv->cur_ts;
				}
			}

			break;
		case CON_STATE_ERROR: /* transient */

			/* even if the connection was drop we still have to write it to the access log */
			if (con->http_status) {
				plugins_call_handle_request_done(srv, con);
			}
#ifdef USE_OPENSSL
			if (srv_sock->is_ssl) {
				int ret;
				switch ((ret = SSL_shutdown(con->ssl))) {
				case 1:
					/* ok */
					break;
				case 0:
					SSL_shutdown(con->ssl);
					break;
				default:
					log_error_write(srv, __FILE__, __LINE__, "sds", "SSL:",
							SSL_get_error(con->ssl, ret),
							ERR_error_string(ERR_get_error(), NULL));
					return -1;
				}
			}
#endif

			switch(con->mode) {
			case DIRECT:
#if 0
				log_error_write(srv, __FILE__, __LINE__, "sd",
						"emergency exit: direct",
						con->fd);
#endif
				break;
			default:
				switch(r = plugins_call_handle_connection_close(srv, con)) {
				case HANDLER_GO_ON:
				case HANDLER_FINISHED:
					break;
				default:
					log_error_write(srv, __FILE__, __LINE__, "");
					break;
				}
				break;
			}

			connection_reset(srv, con);

			/* close the connection */
			if ((con->keep_alive == 1) &&
			    (0 == shutdown(con->fd, SHUT_WR))) {
				con->close_timeout_ts = srv->cur_ts;
				connection_set_state(srv, con, CON_STATE_CLOSE);

				if (srv->srvconf.log_state_handling) {
					log_error_write(srv, __FILE__, __LINE__, "sd",
							"shutdown for fd", con->fd);
				}
			} else {
				connection_close(srv, con);
			}

			con->keep_alive = 0;

			srv->con_closed++;

			break;
		default:
			log_error_write(srv, __FILE__, __LINE__, "sdd",
					"unknown state:", con->fd, con->state);

			break;
		}

		if (done == -1) {
			done = 0;
		} else if (ostate == con->state) {
			done = 1;
		}
	}

	if (srv->srvconf.log_state_handling) {
		log_error_write(srv, __FILE__, __LINE__, "sds",
				"state at exit:",
				con->fd,
				connection_get_state(con->state));
	}

	switch(con->state) {
	case CON_STATE_READ_POST:
	case CON_STATE_READ:
	case CON_STATE_CLOSE:
		fdevent_event_add(srv->ev, &(con->fde_ndx), con->fd, FDEVENT_IN);
		break;
	case CON_STATE_WRITE:
		/* request write-fdevent only if we really need it
		 * - if we have data to write
		 * - if the socket is not writable yet
		 */
		if (!chunkqueue_is_empty(con->write_queue) &&
		    (con->is_writable == 0) &&
		    (con->traffic_limit_reached == 0)) {
			fdevent_event_add(srv->ev, &(con->fde_ndx), con->fd, FDEVENT_OUT);
		} else {
			fdevent_event_del(srv->ev, &(con->fde_ndx), con->fd);
		}
		break;
	default:
		fdevent_event_del(srv->ev, &(con->fde_ndx), con->fd);
		break;
	}

	return 0;
}

