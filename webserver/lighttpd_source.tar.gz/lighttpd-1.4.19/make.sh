source  envlighttpdarmEABI.sh
./configure --host=arm-linux --without-bzip2 --without-zlib --prefix=/system/lighttpd --with-openssl
make && sudo make install
