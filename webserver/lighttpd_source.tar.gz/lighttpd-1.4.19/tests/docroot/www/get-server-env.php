<?php
	print $_SERVER[$_GET["env"]];
?>
